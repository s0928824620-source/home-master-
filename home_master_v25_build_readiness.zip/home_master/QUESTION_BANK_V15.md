# Home Master v15 — Question Bank & Publishing

Added:
- Select existing questions for an exam
- Save question order
- Automatic exam question count
- Publish/unpublish exams
- Students can only read questions from published exams
- Staff-only question assignment

Setup:
Run `supabase/v15_question_bank.sql` after v14.

Important:
The existing question table may use a different option representation in older seed data.
Map/normalize those fields before production use.
