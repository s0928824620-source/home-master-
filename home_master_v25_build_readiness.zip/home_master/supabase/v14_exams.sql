
-- Home Master v14: online exam system
create table if not exists public.exams (
  id uuid primary key default gen_random_uuid(),
  title_en text not null,
  title_ar text not null,
  grade_id text not null references public.grades(id),
  subject_id text not null references public.subjects(id),
  duration_minutes integer not null default 30 check(duration_minutes > 0),
  question_count integer not null default 10 check(question_count > 0),
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.exam_attempts (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  subject_id text not null references public.subjects(id),
  score integer not null default 0,
  total integer not null default 0,
  duration_seconds integer not null default 0,
  created_at timestamptz not null default now()
);

alter table public.exams enable row level security;
alter table public.exam_attempts enable row level security;

drop policy if exists "published exams readable" on public.exams;
drop policy if exists "staff manage exams" on public.exams;
drop policy if exists "own attempts" on public.exam_attempts;
drop policy if exists "staff read attempts" on public.exam_attempts;
drop policy if exists "students submit attempts" on public.exam_attempts;

create policy "published exams readable" on public.exams
for select to authenticated using (is_published or public.is_staff());

create policy "staff manage exams" on public.exams
for all to authenticated using (public.is_staff()) with check (public.is_staff());

create policy "own attempts" on public.exam_attempts
for select to authenticated using (user_id=auth.uid());

create policy "staff read attempts" on public.exam_attempts
for select to authenticated using (public.is_staff());

create policy "students submit attempts" on public.exam_attempts
for insert to authenticated with check (user_id=auth.uid());

create index if not exists idx_exams_grade on public.exams(grade_id);
create index if not exists idx_exams_subject on public.exams(subject_id);
create index if not exists idx_attempts_user on public.exam_attempts(user_id);
