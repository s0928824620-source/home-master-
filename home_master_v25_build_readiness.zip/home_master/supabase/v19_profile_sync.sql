-- Home Master v19: editable student profiles and local lesson-progress sync.
alter table public.profiles add column if not exists full_name text;
alter table public.profiles add column if not exists role text not null default 'student';

-- Keep the original schema's name column supported by older app versions.
alter table public.profiles add column if not exists name text;
alter table public.profiles add column if not exists grade_id text;

alter table public.lesson_progress add column if not exists completed boolean not null default true;
alter table public.lesson_progress add column if not exists completed_at timestamptz default now();

alter table public.profiles enable row level security;
drop policy if exists "own profile select" on public.profiles;
create policy "own profile select" on public.profiles
for select to authenticated using (auth.uid() = id);

drop policy if exists "own profile update" on public.profiles;
create policy "own profile update" on public.profiles
for update to authenticated using (auth.uid() = id)
with check (auth.uid() = id);

drop policy if exists "Users can view own profile" on public.profiles;
create policy "Users can view own profile" on public.profiles
for select to authenticated using (auth.uid() = id);

drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile" on public.profiles
for update to authenticated using (auth.uid() = id)
with check (auth.uid() = id);

alter table public.lesson_progress enable row level security;
drop policy if exists "own progress select" on public.lesson_progress;
create policy "own progress select" on public.lesson_progress
for select to authenticated using (auth.uid() = user_id);

drop policy if exists "own progress insert" on public.lesson_progress;
create policy "own progress insert" on public.lesson_progress
for insert to authenticated with check (auth.uid() = user_id);

drop policy if exists "own progress update" on public.lesson_progress;
create policy "own progress update" on public.lesson_progress
for update to authenticated using (auth.uid() = user_id)
with check (auth.uid() = user_id);
