-- Home Master v20: secure admin role management RPC.
-- Run after the previous schema and migrations. Review the existing is_staff()
-- function and adapt the admin check if your project uses a different role model.

create or replace function public.home_master_set_user_role(target_user uuid, new_role text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  caller_role text;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  select role into caller_role
  from public.profiles
  where id = auth.uid();

  if caller_role is distinct from 'admin' then
    raise exception 'Only an admin can change roles';
  end if;

  if new_role not in ('student', 'teacher', 'admin') then
    raise exception 'Invalid role';
  end if;

  update public.profiles
  set role = new_role
  where id = target_user;

  if not found then
    raise exception 'User profile not found';
  end if;
end;
$$;

revoke all on function public.home_master_set_user_role(uuid, text) from public;
grant execute on function public.home_master_set_user_role(uuid, text) to authenticated;
