
-- Home Master v15: connect exams to existing question bank

alter table public.questions add column if not exists text_en text;
alter table public.questions add column if not exists text_ar text;
alter table public.questions add column if not exists subject_id text references public.subjects(id);
-- Keep existing options columns/types from schema.sql; PostgreSQL cannot change their type with IF NOT EXISTS.


create table if not exists public.exam_questions (
  exam_id uuid not null references public.exams(id) on delete cascade,
  question_id text not null references public.questions(id) on delete cascade,
  position integer not null default 1,
  primary key (exam_id,question_id)
);

alter table public.exam_questions enable row level security;

drop policy if exists "staff manage exam questions" on public.exam_questions;
drop policy if exists "students read published exam questions" on public.exam_questions;

create policy "staff manage exam questions" on public.exam_questions
for all to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "students read published exam questions" on public.exam_questions
for select to authenticated
using (
  exists (
    select 1 from public.exams e
    where e.id=exam_id and e.is_published=true
  )
);

create index if not exists idx_exam_questions_exam on public.exam_questions(exam_id);
create index if not exists idx_exam_questions_question on public.exam_questions(question_id);

-- Keep exam question count synchronized.
create or replace function public.sync_exam_question_count()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  update public.exams
  set question_count=(select count(*) from public.exam_questions where exam_id=coalesce(new.exam_id,old.exam_id))
  where id=coalesce(new.exam_id,old.exam_id);
  return coalesce(new,old);
end;
$$;

drop trigger if exists trg_sync_exam_question_count on public.exam_questions;
create trigger trg_sync_exam_question_count
after insert or delete on public.exam_questions
for each row execute function public.sync_exam_question_count();
