-- Home Master v23: compatibility migration for columns used by the current Flutter client.
-- Run AFTER schema.sql and migrations v12-v22. Review on a test project first.

-- Lessons: keep legacy body_* columns while supporting the app's content_* field names.
alter table public.lessons add column if not exists content_en text;
alter table public.lessons add column if not exists content_ar text;
alter table public.lessons add column if not exists created_at timestamptz not null default now();
update public.lessons set content_en = body_en where content_en is null and body_en is not null;
update public.lessons set content_ar = body_ar where content_ar is null and body_ar is not null;

-- Questions: preserve legacy question_* columns while supporting text_* names.
alter table public.questions add column if not exists text_en text;
alter table public.questions add column if not exists text_ar text;
alter table public.questions add column if not exists subject_id text references public.subjects(id);
alter table public.questions add column if not exists created_at timestamptz not null default now();
update public.questions set text_en = question_en where text_en is null and question_en is not null;
update public.questions set text_ar = question_ar where text_ar is null and question_ar is not null;
update public.questions q set subject_id = l.subject_id from public.lessons l where q.lesson_id = l.id and q.subject_id is null;

-- Profile and analytics fields expected by the app.
alter table public.profiles add column if not exists full_name text;
alter table public.profiles add column if not exists role text not null default 'student';
update public.profiles set full_name = name where full_name is null and name is not null;

-- Analytics expects stable row IDs and created_at fields.
alter table public.lesson_progress add column if not exists id uuid default gen_random_uuid();
alter table public.quiz_results add column if not exists id uuid default gen_random_uuid();
alter table public.quiz_results add column if not exists created_at timestamptz default now();
update public.quiz_results set created_at = taken_at where created_at is null and taken_at is not null;

-- Ensure newly created app records carry both the legacy and current field names.
-- Existing writes use content_* and text_*; legacy readers can continue using body_* / question_*.
create or replace function public.home_master_sync_legacy_content_columns()
returns trigger language plpgsql set search_path = public as $$
begin
  if tg_table_name = 'lessons' then
    if new.content_en is null then new.content_en := new.body_en; end if;
    if new.content_ar is null then new.content_ar := new.body_ar; end if;
    if new.body_en is null then new.body_en := new.content_en; end if;
    if new.body_ar is null then new.body_ar := new.content_ar; end if;
  elsif tg_table_name = 'questions' then
    if new.text_en is null then new.text_en := new.question_en; end if;
    if new.text_ar is null then new.text_ar := new.question_ar; end if;
    if new.question_en is null then new.question_en := new.text_en; end if;
    if new.question_ar is null then new.question_ar := new.text_ar; end if;
  end if;
  return new;
end; $$;

drop trigger if exists home_master_sync_lessons_columns on public.lessons;
create trigger home_master_sync_lessons_columns before insert or update on public.lessons
for each row execute function public.home_master_sync_legacy_content_columns();
drop trigger if exists home_master_sync_questions_columns on public.questions;
create trigger home_master_sync_questions_columns before insert or update on public.questions
for each row execute function public.home_master_sync_legacy_content_columns();

create index if not exists idx_questions_subject on public.questions(subject_id);
create index if not exists idx_lessons_created_at on public.lessons(created_at desc);
