-- HOME MASTER v6 DATABASE
-- Run this in Supabase SQL Editor.
-- RLS is enabled so students can only change their own progress/results.

create table if not exists public.grades (
  id text primary key,
  name_en text not null,
  name_ar text not null
);

create table if not exists public.subjects (
  id text primary key,
  title_en text not null,
  title_ar text not null,
  icon text
);

create table if not exists public.grade_subjects (
  grade_id text references public.grades(id) on delete cascade,
  subject_id text references public.subjects(id) on delete cascade,
  primary key (grade_id, subject_id)
);

create table if not exists public.lessons (
  id text primary key,
  subject_id text references public.subjects(id) on delete cascade,
  lesson_number int not null,
  title_en text not null,
  title_ar text not null,
  body_en text not null,
  body_ar text not null
);

create table if not exists public.questions (
  id text primary key,
  lesson_id text references public.lessons(id) on delete cascade,
  question_number int not null,
  question_en text not null,
  question_ar text not null,
  options_en jsonb not null,
  options_ar jsonb not null,
  correct_index int not null
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text,
  grade_id text references public.grades(id),
  created_at timestamptz default now()
);

create table if not exists public.lesson_progress (
  user_id uuid references auth.users(id) on delete cascade,
  lesson_id text references public.lessons(id) on delete cascade,
  completed boolean not null default false,
  completed_at timestamptz,
  primary key (user_id, lesson_id)
);

create table if not exists public.quiz_results (
  user_id uuid references auth.users(id) on delete cascade,
  subject_id text references public.subjects(id) on delete cascade,
  score int not null,
  total int not null,
  taken_at timestamptz default now(),
  primary key (user_id, subject_id)
);

-- Seed grades
insert into public.grades (id,name_en,name_ar) values
('p8','Primary 8','الصف الثامن'),
('s1','Senior 1','الأول الثانوي'),
('s2','Senior 2','الثاني الثانوي'),
('s3','Senior 3','الثالث الثانوي')
on conflict (id) do nothing;

-- Seed subjects
insert into public.subjects (id,title_en,title_ar,icon) values
('mathematics','Mathematics','الرياضيات','calculate'),
('english','English','اللغة الإنجليزية','translate'),
('biology','Biology','الأحياء','biotech'),
('chemistry','Chemistry','الكيمياء','science'),
('physics','Physics','الفيزياء','bolt'),
('geography','Geography','الجغرافيا','public'),
('history','History','التاريخ','history_edu'),
('commerce','Commerce','التجارة','storefront'),
('account','Account','المحاسبة','account_balance')
on conflict (id) do nothing;

-- Give S1-S3 all subjects. P8 uses the core four.
insert into public.grade_subjects
select g.id, s.id
from public.grades g cross join public.subjects s
where g.id in ('s1','s2','s3')
on conflict do nothing;

insert into public.grade_subjects values
('p8','mathematics'),('p8','english'),('p8','biology'),('p8','geography')
on conflict do nothing;

-- Example online lesson
insert into public.lessons
(id,subject_id,lesson_number,title_en,title_ar,body_en,body_ar)
values
('math_s1_01','mathematics',1,
 'Introduction to Algebra','مقدمة في الجبر',
 'Algebra uses letters and symbols to represent numbers and relationships.',
 'يستخدم الجبر الحروف والرموز لتمثيل الأعداد والعلاقات.')
on conflict (id) do nothing;

insert into public.questions
(id,lesson_id,question_number,question_en,question_ar,options_en,options_ar,correct_index)
values
('math_s1_01_q1','math_s1_01',1,
 'If x + 3 = 8, what is x?','إذا كان x + 3 = 8، فما قيمة x؟',
 '["3","5","8","11"]','["3","5","8","11"]',1)
on conflict (id) do nothing;

-- RLS
alter table public.profiles enable row level security;
alter table public.lesson_progress enable row level security;
alter table public.quiz_results enable row level security;
alter table public.grades enable row level security;
alter table public.subjects enable row level security;
alter table public.grade_subjects enable row level security;
alter table public.lessons enable row level security;
alter table public.questions enable row level security;

create policy "public read grades" on public.grades for select to anon, authenticated using (true);
create policy "public read subjects" on public.subjects for select to anon, authenticated using (true);
create policy "public read grade subjects" on public.grade_subjects for select to anon, authenticated using (true);
create policy "public read lessons" on public.lessons for select to anon, authenticated using (true);
create policy "public read questions" on public.questions for select to anon, authenticated using (true);

create policy "own profile select" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "own profile insert" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "own profile update" on public.profiles for update to authenticated using (auth.uid() = id);

create policy "own progress select" on public.lesson_progress for select to authenticated using (auth.uid() = user_id);
create policy "own progress insert" on public.lesson_progress for insert to authenticated with check (auth.uid() = user_id);
create policy "own progress update" on public.lesson_progress for update to authenticated using (auth.uid() = user_id);

create policy "own results select" on public.quiz_results for select to authenticated using (auth.uid() = user_id);
create policy "own results insert" on public.quiz_results for insert to authenticated with check (auth.uid() = user_id);
create policy "own results update" on public.quiz_results for update to authenticated using (auth.uid() = user_id);

-- Create a profile automatically after registration.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, name, grade_id)
  values (
    new.id,
    new.raw_user_meta_data ->> 'name',
    new.raw_user_meta_data ->> 'grade_id'
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();


-- v9 performance indexes
create index if not exists idx_grade_subjects_grade on public.grade_subjects(grade_id);
create index if not exists idx_grade_subjects_subject on public.grade_subjects(subject_id);
create index if not exists idx_lessons_subject on public.lessons(subject_id);
create index if not exists idx_questions_lesson on public.questions(lesson_id);
create index if not exists idx_lesson_progress_user on public.lesson_progress(user_id);
create index if not exists idx_quiz_results_user on public.quiz_results(user_id);

-- v11 search indexes
create index if not exists idx_lessons_title_en on public.lessons using gin (to_tsvector('english', coalesce(title_en,'') || ' ' || coalesce(content_en,'')));
create index if not exists idx_lessons_title_ar on public.lessons (title_ar);
