
-- Home Master v13 analytics
-- Safe read access for staff only; users can manage their own profile as before.

create or replace function public.is_staff()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role in ('teacher','admin')
  );
$$;

grant execute on function public.is_staff() to authenticated;

alter table public.profiles enable row level security;
alter table public.quiz_results enable row level security;
alter table public.lesson_progress enable row level security;

drop policy if exists "staff_read_profiles" on public.profiles;
drop policy if exists "staff_update_profiles" on public.profiles;
drop policy if exists "staff_read_results" on public.quiz_results;
drop policy if exists "staff_read_progress" on public.lesson_progress;

create policy "staff_read_profiles" on public.profiles
for select to authenticated using (public.is_staff() or id=auth.uid());

create policy "staff_update_profiles" on public.profiles
for update to authenticated using (public.is_staff() or id=auth.uid())
with check (public.is_staff() or id=auth.uid());

create policy "staff_read_results" on public.quiz_results
for select to authenticated using (public.is_staff() or user_id=auth.uid());

create policy "staff_read_progress" on public.lesson_progress
for select to authenticated using (public.is_staff() or user_id=auth.uid());
