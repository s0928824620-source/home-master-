-- Home Master v21: prevent clients from granting themselves roles.
-- Run AFTER schema.sql and migrations v12-v20 in Supabase SQL Editor.

create or replace function public.home_master_set_user_role(target_user uuid, new_role text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  caller_role text;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  select role into caller_role
  from public.profiles
  where id = auth.uid();

  if caller_role is distinct from 'admin' then
    raise exception 'Only an admin can change roles';
  end if;

  if new_role is null or new_role not in ('student', 'teacher', 'admin') then
    raise exception 'Invalid role';
  end if;

  update public.profiles
  set role = new_role
  where id = target_user;

  if not found then
    raise exception 'User profile not found';
  end if;
end;
$$;

revoke all on function public.home_master_set_user_role(uuid, text) from public;
grant execute on function public.home_master_set_user_role(uuid, text) to authenticated;

-- Remove broad table-level UPDATE access, then allow only editable profile fields.
-- This blocks a user from changing their own role via a direct table update.
revoke update on table public.profiles from anon, authenticated;
grant update (full_name, name, grade_id) on table public.profiles to authenticated;

-- Keep row-level protection: profile edits remain limited to the signed-in user's row.
alter table public.profiles enable row level security;

drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile"
on public.profiles for update
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);
