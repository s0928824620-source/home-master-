-- Home Master v18: profile fields and profile creation trigger.
-- Run this in Supabase SQL Editor after schema.sql and prior migrations.
alter table public.profiles add column if not exists full_name text;
alter table public.profiles add column if not exists role text not null default 'student';

create or replace function public.home_master_create_profile()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, name, grade_id, role)
  values (
    new.id,
    nullif(new.raw_user_meta_data->>'full_name', ''),
    nullif(new.raw_user_meta_data->>'full_name', ''),
    nullif(new.raw_user_meta_data->>'grade_id', ''),
    'student'
  )
  on conflict (id) do update set
    full_name = coalesce(excluded.full_name, profiles.full_name),
    name = coalesce(excluded.name, profiles.name),
    grade_id = coalesce(excluded.grade_id, profiles.grade_id);
  return new;
end;
$$;

drop trigger if exists home_master_auth_user_created on auth.users;
create trigger home_master_auth_user_created
after insert on auth.users
for each row execute procedure public.home_master_create_profile();

alter table public.profiles enable row level security;
drop policy if exists "Users can view own profile" on public.profiles;
create policy "Users can view own profile"
on public.profiles for select
using (auth.uid() = id);
drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile"
on public.profiles for update
using (auth.uid() = id)
with check (auth.uid() = id);

-- Ensure profile insertion is performed only by the trusted trigger.
drop policy if exists "Users can insert own profile" on public.profiles;
