
-- Home Master v12: staff roles + protected curriculum editing
alter table public.profiles
  add column if not exists role text not null default 'student';

alter table public.profiles
  drop constraint if exists profiles_role_check;

alter table public.profiles
  add constraint profiles_role_check
  check (role in ('student','teacher','admin'));

create or replace function public.is_staff()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid()
      and role in ('teacher','admin')
  );
$$;

revoke all on function public.is_staff() from public;
grant execute on function public.is_staff() to authenticated;

-- Enable RLS
alter table public.lessons enable row level security;
alter table public.questions enable row level security;

drop policy if exists "staff_insert_lessons" on public.lessons;
drop policy if exists "staff_update_lessons" on public.lessons;
drop policy if exists "staff_delete_lessons" on public.lessons;
drop policy if exists "staff_insert_questions" on public.questions;
drop policy if exists "staff_update_questions" on public.questions;
drop policy if exists "staff_delete_questions" on public.questions;

create policy "staff_insert_lessons" on public.lessons
for insert to authenticated
with check (public.is_staff());

create policy "staff_update_lessons" on public.lessons
for update to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "staff_delete_lessons" on public.lessons
for delete to authenticated
using (public.is_staff());

create policy "staff_insert_questions" on public.questions
for insert to authenticated
with check (public.is_staff());

create policy "staff_update_questions" on public.questions
for update to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "staff_delete_questions" on public.questions
for delete to authenticated
using (public.is_staff());

-- First admin: replace the UUID below with the user's Auth UUID.
-- update public.profiles set role='admin' where id='YOUR-AUTH-USER-UUID';
