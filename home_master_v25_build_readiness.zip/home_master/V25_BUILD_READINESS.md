# Home Master v25 — Build Readiness

This package is Flutter source code, not an APK. This environment does not have Flutter/Dart installed, so no compile or runtime test is claimed.

## 1. Install tools
- Install Flutter SDK and Android Studio on a computer.
- Run `flutter doctor` and resolve the Android toolchain issues.
- iOS builds require macOS with Xcode; an Android/Windows computer cannot produce an iOS IPA.

## 2. Prepare native platform folders
From the `home_master` project directory, run:

```bash
flutter create --platforms=android,ios .
flutter pub get
python3 tools/preflight_check.py
flutter analyze
flutter test
```

If Flutter reports that platform files already exist, back up the project before regenerating them.

## 3. Configure Supabase
- Create a Supabase project.
- Set `SUPABASE_URL` and the publishable/anon key using the project's supported build configuration.
- Never include a Supabase `service_role` key in a mobile app.
- Review and apply SQL migrations in order only after comparing them with the live schema and taking a backup.
- Create the first admin role through a trusted, server-side process; do not make a user admin from an untrusted client.

## 4. Build Android APK
```bash
flutter build apk --release
```
Expected output after a successful build: `build/app/outputs/flutter-apk/app-release.apk`.

## 5. Before sharing
Test sign-in/sign-up, lesson loading, Arabic/English switching, exam attempts, results, role permissions, and behavior with no network. Do not publish until `flutter analyze`, tests, and real Supabase security checks pass.


## Compile correction pass (2026-10-15)
Corrected malformed widget expressions in `main.dart`, corrected the student exam list widget tree, and added the missing Supabase profile/lesson-sync methods referenced by the student profile screen. These changes are source-level corrections; the APK must still be built in GitHub Actions to verify the complete project.
