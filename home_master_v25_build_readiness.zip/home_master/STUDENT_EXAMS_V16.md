# Home Master v16 — Student Exams, Results & Leaderboard

Added reusable pages:
- StudentExamsPage: lists published exams and starts them.
- StudentResultsPage: shows the signed-in learner's attempts.
- LeaderboardPage: ranks learners by average percentage, using anonymous labels.

Run the v14 and v15 SQL migrations first. Supabase must be configured.
These pages need to be linked from the app navigation before appearing in the main UI.
