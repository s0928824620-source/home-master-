#!/usr/bin/env python3
"""Static preflight checks only; does not compile or test Flutter/Supabase."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
required = [
    "pubspec.yaml", "lib/main.dart", "lib/services/supabase_service.dart",
    "lib/services/admin_analytics.dart", "lib/services/admin_service.dart",
    "supabase/schema.sql", "supabase/v20_secure_role_management.sql",
    "supabase/v23_schema_compatibility.sql", ".env.example",
    "V25_BUILD_READINESS.md",
]
errors = [f"Missing required file: {item}" for item in required if not (ROOT / item).is_file()]
pubspec = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
if "version: 1.0.0+25" not in pubspec:
    errors.append("pubspec version is not 1.0.0+25")

# Basic check that role changes call the server-side RPC, not a direct profile update.
analytics = ROOT / "lib/services/admin_analytics.dart"
if analytics.exists():
    content = analytics.read_text(encoding="utf-8")
    if "home_master_set_user_role" not in content:
        errors.append("AdminAnalytics does not call the secure role RPC")
    if ".from('profiles').update" in content or '.from("profiles").update' in content:
        errors.append("Possible direct profiles update remains in admin analytics")

# Service-role keys must never be embedded in client code.
for folder in (ROOT / "lib", ROOT / "android", ROOT / "ios"):
    if folder.exists():
        for file in folder.rglob("*"):
            if file.is_file() and file.suffix in {".dart", ".xml", ".gradle", ".plist", ".kt", ".swift"}:
                data = file.read_text(encoding="utf-8", errors="ignore").lower()
                if "service_role" in data and "never include" not in data:
                    errors.append(f"Review possible service_role reference: {file.relative_to(ROOT)}")

if errors:
    print("PREFLIGHT: FAILED")
    for error in errors:
        print(" - " + error)
    sys.exit(1)

print("PREFLIGHT: basic static checks passed.")
if not (ROOT / "android").exists():
    print("WARNING: android/ folder missing; run: flutter create --platforms=android,ios .")
if not (ROOT / "ios").exists():
    print("WARNING: ios/ folder missing; iOS build requires macOS + Xcode.")
print("This check does NOT prove the app compiles, runs, or has a secure live backend.")
