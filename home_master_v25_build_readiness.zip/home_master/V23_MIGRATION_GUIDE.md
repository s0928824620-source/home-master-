# Home Master v23 migration guide

## Important safety notes
- Back up the Supabase project before running SQL.
- Run migrations in the Supabase SQL Editor with an account authorized to alter tables/functions.
- Never place a Supabase `service_role` key in the mobile app.
- The first administrator must be provisioned manually by a trusted project owner. Never let public signup choose a role.

## New or existing database
For an existing database, run only `supabase/v23_schema_compatibility.sql` after prior migrations, after reviewing it against the actual schema. For a fresh database, use `schema.sql` and the ordered migration files; v23 adds compatibility columns and triggers for the current client.

## Verification checklist
- `profiles.role` contains only student/teacher/admin.
- Student can read their own profile and update only allowed profile fields.
- Student cannot edit curriculum, publish exams, or change roles.
- Teacher can manage lessons/questions/exams only if the RLS policies allow staff.
- Student can read published exams and submit their own attempt only.
- Results and progress are visible only to their owner unless staff analytics policy explicitly allows staff.
- Verify the `exam_questions.question_id` type matches `questions.id`.

## Build commands
After installing Flutter stable and generating native platform folders, run:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
```

Replace placeholders with your Supabase project URL and publishable/anon key. Build output should be at `build/app/outputs/flutter-apk/app-release.apk`. A Mac with Xcode is required to build the iOS app.
