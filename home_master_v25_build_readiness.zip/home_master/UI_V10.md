# Home Master v10 — Student UI

Added a reusable Material 3 visual layer:
- `lib/ui/home_master_theme.dart`
- consistent light/dark themes
- section titles
- statistics cards
- cleaner spacing and card presentation

Recommended home screen structure:
1. Welcome/student name
2. Current class badge (P8/S1/S2/S3)
3. Progress summary: lessons completed + quiz score
4. Subjects as cards
5. Continue Learning button
6. Quick Quiz button
7. Results and Settings

The existing bilingual `t()` system can be used for Arabic/English labels.
