# Home Master v21 changelog

- Hardened role management by routing role changes through the admin-only Supabase RPC.
- Restricted client profile updates to `full_name`, `name`, and `grade_id` at the database permission layer.
- Added bilingual feedback for successful/failed role updates.
- Added security migration and Android build/validation guide.
