# Home Master v14 — Exam System

Added:
- Timed exams
- Multiple-choice questions
- Previous/Next navigation
- Automatic scoring and percentage
- Online saving of exam attempts
- Staff exam management
- Supabase RLS

Setup:
1. Run `supabase/v14_exams.sql` after the v13 SQL.
2. Connect the exam UI to your existing question bank.
3. Publish exams only after questions are assigned.

A live Supabase project is still required for online operation.
