# Home Master v19 — Editable Profile and Progress Sync

## New in v19
- Edit student display name and class from My Profile.
- Upload completed local lesson IDs to the signed-in student's Supabase progress.
- Refresh online progress, practice results, and online exam attempts.
- Arabic/English labels and user-facing status/error messages.

## Setup
1. Apply the previous required schema and migrations first.
2. Run `supabase/v19_profile_sync.sql` in the Supabase SQL Editor.
3. Run `flutter pub get`.
4. Launch with the Supabase project URL and publishable key using the instructions in `SUPABASE_SETUP.md`.

## Notes
- The app source is not a built APK/IPA.
- Sync only uploads completed lesson markers; it does not upload practice quiz history from local storage.
- Test migrations against a development Supabase project before production. Do not use a service-role key in the mobile app.
