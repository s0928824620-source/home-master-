# Home Master

Bilingual English/Arabic offline-first Flutter education app for Android and iPhone.

Current features:
- Offline lessons and quizzes
- English / Arabic interface
- Dark mode
- Local quiz results
- Classes: Primary 8, Senior 1, Senior 2, Senior 3
- Grade-specific subject filtering
- Lesson completion tracking
- Progress dashboard with lesson completion, quiz performance and overall level

Run with Flutter:
`flutter pub get`
`flutter run`

Android: `flutter build apk`
iOS (macOS): `flutter build ios`


## Home Master v5 — Online
- Internet/API layer added.
- Android Internet permission added.
- Connectivity detection added.
- Configure `HOME_MASTER_API` with `--dart-define`.
- See `ONLINE_BACKEND.md` for the server contract.


## v7 content
Run `supabase/seed_content_v7.sql` after the schema to load the expanded bilingual curriculum seed. See `CONTENT_V7.md`.


## v12 Admin Dashboard
Teacher/admin roles, secure Supabase RLS policies, and an online lesson/question editor are included. See `ADMIN_V12.md` and `supabase/v12_admin.sql`.


## v17 Student tools
See `STUDENT_V17.md` for profile, student exam navigation, online results, leaderboard, and Supabase setup notes.


See `STUDENT_ACCOUNTS_V18.md` for student account setup and `supabase/v18_student_accounts.sql` for the profile migration.


See `PROFILE_SYNC_V19.md` for editable profile and lesson progress sync setup.


See `TEACHER_WORKSPACE_V20.md` for teacher tools and `supabase/v20_secure_role_management.sql` for admin-only role changes.


## v24 release preparation
See `V24_CHANGELOG.md`. Run `python3 tools/preflight_check.py` for basic static checks, or `./check_project.sh` on a machine with Flutter installed. Static checks do not certify a successful app build.
