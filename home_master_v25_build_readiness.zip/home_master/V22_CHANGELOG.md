# Home Master v22 changes

- Added Windows and macOS/Linux scripts to generate Android and iOS Flutter platform folders consistently.
- Added `.env.example` showing the two public build-time configuration values without real secrets.
- Added a platform setup, validation, and Android build checklist.
- Bumped package version to `1.0.0+22`.

Validation status: source packaging completed; Flutter analyze/build not run because Flutter tooling is not available in the packaging environment.
