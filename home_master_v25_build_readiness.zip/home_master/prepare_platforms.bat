@echo off
setlocal
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter was not found. Install Flutter and add it to PATH first.
  exit /b 1
)
cd /d "%~dp0"
flutter create --platforms=android,ios --org org.homemaster.education .
if errorlevel 1 exit /b 1
flutter pub get
if errorlevel 1 exit /b 1
echo.
echo Platform folders generated. Next run: flutter analyze
