class LocalizedText {
  final String en;
  final String ar;
  const LocalizedText(this.en, this.ar);
  String get(bool isArabic) => isArabic ? ar : en;
}

class Grade {
  final String id;
  final LocalizedText name;
  const Grade({required this.id, required this.name});
}

class Subject {
  final String id;
  final LocalizedText name;
  final int colorValue;
  final String icon;
  final List<Lesson> lessons;
  final List<Question> questions;
  const Subject({required this.id, required this.name, required this.colorValue, required this.icon, required this.lessons, required this.questions});
}

class Lesson {
  final String id;
  final LocalizedText title;
  final LocalizedText body;
  const Lesson({required this.id, required this.title, required this.body});
}

class Question {
  final LocalizedText question;
  final List<LocalizedText> options;
  final int answer;
  const Question({required this.question, required this.options, required this.answer});
}
