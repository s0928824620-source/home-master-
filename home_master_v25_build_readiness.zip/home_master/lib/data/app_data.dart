import '../models/models.dart';

LocalizedText lt(String en, String ar) => LocalizedText(en, ar);
Lesson lesson(String id, String enTitle, String arTitle, String enBody, String arBody) => Lesson(id:id,title:lt(enTitle,arTitle),body:lt(enBody,arBody));
Question q(String en, String ar, List<String> enO, List<String> arO, int a) => Question(question:lt(en,ar),options:List.generate(enO.length,(i)=>lt(enO[i],arO[i])),answer:a);

final List<Subject> subjects = [
  Subject(id:'mathematics',name:lt('Mathematics','الرياضيات'),colorValue:0xFF1565C0,icon:'∑',lessons:[
    lesson('algebra','Algebra Basics','أساسيات الجبر','An equation has two equal sides. Solve 2x + 6 = 16 by subtracting 6, then dividing by 2, so x = 5.','المعادلة لها طرفان متساويان. لحل 2x + 6 = 16 نطرح 6 ثم نقسم على 2، فنحصل على x = 5.'),
    lesson('fractions','Fractions','الكسور','A fraction represents a part of a whole. In 3/4, 3 is the numerator and 4 is the denominator.','الكسر يمثل جزءًا من كل. في 3/4 البسط هو 3 والمقام هو 4.'),
    lesson('percentages','Percentages','النسب المئوية','A percentage is a fraction out of 100. 25% of 80 is 20.','النسبة المئوية كسر من 100. ‏25% من 80 تساوي 20.'),
    lesson('indices','Indices and Powers','الأسس والقوى','An index shows repeated multiplication. 2³ = 2 × 2 × 2 = 8.','الأس يوضح تكرار الضرب. 2³ = 2 × 2 × 2 = 8.'),
  ],questions:[
    q('What is x in 2x + 6 = 16?','ما قيمة x في 2x + 6 = 16؟',['4','5','6','7'],['٤','٥','٦','٧'],1),
    q('What is 7 × 8?','كم يساوي 7 × 8؟',['54','56','64','48'],['٥٤','٥٦','٦٤','٤٨'],1),
    q('What is 3/4 of 20?','كم يساوي 3/4 من 20؟',['10','12','15','16'],['١٠','١٢','١٥','١٦'],2),
    q('What is 25% of 80?','كم تساوي 25% من 80؟',['15','20','25','30'],['١٥','٢٠','٢٥','٣٠'],1),
    q('What is 2³?','ما قيمة 2³؟',['6','8','9','12'],['٦','٨','٩','١٢'],1),
  ]),
  Subject(id:'english',name:lt('English','اللغة الإنجليزية'),colorValue:0xFFD32F2F,icon:'A',lessons:[
    lesson('parts','Parts of Speech','أقسام الكلام','A noun names a person, place, thing or idea. A verb shows an action or state. An adjective describes a noun.','الاسم يدل على شخص أو مكان أو شيء أو فكرة. الفعل يدل على حدث أو حالة. الصفة تصف الاسم.'),
    lesson('tenses','Basic Tenses','الأزمنة الأساسية','The present describes regular actions: I study. The past describes completed actions: I studied. The future can use will: I will study.','المضارع يصف الأفعال المعتادة: I study. الماضي يصف الأفعال المكتملة: I studied. المستقبل يمكن أن يستخدم will: I will study.'),
    lesson('sentence','Sentence Structure','تركيب الجملة','A basic English sentence often has a subject, verb and object: The student reads a book.','غالبًا تتكون الجملة الإنجليزية الأساسية من فاعل وفعل ومفعول به: The student reads a book.'),
    lesson('vocabulary','Vocabulary Skills','مهارات المفردات','Learn new words using context, synonyms and examples. Keep a small vocabulary list and review it regularly.','تعلم الكلمات الجديدة باستخدام السياق والمرادفات والأمثلة. احتفظ بقائمة مفردات وراجعها باستمرار.'),
  ],questions:[
    q('Which word is a verb?','أي كلمة هي فعل؟',['school','run','beautiful','student'],['مدرسة','يجري','جميل','طالب'],1),
    q('Choose the past tense of “go”.','اختر صيغة الماضي للفعل go.',['goed','goes','went','going'],['goed','goes','went','going'],2),
    q('Which is a noun?','أي كلمة اسم؟',['quickly','teacher','write','beautiful'],['بسرعة','معلم','يكتب','جميل'],1),
    q('Choose the correct sentence.','اختر الجملة الصحيحة.',['He go to school.','He goes to school.','He going school.','He gone school.'],['He go to school.','He goes to school.','He going school.','He gone school.'],1),
    q('What is the opposite of “easy”?','ما عكس كلمة easy؟',['simple','hard','light','early'],['بسيط','صعب','خفيف','مبكر'],1),
  ]),
  Subject(id:'biology',name:lt('Biology','الأحياء'),colorValue:0xFF2E7D32,icon:'⌁',lessons:[
    lesson('cell','The Cell','الخلية','The cell is the basic structural and functional unit of life.','الخلية هي الوحدة الأساسية في تركيب ووظيفة الكائنات الحية.'),
    lesson('photosynthesis','Photosynthesis','البناء الضوئي','Plants use light energy, water and carbon dioxide to make food and release oxygen.','تستخدم النباتات ضوء الشمس والماء وثاني أكسيد الكربون لصنع الغذاء وإطلاق الأكسجين.'),
    lesson('nutrition','Human Nutrition','تغذية الإنسان','A balanced diet supplies carbohydrates, proteins, fats, vitamins, minerals, fibre and water in suitable amounts.','الغذاء المتوازن يوفر الكربوهيدرات والبروتينات والدهون والفيتامينات والمعادن والألياف والماء بكميات مناسبة.'),
    lesson('ecosystem','Ecosystems','الأنظمة البيئية','An ecosystem includes living organisms and the non-living environment in which they interact.','يشمل النظام البيئي الكائنات الحية والبيئة غير الحية التي تتفاعل معها.'),
  ],questions:[
    q('What is the basic unit of life?','ما الوحدة الأساسية للحياة؟',['Tissue','Cell','Organ','System'],['نسيج','خلية','عضو','جهاز'],1),
    q('What gas is released during photosynthesis?','ما الغاز الذي يطلق أثناء البناء الضوئي؟',['Nitrogen','Oxygen','Hydrogen','Helium'],['النيتروجين','الأكسجين','الهيدروجين','الهيليوم'],1),
    q('Which nutrient mainly builds and repairs tissues?','أي عنصر غذائي يساعد أساسًا في بناء وإصلاح الأنسجة؟',['Protein','Water','Salt','Fibre'],['البروتين','الماء','الملح','الألياف'],0),
    q('Which is a living component of an ecosystem?','أي مما يلي مكون حي للنظام البيئي؟',['Sunlight','Water','Plant','Soil'],['ضوء الشمس','الماء','النبات','التربة'],2),
  ]),
  Subject(id:'chemistry',name:lt('Chemistry','الكيمياء'),colorValue:0xFF8E24AA,icon:'⚗',lessons:[
    lesson('matter','States of Matter','حالات المادة','Matter commonly exists as solid, liquid and gas.','توجد المادة عادة في حالات صلبة وسائلة وغازية.'),
    lesson('atom','Atoms and Elements','الذرات والعناصر','An atom is a tiny unit of matter. An element contains atoms with the same number of protons.','الذرة وحدة صغيرة جدًا من المادة. والعنصر يتكون من ذرات لها العدد نفسه من البروتونات.'),
    lesson('mixtures','Mixtures','المخاليط','A mixture contains two or more substances that are physically combined and can often be separated.','المخلوط يحتوي على مادتين أو أكثر متحدتين فيزيائيًا ويمكن غالبًا فصلهما.'),
    lesson('acids','Acids and Bases','الأحماض والقواعد','Acids and bases have different properties. The pH scale is commonly used to describe how acidic or basic a solution is.','للأحماض والقواعد خصائص مختلفة. ويستخدم مقياس pH لوصف حموضة أو قاعدية المحلول.'),
  ],questions:[
    q('Which state has no fixed shape or volume?','أي حالة ليس لها شكل أو حجم ثابت؟',['Solid','Liquid','Gas','Ice'],['صلب','سائل','غاز','ثلج'],2),
    q('What is the centre of an atom called?','ماذا يسمى مركز الذرة؟',['Nucleus','Shell','Cell','Mixture'],['النواة','الغلاف','الخلية','المخلوط'],0),
    q('Which is a mixture?','أي مما يلي مخلوط؟',['Pure oxygen','Salt water','Gold element','Hydrogen'],['الأكسجين النقي','الماء المالح','عنصر الذهب','الهيدروجين'],1),
    q('A pH below 7 is generally…','قيمة pH أقل من 7 تكون عادة…',['Acidic','Basic','Neutral','Metallic'],['حمضية','قاعدية','متعادلـة','فلزية'],0),
  ]),
  Subject(id:'physics',name:lt('Physics','الفيزياء'),colorValue:0xFFEF6C00,icon:'⚡',lessons:[
    lesson('force','Force and Motion','القوة والحركة','A force is a push or pull that can change motion. Force is measured in newtons (N).','القوة هي دفع أو سحب يمكن أن يغير الحركة. وتقاس بالنيوتن (N).'),
    lesson('energy','Energy','الطاقة','Energy is the ability to do work. Common forms include kinetic, potential, thermal and electrical energy.','الطاقة هي القدرة على بذل شغل. ومن أشكالها الطاقة الحركية والوضعية والحرارية والكهربائية.'),
    lesson('electricity','Basic Electricity','الكهرباء الأساسية','An electric current is the flow of charge. Voltage provides the push that drives current through a circuit.','التيار الكهربائي هو تدفق الشحنة. والجهد يوفر القوة الدافعة للتيار في الدائرة.'),
    lesson('density','Density','الكثافة','Density is mass per unit volume: density = mass ÷ volume.','الكثافة هي الكتلة لكل وحدة حجم: الكثافة = الكتلة ÷ الحجم.'),
  ],questions:[
    q('What is the SI unit of force?','ما وحدة قياس القوة؟',['Joule','Watt','Newton','Pascal'],['جول','واط','نيوتن','باسكال'],2),
    q('Which energy is associated with motion?','أي طاقة ترتبط بالحركة؟',['Kinetic','Chemical','Nuclear','Sound only'],['حركية','كيميائية','نووية','صوتية فقط'],0),
    q('What flows in an electric circuit?','ماذا يتدفق في الدائرة الكهربائية؟',['Charge','Wood','Light only','Water'],['الشحنة','الخشب','الضوء فقط','الماء'],0),
    q('Density equals…','الكثافة تساوي…',['mass × volume','mass ÷ volume','volume ÷ mass','mass + volume'],['الكتلة × الحجم','الكتلة ÷ الحجم','الحجم ÷ الكتلة','الكتلة + الحجم'],1),
  ]),
  Subject(id:'geography',name:lt('Geography','الجغرافيا'),colorValue:0xFF00838F,icon:'◎',lessons:[
    lesson('plates','Tectonic Plates','الصفائح التكتونية','Earth’s crust is divided into large tectonic plates. Their movement can cause earthquakes, volcanoes and mountain building.','تنقسم قشرة الأرض إلى صفائح تكتونية كبيرة. ويمكن لحركتها أن تسبب الزلازل والبراكين وتكوين الجبال.'),
    lesson('weather','Weather and Climate','الطقس والمناخ','Weather describes short-term atmospheric conditions, while climate describes long-term patterns in a place.','الطقس يصف حالة الجو قصيرة المدى، بينما المناخ يصف الأنماط طويلة المدى في المكان.'),
    lesson('rivers','Rivers','الأنهار','A river is a natural flowing watercourse. Rivers can erode, transport and deposit materials.','النهر مجرى مائي طبيعي جارٍ. ويمكن للأنهار أن تنحت وتنقل وترسب المواد.'),
    lesson('population','Population','السكان','Population geography studies where people live, population size, density, movement and related patterns.','تدرس جغرافيا السكان أماكن إقامة الناس وحجم السكان والكثافة والهجرة والأنماط المرتبطة بها.'),
  ],questions:[
    q('What can plate movement cause?','ماذا يمكن أن تسبب حركة الصفائح؟',['Earthquakes','Only rain','Only wind','None'],['الزلازل','المطر فقط','الرياح فقط','لا شيء'],0),
    q('Climate refers mainly to…','المناخ يشير أساسًا إلى…',['Long-term patterns','One hour of weather','One storm','One day'],['الأنماط طويلة المدى','ساعة واحدة من الطقس','عاصفة واحدة','يوم واحد'],0),
    q('Which process removes soil or rock?','أي عملية تزيل التربة أو الصخور؟',['Erosion','Condensation','Freezing only','Illumination'],['التعرية','التكاثف','التجمد فقط','الإضاءة'],0),
    q('Population density means…','الكثافة السكانية تعني…',['People per unit area','Total rainfall','Number of rivers','Height of mountains'],['عدد السكان لكل وحدة مساحة','إجمالي الأمطار','عدد الأنهار','ارتفاع الجبال'],0),
  ]),
  Subject(id:'history',name:lt('History','التاريخ'),colorValue:0xFF6D4C41,icon:'⌂',lessons:[
    lesson('sources','Sources of History','مصادر التاريخ','Primary sources are original evidence from the period studied, such as letters, photographs and official records. Secondary sources interpret primary evidence.','المصادر الأولية أدلة أصلية من الفترة المدروسة مثل الرسائل والصور والسجلات الرسمية. أما الثانوية فتفسر الأدلة الأولية.'),
    lesson('colonial','Colonial Administration','الإدارة الاستعمارية','Colonial powers used different systems of administration, including direct and indirect rule, depending on the territory and period.','استخدمت القوى الاستعمارية أنظمة مختلفة للإدارة، منها الحكم المباشر وغير المباشر، حسب الإقليم والفترة.'),
    lesson('trade','Coastal Trade','التجارة الساحلية','Coastal trade involves exchange of goods between ports and coastal communities. It helped connect inland and overseas markets.','التجارة الساحلية هي تبادل السلع بين الموانئ والمجتمعات الساحلية، وقد ساعدت في ربط الأسواق الداخلية والخارجية.'),
    lesson('education','Modern Education','التعليم الحديث','Modern education introduced organized schools, new subjects, examinations and new forms of professional training in many societies.','أدخل التعليم الحديث المدارس المنظمة والمواد الجديدة والامتحانات وأشكالًا جديدة من التدريب المهني في مجتمعات كثيرة.'),
  ],questions:[
    q('Which is a primary source?','أي مما يلي مصدر أولي؟',['A later textbook','An original letter','A modern summary','A revision guide'],['كتاب مدرسي لاحق','رسالة أصلية','ملخص حديث','دليل مراجعة'],1),
    q('Indirect rule means…','الحكم غير المباشر يعني…',['Using local authorities within a colonial system','No government','Only military rule','Private business rule'],['استخدام سلطات محلية داخل نظام استعماري','عدم وجود حكومة','الحكم العسكري فقط','حكم الشركات الخاصة'],0),
    q('Coastal trade mainly uses…','التجارة الساحلية تعتمد أساسًا على…',['Ports and sea routes','Deserts only','Airports only','Mountain tunnels'],['الموانئ والطرق البحرية','الصحارى فقط','المطارات فقط','الأنفاق الجبلية'],0),
    q('A historian studies evidence to…','يدرس المؤرخ الأدلة من أجل…',['Understand and interpret the past','Predict rainfall only','Build roads','Measure temperature only'],['فهم الماضي وتفسيره','توقع الأمطار فقط','بناء الطرق','قياس الحرارة فقط'],0),
  ]),
  Subject(id:'commerce',name:lt('Commerce','التجارة'),colorValue:0xFFC2185B,icon:'↗',lessons:[
    lesson('trade','Trade','التجارة','Trade is the buying and selling of goods and services. It may be domestic or international.','التجارة هي شراء وبيع السلع والخدمات، وقد تكون داخلية أو دولية.'),
    lesson('business','Business Activities','الأنشطة التجارية','Business activities include production, distribution and the provision of services to satisfy human wants.','تشمل الأنشطة التجارية الإنتاج والتوزيع وتقديم الخدمات لإشباع حاجات الإنسان.'),
    lesson('banking','Banking','المصارف','Banks accept deposits, provide loans and offer payment and other financial services.','تقبل المصارف الودائع وتقدم القروض وخدمات الدفع والخدمات المالية الأخرى.'),
    lesson('insurance','Insurance','التأمين','Insurance is an arrangement that provides financial protection against specified risks in return for a premium.','التأمين ترتيب يوفر حماية مالية من مخاطر محددة مقابل قسط.'),
  ],questions:[
    q('What is international trade?','ما المقصود بالتجارة الدولية؟',['Trade within one family','Trade between countries','Free goods only','No buying or selling'],['تجارة داخل أسرة','تجارة بين الدول','سلع مجانية فقط','دون شراء أو بيع'],1),
    q('Which is a service?','أي مما يلي خدمة؟',['Teaching','Bread','Chair','Phone'],['التدريس','الخبز','الكرسي','الهاتف'],0),
    q('Banks commonly provide…','ماذا تقدم المصارف عادة؟',['Loans','Rain','Crops','Roads'],['القروض','المطر','المحاصيل','الطرق'],0),
    q('Insurance protects mainly against…','التأمين يحمي أساسًا من…',['Specified risks','All exams','School subjects','Weather forecasts only'],['مخاطر محددة','كل الامتحانات','المواد الدراسية','توقعات الطقس فقط'],0),
  ]),
  Subject(id:'account',name:lt('Account','المحاسبة'),colorValue:0xFF3949AB,icon:'▦',lessons:[
    lesson('assets','Assets and Liabilities','الأصول والالتزامات','Assets are resources owned by a business. Liabilities are amounts owed to outsiders. Assets = Capital + Liabilities.','الأصول موارد يمتلكها النشاط التجاري، والالتزامات مبالغ مستحقة للآخرين. الأصول = رأس المال + الالتزامات.'),
    lesson('transactions','Transactions','المعاملات','A transaction is a business event that can be measured in money and affects accounting records.','المعاملة حدث تجاري يمكن قياسه بالنقود ويؤثر في السجلات المحاسبية.'),
    lesson('ledger','Ledger Accounts','حسابات دفتر الأستاذ','A ledger groups transactions into individual accounts so that balances can be determined.','يجمع دفتر الأستاذ المعاملات في حسابات منفصلة حتى يمكن تحديد الأرصدة.'),
    lesson('profit','Profit and Loss','الربح والخسارة','Profit occurs when revenue is greater than expenses. A loss occurs when expenses are greater than revenue.','يحدث الربح عندما تكون الإيرادات أكبر من المصروفات، وتحدث الخسارة عندما تكون المصروفات أكبر من الإيرادات.'),
  ],questions:[
    q('Which equation is correct?','أي معادلة صحيحة؟',['Assets = Capital + Liabilities','Assets = Sales - Cash','Capital = Assets + Sales','Liabilities = Assets + Capital'],['الأصول = رأس المال + الالتزامات','الأصول = المبيعات - النقدية','رأس المال = الأصول + المبيعات','الالتزامات = الأصول + رأس المال'],0),
    q('Which is an asset?','أي مما يلي أصل؟',['Cash owned by the business','Loan owed','Supplier debt','Unpaid bill'],['نقدية يملكها النشاط','قرض مستحق','دين للمورد','فاتورة غير مدفوعة'],0),
    q('Profit equals…','الربح يساوي…',['Revenue - Expenses','Expenses - Revenue','Assets + Liabilities','Capital + Sales'],['الإيرادات - المصروفات','المصروفات - الإيرادات','الأصول + الالتزامات','رأس المال + المبيعات'],0),
    q('A ledger is used to…','يستخدم دفتر الأستاذ من أجل…',['Group transactions into accounts','Predict weather','Teach biology','Store water'],['تجميع المعاملات في حسابات','توقع الطقس','تدريس الأحياء','تخزين الماء'],0),
  ]),
];


final List<Grade> grades = [
  Grade(id: 'p8', name: lt('Primary 8', 'الصف الثامن الأساسي')),
  Grade(id: 's1', name: lt('Senior 1', 'الصف الأول الثانوي')),
  Grade(id: 's2', name: lt('Senior 2', 'الصف الثاني الثانوي')),
  Grade(id: 's3', name: lt('Senior 3', 'الصف الثالث الثانوي')),
];

// Subjects currently included in the first offline curriculum.
// More grade-specific content can be assigned here as the curriculum grows.
final Map<String, List<String>> gradeSubjectIds = {
  'p8': ['mathematics', 'english', 'biology', 'geography'],
  's1': ['mathematics', 'english', 'biology', 'chemistry', 'physics', 'geography', 'history', 'commerce', 'account'],
  's2': ['mathematics', 'english', 'biology', 'chemistry', 'physics', 'geography', 'history', 'commerce', 'account'],
  's3': ['mathematics', 'english', 'biology', 'chemistry', 'physics', 'geography', 'history', 'commerce', 'account'],
};
