
import 'package:flutter/material.dart';
import 'services/admin_analytics.dart';
import 'services/supabase_service.dart';

class AdminAnalyticsPage extends StatefulWidget {
  final bool arabic;
  const AdminAnalyticsPage({super.key,required this.arabic});
  @override State<AdminAnalyticsPage> createState()=>_AdminAnalyticsPageState();
}

class _AdminAnalyticsPageState extends State<AdminAnalyticsPage>{
  Map<String,dynamic> data={};
  List<Map<String,dynamic>> users=[];
  bool loading=true;
  String t(String e,String a)=>widget.arabic?a:e;

  @override void initState(){super.initState();load();}
  Future<void> load() async{
    setState(()=>loading=true);
    try{
      data=await AdminAnalytics.summary();
      users=await AdminAnalytics.users();
    }finally{
      if(mounted)setState(()=>loading=false);
    }
  }

  Widget stat(String title,String value,IconData icon){
    return Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,
      children:[Icon(icon,size:28),const SizedBox(height:10),Text(value,style:Theme.of(context).textTheme.headlineMedium),Text(title)]
    )));
  }

  Future<void> roleDialog(Map<String,dynamic> user) async{
    String role=(user['role']??'student').toString();
    final selected=await showDialog<String>(context:context,builder:(ctx)=>AlertDialog(
      title:Text(t('Change role','تغيير الصلاحية')),
      content:DropdownButtonFormField<String>(
        value:role,
        items:const[
          DropdownMenuItem(value:'student',child:Text('Student')),
          DropdownMenuItem(value:'teacher',child:Text('Teacher')),
          DropdownMenuItem(value:'admin',child:Text('Admin')),
        ],
        onChanged:(v){if(v!=null)role=v;},
      ),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(ctx),child:Text(t('Cancel','إلغاء'))),
        FilledButton(onPressed:()=>Navigator.pop(ctx,role),child:Text(t('Save','حفظ'))),
      ],
    ));
    if(selected!=null){
      try {
        await AdminAnalytics.setRole(user['id'].toString(),selected);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(t('Role updated successfully','تم تحديث الصلاحية بنجاح')),
        ));
        await load();
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(t('Could not update role. Confirm you are an admin and run the v21 SQL migration.',
            'تعذر تحديث الصلاحية. تأكد أنك مدير ونفّذ ترحيل SQL للإصدار 21.')),
        ));
      }
    }
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(t('Admin Analytics','إحصائيات الإدارة')),actions:[
      IconButton(onPressed:load,icon:const Icon(Icons.refresh))
    ]),
    body:loading?const Center(child:CircularProgressIndicator()):RefreshIndicator(
      onRefresh:load,
      child:ListView(padding:const EdgeInsets.all(12),children:[
        GridView.count(
          crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
          childAspectRatio:1.6,
          children:[
            stat(t('Students','الطلاب'),'${data['students']??0}',Icons.school),
            stat(t('Teachers','المعلمون'),'${data['teachers']??0}',Icons.person),
            stat(t('Admins','المديرون'),'${data['admins']??0}',Icons.admin_panel_settings),
            stat(t('Quiz results','نتائج الاختبارات'),'${data['results']??0}',Icons.quiz),
            stat(t('Completed lessons','الدروس المكتملة'),'${data['completed_lessons']??0}',Icons.check_circle),
            stat(t('Average score','متوسط الدرجات'),'${((data['average_score']??0) as num).toStringAsFixed(1)}%',Icons.bar_chart),
          ],
        ),
        const SizedBox(height:16),
        Text(t('Users','المستخدمون'),style:Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height:8),
        ...users.map((u)=>Card(child:ListTile(
          leading:CircleAvatar(child:Text((u['name']??'U').toString().isEmpty?'U':(u['name']??'U').toString()[0].toUpperCase())),
          title:Text((u['name']??'User').toString()),
          subtitle:Text('${u['role']??'student'}  •  ${u['grade_id']??''}'),
          trailing:PopupMenuButton<String>(
            onSelected:(v)=>roleDialog({...u,'role':v}),
            itemBuilder:(_)=>const[
              PopupMenuItem(value:'student',child:Text('Student')),
              PopupMenuItem(value:'teacher',child:Text('Teacher')),
              PopupMenuItem(value:'admin',child:Text('Admin')),
            ],
          ),
        ))),
      ]),
    ),
  );
}
