import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'data/app_data.dart';
import 'models/models.dart';
import 'services/supabase_service.dart';
import 'services/student_exam_service.dart';

class StudentProfilePage extends StatefulWidget {
  final bool arabic;
  final String gradeId;
  const StudentProfilePage({super.key, required this.arabic, required this.gradeId});
  @override State<StudentProfilePage> createState() => _StudentProfilePageState();
}

class _StudentProfilePageState extends State<StudentProfilePage> {
  bool loading = true;
  bool syncing = false;
  Map<String, dynamic>? profile;
  List<Map<String, dynamic>> progress = [];
  List<Map<String, dynamic>> results = [];
  List<Map<String, dynamic>> attempts = [];
  String? error;
  String? notice;
  String t(String en, String ar) => widget.arabic ? ar : en;

  @override void initState() { super.initState(); load(); }

  Future<void> load() async {
    if (mounted) setState(() { loading = true; error = null; });
    try {
      if (SupabaseService.configured && SupabaseService.currentUser != null) {
        profile = await SupabaseService.getProfile();
        progress = await SupabaseService.getProgress();
        results = await SupabaseService.getResults();
        attempts = await StudentExamService.myAttempts();
      } else {
        profile = null; progress = []; results = []; attempts = [];
      }
    } catch (_) {
      error = t('Could not load account data. Check your connection and Supabase setup.',
          'تعذر تحميل بيانات الحساب. تحقق من الإنترنت وإعدادات Supabase.');
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _editProfile() async {
    final user = SupabaseService.currentUser;
    if (user == null || !SupabaseService.configured) return;
    final nameController = TextEditingController(
      text: (profile?['full_name'] ?? profile?['name'] ?? user.userMetadata?['full_name'] ?? '').toString(),
    );
    String selectedGrade = (profile?['grade_id'] ?? widget.gradeId).toString();
    if (!grades.any((g) => g.id == selectedGrade)) selectedGrade = widget.gradeId;
    final result = await showDialog<Map<String, String>>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(t('Edit profile', 'تعديل الملف الشخصي')),
          content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: nameController,
              textCapitalization: TextCapitalization.words,
              decoration: InputDecoration(
                labelText: t('Full name', 'الاسم الكامل'),
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 14),
            DropdownButtonFormField<String>(
              value: selectedGrade,
              decoration: InputDecoration(
                labelText: t('Class', 'الصف'),
                border: const OutlineInputBorder(),
              ),
              items: grades.map((Grade g) => DropdownMenuItem<String>(
                value: g.id,
                child: Text(g.name.get(widget.arabic)),
              )).toList(),
              onChanged: (value) {
                if (value != null) setDialogState(() => selectedGrade = value);
              },
            ),
          ])),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text(t('Cancel', 'إلغاء'))),
            FilledButton(
              onPressed: () {
                if (nameController.text.trim().isEmpty) return;
                Navigator.pop(dialogContext, {
                  'name': nameController.text.trim(),
                  'grade': selectedGrade,
                });
              },
              child: Text(t('Save', 'حفظ')),
            ),
          ],
        ),
      ),
    );
    if (result == null) {
      nameController.dispose();
      return;
    }
    try {
      await SupabaseService.updateStudentProfile(
        fullName: result['name']!,
        gradeId: result['grade']!,
      );
      if (mounted) {
        setState(() => notice = t('Profile updated.', 'تم تحديث الملف الشخصي.'));
        await load();
      }
    } catch (_) {
      if (mounted) setState(() => error = t('Could not update profile. Check your connection and database migration.',
          'تعذر تحديث الملف الشخصي. تحقق من الاتصال وتحديث قاعدة البيانات.'));
    } finally {
      nameController.dispose();
    }
  }

  Future<void> _syncLocalLessons() async {
    if (!SupabaseService.configured || SupabaseService.currentUser == null) return;
    setState(() { syncing = true; error = null; notice = null; });
    try {
      final prefs = await SharedPreferences.getInstance();
      final ids = <String>[];
      for (final subject in subjects) {
        for (final lesson in subject.lessons) {
          if (prefs.getBool('lesson_done_${lesson.id}') ?? false) ids.add(lesson.id);
        }
      }
      await SupabaseService.syncCompletedLessons(ids);
      if (mounted) setState(() => notice = t(
        'Synced ${ids.length} completed local lessons to your account.',
        'تمت مزامنة ${ids.length} درسًا مكتملًا من هذا الجهاز إلى حسابك.',
      ));
      await load();
    } catch (_) {
      if (mounted) setState(() => error = t(
        'Sync failed. Confirm the latest Supabase schema and internet connection.',
        'فشلت المزامنة. تحقق من تحديث قاعدة بيانات Supabase والاتصال بالإنترنت.',
      ));
    } finally {
      if (mounted) setState(() => syncing = false);
    }
  }

  @override Widget build(BuildContext context) {
    final user = SupabaseService.currentUser;
    final metadata = user?.userMetadata ?? <String, dynamic>{};
    final name = (profile?['full_name'] ?? profile?['name'] ?? metadata['full_name'] ?? t('Student', 'طالب')).toString();
    final email = user?.email ?? t('Not signed in', 'لم يتم تسجيل الدخول');
    final gradeId = (profile?['grade_id'] ?? widget.gradeId).toString();
    final grade = grades.where((g) => g.id == gradeId).isEmpty
        ? gradeId : grades.firstWhere((g) => g.id == gradeId).name.get(widget.arabic);
    final isConnected = SupabaseService.configured && user != null;

    return Directionality(
      textDirection: widget.arabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: Text(t('My Profile', 'ملفي الشخصي')),
          actions: [
            IconButton(onPressed: load, icon: const Icon(Icons.refresh), tooltip: t('Refresh', 'تحديث')),
          ],
        ),
        body: loading ? const Center(child: CircularProgressIndicator()) : ListView(
          padding: const EdgeInsets.all(18), children: [
            Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
              const CircleAvatar(radius: 36, child: Icon(Icons.person, size: 38)),
              const SizedBox(height: 12),
              Text(name, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4), Text(email, textAlign: TextAlign.center),
              const SizedBox(height: 10),
              Chip(avatar: const Icon(Icons.school_outlined), label: Text('${t('Class', 'الصف')}: $grade')),
              if (isConnected)
                OutlinedButton.icon(
                  onPressed: _editProfile,
                  icon: const Icon(Icons.edit_outlined),
                  label: Text(t('Edit profile', 'تعديل الملف الشخصي')),
                ),
            ]))),
            if (!isConnected) Card(child: ListTile(
              leading: const Icon(Icons.cloud_off_outlined),
              title: Text(t('Online account not connected', 'الحساب الإلكتروني غير متصل')),
              subtitle: Text(t('Local lessons still work. Configure Supabase and sign in to sync your profile, progress and exam results.',
                  'يمكنك مواصلة الدروس المحلية. أعد إعداد Supabase وسجّل الدخول لمزامنة الملف الشخصي والتقدم ونتائج الامتحانات.')),
            )),
            if (notice != null) Card(child: ListTile(leading: const Icon(Icons.check_circle_outline), title: Text(notice!))),
            if (error != null) Card(child: ListTile(leading: const Icon(Icons.error_outline), title: Text(error!))),
            if (isConnected) Card(child: ListTile(
              leading: const Icon(Icons.sync),
              title: Text(t('Sync local lesson progress', 'مزامنة تقدم الدروس المحلية')),
              subtitle: Text(t('Upload completed lessons saved on this device.', 'ارفع الدروس المكتملة المحفوظة على هذا الجهاز.')),
              trailing: syncing
                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.chevron_right),
              onTap: syncing ? null : _syncLocalLessons,
            )),
            const SizedBox(height: 8),
            Text(t('Learning summary', 'ملخص التعلم'), style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            _stat(context, Icons.check_circle_outline, t('Completed lessons', 'الدروس المكتملة'), '${progress.length}'),
            _stat(context, Icons.quiz_outlined, t('Practice quiz results', 'نتائج الاختبارات التدريبية'), '${results.length}'),
            _stat(context, Icons.assignment_turned_in_outlined, t('Online exam attempts', 'محاولات الامتحانات الإلكترونية'), '${attempts.length}'),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: isConnected ? () async {
                try {
                  await SupabaseService.signOut();
                  if (mounted) await load();
                } catch (_) {
                  if (mounted) setState(() => error = t('Sign out failed.', 'تعذر تسجيل الخروج.'));
                }
              } : null,
              icon: const Icon(Icons.logout),
              label: Text(t('Sign out', 'تسجيل الخروج')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(BuildContext context, IconData icon, String label, String value) => Card(
    child: ListTile(
      leading: Icon(icon), title: Text(label),
      trailing: Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
    ),
  );
}
