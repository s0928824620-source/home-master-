
import 'package:flutter/material.dart';
import '../services/admin_service.dart';
import '../services/supabase_service.dart';

class AdminDashboardPage extends StatefulWidget {
  final bool arabic;
  const AdminDashboardPage({super.key, required this.arabic});

  @override
  State<AdminDashboardPage> createState() => _AdminDashboardPageState();
}

class _AdminDashboardPageState extends State<AdminDashboardPage> {
  final _subjectController = TextEditingController();
  String? _subjectId;
  List<Map<String,dynamic>> _lessons = [];
  bool _loading = true;
  String? _role;

  String t(String en, String ar) => widget.arabic ? ar : en;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _subjectController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final profile = await SupabaseService.getProfile();
    _role = profile?['role']?.toString();
    _lessons = await AdminService.lessons(
      subjectId: _subjectId,
    );
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _editLesson([Map<String,dynamic>? lesson]) async {
    final enTitle = TextEditingController(text: lesson?['title_en'] ?? '');
    final arTitle = TextEditingController(text: lesson?['title_ar'] ?? '');
    final enContent = TextEditingController(text: lesson?['content_en'] ?? '');
    final arContent = TextEditingController(text: lesson?['content_ar'] ?? '');

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(lesson == null ? t('Add Lesson','إضافة درس') : t('Edit Lesson','تعديل الدرس')),
        content: SingleChildScrollView(
          child: Column(children: [
            TextField(controller: enTitle, decoration: const InputDecoration(labelText: 'Title (English)')),
            TextField(controller: arTitle, decoration: const InputDecoration(labelText: 'العنوان (العربية)')),
            TextField(controller: enContent, minLines: 4, maxLines: 8, decoration: const InputDecoration(labelText: 'Content (English)')),
            TextField(controller: arContent, minLines: 4, maxLines: 8, decoration: const InputDecoration(labelText: 'المحتوى (العربية)')),
          ]),
        ),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(context,false), child: Text(t('Cancel','إلغاء'))),
          FilledButton(onPressed: ()=>Navigator.pop(context,true), child: Text(t('Save','حفظ'))),
        ],
      ),
    );

    if (ok != true) return;
    if (_subjectId == null || _subjectId!.isEmpty) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(t('Enter a Subject ID first.','أدخل معرف المادة أولاً.')))
      );
      return;
    }

    try {
      if (lesson == null) {
        await AdminService.createLesson(
          subjectId: _subjectId!,
          titleEn: enTitle.text.trim(),
          titleAr: arTitle.text.trim(),
          contentEn: enContent.text.trim(),
          contentAr: arContent.text.trim(),
        );
      } else {
        await AdminService.updateLesson(
          id: lesson['id'].toString(),
          titleEn: enTitle.text.trim(),
          titleAr: arTitle.text.trim(),
          contentEn: enContent.text.trim(),
          contentAr: arContent.text.trim(),
        );
      }
      await _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  Future<void> _deleteLesson(Map<String,dynamic> lesson) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(t('Delete lesson?','حذف الدرس؟')),
        content: Text((lesson['title_en'] ?? lesson['title_ar'] ?? '').toString()),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(context,false), child: Text(t('Cancel','إلغاء'))),
          FilledButton(onPressed: ()=>Navigator.pop(context,true), child: Text(t('Delete','حذف'))),
        ],
      ),
    );
    if (ok == true) {
      await AdminService.deleteLesson(lesson['id'].toString());
      await _load();
    }
  }

  Future<void> _questions(Map<String,dynamic> lesson) async {
    await Navigator.push(context, MaterialPageRoute(
      builder: (_) => QuestionEditorPage(
        arabic: widget.arabic,
        lesson: lesson,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final staff = _role == 'teacher' || _role == 'admin';
    return Scaffold(
      appBar: AppBar(
        title: Text(t('Teacher / Admin','المعلم / الإدارة')),
      ),
      floatingActionButton: staff ? FloatingActionButton.extended(
        onPressed: ()=>_editLesson(),
        icon: const Icon(Icons.add),
        label: Text(t('Lesson','درس')),
      ) : null,
      body: !SupabaseService.configured
        ? Center(child: Text(t('Configure Supabase first.','قم بإعداد Supabase أولاً.')))
        : !staff
          ? Center(child: Text(t('Staff access required.','تحتاج إلى صلاحية معلم أو مدير.')))
          : Column(children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: Row(children: [
                  Expanded(child: TextField(
                    controller: _subjectController,
                    decoration: InputDecoration(
                      labelText: t('Subject ID','معرف المادة'),
                      hintText: 'mathematics',
                      suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: (){
                        _subjectId = _subjectController.text.trim();
                        _load();
                      }),
                    ),
                    onSubmitted: (v){ _subjectId=v.trim(); _load(); },
                  )),
                ]),
              ),
              Expanded(
                child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _lessons.isEmpty
                    ? Center(child: Text(t('No lessons found.','لا توجد دروس.')))
                    : ListView.builder(
                        itemCount: _lessons.length,
                        itemBuilder: (_, i) {
                          final l = _lessons[i];
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                            child: ListTile(
                              title: Text((widget.arabic ? l['title_ar'] : l['title_en'])?.toString() ?? ''),
                              subtitle: Text(l['id'].toString()),
                              trailing: PopupMenuButton<String>(
                                onSelected: (v){
                                  if(v=='edit') _editLesson(l);
                                  if(v=='questions') _questions(l);
                                  if(v=='delete') _deleteLesson(l);
                                },
                                itemBuilder: (_) => [
                                  PopupMenuItem(value:'edit', child: Text(t('Edit','تعديل'))),
                                  PopupMenuItem(value:'questions', child: Text(t('Questions','الأسئلة'))),
                                  PopupMenuItem(value:'delete', child: Text(t('Delete','حذف'))),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ]),
    );
  }
}

class QuestionEditorPage extends StatefulWidget {
  final bool arabic;
  final Map<String,dynamic> lesson;
  const QuestionEditorPage({super.key, required this.arabic, required this.lesson});
  @override
  State<QuestionEditorPage> createState() => _QuestionEditorPageState();
}

class _QuestionEditorPageState extends State<QuestionEditorPage> {
  List<Map<String,dynamic>> _questions = [];
  bool _loading = true;
  String t(String en,String ar)=>widget.arabic?ar:en;

  @override void initState(){super.initState(); _load();}
  Future<void> _load() async {
    setState(()=>_loading=true);
    _questions=await AdminService.questions(widget.lesson['id'].toString());
    if(mounted)setState(()=>_loading=false);
  }

  Future<void> _edit([Map<String,dynamic>? q]) async {
    final en=TextEditingController(text:q?['text_en']??'');
    final ar=TextEditingController(text:q?['text_ar']??'');
    final oe=List.generate(4,(i)=>TextEditingController(text:((q?['options_en'] as List?)?[i]??'').toString()));
    final oa=List.generate(4,(i)=>TextEditingController(text:((q?['options_ar'] as List?)?[i]??'').toString()));
    int correct=(q?['correct_index']??0) as int;

    final ok=await showDialog<bool>(context:context,builder:(_)=>StatefulBuilder(builder:(ctx,setLocal)=>AlertDialog(
      title:Text(q==null?t('Add Question','إضافة سؤال'):t('Edit Question','تعديل السؤال')),
      content:SingleChildScrollView(child:Column(children:[
        TextField(controller:en,minLines:2,maxLines:4,decoration:const InputDecoration(labelText:'Question (English)')),
        TextField(controller:ar,minLines:2,maxLines:4,decoration:const InputDecoration(labelText:'السؤال (العربية)')),
        for(int i=0;i<4;i++) Row(children:[
          Radio<int>(value:i,groupValue:correct,onChanged:(v)=>setLocal(()=>correct=v??0)),
          Expanded(child:TextField(controller:oe[i],decoration:InputDecoration(labelText:'Option ${String.fromCharCode(65+i)} (EN)'))),
          const SizedBox(width:8),
          Expanded(child:TextField(controller:oa[i],decoration:InputDecoration(labelText:'الخيار ${String.fromCharCode(65+i)} (AR)'))),
        ]),
      ])),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(ctx,false),child:Text(t('Cancel','إلغاء'))),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:Text(t('Save','حفظ'))),
      ],
    )));
    if(ok!=true)return;
    try{
      if(q==null){
        await AdminService.createQuestion(
          lessonId:widget.lesson['id'].toString(),
          textEn:en.text.trim(), textAr:ar.text.trim(),
          optionsEn:oe.map((x)=>x.text.trim()).toList(),
          optionsAr:oa.map((x)=>x.text.trim()).toList(),
          correctIndex:correct,
        );
      }else{
        await AdminService.updateQuestion(
          id:q['id'].toString(),
          textEn:en.text.trim(), textAr:ar.text.trim(),
          optionsEn:oe.map((x)=>x.text.trim()).toList(),
          optionsAr:oa.map((x)=>x.text.trim()).toList(),
          correctIndex:correct,
        );
      }
      await _load();
    }catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));
    }
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(t('Questions','الأسئلة'))),
    floatingActionButton:FloatingActionButton.extended(onPressed:()=>_edit(),icon:const Icon(Icons.add),label:Text(t('Question','سؤال'))),
    body:_loading?const Center(child:CircularProgressIndicator()):ListView.builder(
      itemCount:_questions.length,
      itemBuilder:(_,i){
        final q=_questions[i];
        return Card(child:ListTile(
          title:Text((widget.arabic?q['text_ar']:q['text_en'])?.toString()??''),
          subtitle:Text('${t('Correct option','الإجابة الصحيحة')}: ${(q['correct_index']??0)+1}'),
          trailing:PopupMenuButton<String>(onSelected:(v)async{
            if(v=='edit')await _edit(q);
            if(v=='delete'){await AdminService.deleteQuestion(q['id'].toString());await _load();}
          },itemBuilder:(_)=>[
            PopupMenuItem(value:'edit',child:Text(t('Edit','تعديل'))),
            PopupMenuItem(value:'delete',child:Text(t('Delete','حذف'))),
          ]),
        ));
      },
    ),
  );
}
