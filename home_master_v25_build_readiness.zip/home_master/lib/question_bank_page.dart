
import 'package:flutter/material.dart';
import 'services/exam_question_service.dart';

class QuestionBankPage extends StatefulWidget {
  final String examId,subjectId;
  final bool arabic;
  const QuestionBankPage({super.key,required this.examId,required this.subjectId,required this.arabic});
  @override State<QuestionBankPage> createState()=>_QuestionBankPageState();
}

class _QuestionBankPageState extends State<QuestionBankPage>{
  List<Map<String,dynamic>> all=[],selected=[];
  bool loading=true,saving=false;
  String t(String e,String a)=>widget.arabic?a:e;

  @override void initState(){super.initState();load();}
  Future<void> load()async{
    try{
      final q=await ExamQuestionService.questions(widget.subjectId);
      final eq=await ExamQuestionService.examQuestions(widget.examId);
      final ids=eq.map((x)=>x['question_id'].toString()).toSet();
      if(mounted)setState((){
        all=q; selected=q.where((x)=>ids.contains(x['id'].toString())).toList(); loading=false;
      });
    }catch(_){if(mounted)setState(()=>loading=false);}
  }

  Future<void> save()async{
    setState(()=>saving=true);
    await ExamQuestionService.setQuestions(widget.examId,selected.map((x)=>x['id'].toString()).toList());
    if(mounted){
      setState(()=>saving=false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(t('Saved','تم الحفظ'))));
    }
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(
      title:Text(t('Question Bank','بنك الأسئلة')),
      actions:[IconButton(onPressed:saving?null:save,icon:const Icon(Icons.save))]
    ),
    body:loading?const Center(child:CircularProgressIndicator()):ListView(
      padding:const EdgeInsets.all(12),
      children:[
        Text(t('Selected questions: ${selected.length}','الأسئلة المختارة: ${selected.length}'),
          style:Theme.of(context).textTheme.titleLarge),
        const SizedBox(height:10),
        ...all.map((q){
          final checked=selected.any((x)=>x['id']==q['id']);
          final text=(widget.arabic?(q['text_ar']??q['text_en']):(q['text_en']??q['text_ar'])).toString();
          return Card(child:CheckboxListTile(
            value:checked,
            title:Text(text),
            onChanged:(v){
              setState((){
                if(v==true)selected.add(q);
                else selected.removeWhere((x)=>x['id']==q['id']);
              });
            },
          ));
        })
      ],
    ),
  );
}
