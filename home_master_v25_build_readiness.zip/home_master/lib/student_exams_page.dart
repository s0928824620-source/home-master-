
import 'package:flutter/material.dart';
import 'exam_page.dart';
import 'services/student_exam_service.dart';
import 'services/exam_question_service.dart';
class StudentExamsPage extends StatefulWidget {
 final bool arabic; final String? gradeId;
 const StudentExamsPage({super.key,required this.arabic,this.gradeId});
 @override State<StudentExamsPage> createState()=>_StudentExamsPageState();
}
class _StudentExamsPageState extends State<StudentExamsPage>{
 List<Map<String,dynamic>> exams=[]; bool loading=true;
 String t(String e,String a)=>widget.arabic?a:e;
 @override void initState(){super.initState();load();}
 Future<void> load()async{try{exams=await StudentExamService.availableExams(gradeId:widget.gradeId);}catch(_){} if(mounted)setState(()=>loading=false);}
 Future<void> start(Map<String,dynamic> e)async{
  final links=await ExamQuestionService.examQuestions(e['id'].toString());
  final qs=links.map((x)=>Map<String,dynamic>.from(x['questions'] as Map)).toList();
  final exam=Map<String,dynamic>.from(e)..['questions']=qs;
  if(mounted)await Navigator.push(context,MaterialPageRoute(builder:(_)=>ExamPage(exam:exam,arabic:widget.arabic)));
 }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(t('Available Exams','الامتحانات المتاحة')),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),body:loading?const Center(child:CircularProgressIndicator()):exams.isEmpty?Center(child:Text(t('No published exams yet.','لا توجد امتحانات منشورة حالياً.'))):ListView(children:exams.map((e)=>Card(child:ListTile(leading:const Icon(Icons.assignment),title:Text((widget.arabic?e['title_ar']:e['title_en']).toString()),subtitle:Text('${e['subject_id']} • ${e['question_count']} ${t('questions','أسئلة')} • ${e['duration_minutes']} ${t('minutes','دقيقة')}'),trailing:FilledButton(onPressed:()=>start(e),child:Text(t('Start','ابدأ'))))).toList()));
}
