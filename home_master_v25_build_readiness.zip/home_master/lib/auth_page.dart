import 'package:flutter/material.dart';
import 'services/supabase_service.dart';

class AuthPage extends StatefulWidget {
  final bool arabic;
  final String gradeId;
  const AuthPage({super.key, required this.arabic, required this.gradeId});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _creating = false;
  bool _busy = false;
  bool _hidePassword = true;
  String? _message;
  bool _error = false;

  String t(String en, String ar) => widget.arabic ? ar : en;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (!SupabaseService.configured) {
      setState(() {
        _error = true;
        _message = t(
          'Online accounts are not configured yet. Add your Supabase URL and publishable key, then run the SQL setup.',
          'الحسابات الإلكترونية غير مهيأة بعد. أضف رابط Supabase ومفتاح النشر ثم نفّذ إعدادات SQL.',
        );
      });
      return;
    }

    setState(() { _busy = true; _message = null; });
    try {
      if (_creating) {
        await SupabaseService.signUp(
          _email.text.trim(),
          _password.text,
          _name.text.trim(),
          widget.gradeId,
        );
        setState(() {
          _error = false;
          _message = t(
            'Account request submitted. If email confirmation is enabled, check your inbox before signing in.',
            'تم إرسال طلب إنشاء الحساب. إذا كان تأكيد البريد مفعّلًا، افحص بريدك قبل تسجيل الدخول.',
          );
        });
      } else {
        await SupabaseService.signIn(_email.text.trim(), _password.text);
        if (mounted) {
          setState(() {
            _error = false;
            _message = t('You are signed in successfully.', 'تم تسجيل الدخول بنجاح.');
          });
        }
      }
    } catch (e) {
      setState(() {
        _error = true;
        _message = t(
          'Could not complete the request. Check your email, password, internet connection and Supabase setup.',
          'تعذر إكمال العملية. تحقق من البريد وكلمة المرور والإنترنت وإعدادات Supabase.',
        );
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ar = widget.arabic;
    return Directionality(
      textDirection: ar ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(t('Student account', 'حساب الطالب'))),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 12),
            const CircleAvatar(radius: 34, child: Icon(Icons.school_outlined, size: 36)),
            const SizedBox(height: 14),
            Text(
              t('Welcome to Home Master', 'مرحبًا بك في هوم ماستر'),
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              t('Sign in to sync your learning progress across devices.', 'سجّل الدخول لمزامنة تقدمك الدراسي بين الأجهزة.'),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 22),
            if (!SupabaseService.configured)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: Text(t('Setup required', 'الإعداد مطلوب')),
                  subtitle: Text(t(
                    'The app can still be used for local lessons. Online sign-in needs Supabase configuration.',
                    'يمكنك استخدام الدروس المحلية. تسجيل الدخول الإلكتروني يحتاج إلى إعداد Supabase.',
                  )),
                ),
              ),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  if (_creating)
                    TextFormField(
                      controller: _name,
                      textCapitalization: TextCapitalization.words,
                      decoration: InputDecoration(
                        labelText: t('Full name', 'الاسم الكامل'),
                        prefixIcon: const Icon(Icons.person_outline),
                        border: const OutlineInputBorder(),
                      ),
                      validator: (v) => _creating && (v == null || v.trim().isEmpty)
                          ? t('Enter your name', 'أدخل اسمك')
                          : null,
                    ),
                  if (_creating) const SizedBox(height: 14),
                  TextFormField(
                    controller: _email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                      labelText: t('Email address', 'البريد الإلكتروني'),
                      prefixIcon: const Icon(Icons.email_outlined),
                      border: const OutlineInputBorder(),
                    ),
                    validator: (v) {
                      if (v == null || !v.contains('@') || !v.contains('.')) {
                        return t('Enter a valid email', 'أدخل بريدًا إلكترونيًا صحيحًا');
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _password,
                    obscureText: _hidePassword,
                    decoration: InputDecoration(
                      labelText: t('Password (at least 6 characters)', 'كلمة المرور (6 أحرف على الأقل)'),
                      prefixIcon: const Icon(Icons.lock_outline),
                      suffixIcon: IconButton(
                        onPressed: () => setState(() => _hidePassword = !_hidePassword),
                        icon: Icon(_hidePassword ? Icons.visibility : Icons.visibility_off),
                      ),
                      border: const OutlineInputBorder(),
                    ),
                    validator: (v) => (v == null || v.length < 6)
                        ? t('Use at least 6 characters', 'استخدم 6 أحرف على الأقل')
                        : null,
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: _busy ? null : _submit,
                      child: _busy
                          ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                          : Text(_creating ? t('Create account', 'إنشاء حساب') : t('Sign in', 'تسجيل الدخول')),
                    ),
                  ),
                ],
              ),
            ),
            if (_message != null) ...[
              const SizedBox(height: 14),
              Card(
                child: ListTile(
                  leading: Icon(_error ? Icons.error_outline : Icons.check_circle_outline),
                  title: Text(_message!),
                ),
              ),
            ],
            TextButton(
              onPressed: _busy ? null : () => setState(() { _creating = !_creating; _message = null; }),
              child: Text(_creating
                  ? t('Already have an account? Sign in', 'لديك حساب؟ سجّل الدخول')
                  : t('New student? Create an account', 'طالب جديد؟ أنشئ حسابًا')),
            ),
            const SizedBox(height: 6),
            OutlinedButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.arrow_back),
              label: Text(t('Continue learning', 'متابعة التعلم')),
            ),
          ],
        ),
      ),
    );
  }
}
