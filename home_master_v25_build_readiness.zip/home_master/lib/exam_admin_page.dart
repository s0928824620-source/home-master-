
import 'package:flutter/material.dart';
import 'services/exam_service.dart';

class ExamAdminPage extends StatefulWidget {
  final bool arabic;
  const ExamAdminPage({super.key,required this.arabic});
  @override State<ExamAdminPage> createState()=>_ExamAdminPageState();
}

class _ExamAdminPageState extends State<ExamAdminPage> {
  final en=TextEditingController(), ar=TextEditingController();
  final grade=TextEditingController(text:'s1');
  final subject=TextEditingController(text:'mathematics');
  final duration=TextEditingController(text:'30');
  final count=TextEditingController(text:'10');
  bool busy=false;

  String t(String e,String a)=>widget.arabic?a:e;

  Future<void> create()async{
    setState(()=>busy=true);
    try{
      await ExamService.createExam(
        titleEn:en.text,titleAr:ar.text,
        gradeId:grade.text,subjectId:subject.text,
        durationMinutes:int.tryParse(duration.text)??30,
        questionCount:int.tryParse(count.text)??10,
      );
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content:Text(t('Exam created.','تم إنشاء الامتحان.')))
      );
      en.clear(); ar.clear();
    }finally{
      if(mounted)setState(()=>busy=false);
    }
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(t('Exam Management','إدارة الامتحانات'))),
    body:ListView(
      padding:const EdgeInsets.all(16),
      children:[
        TextField(controller:en,decoration:InputDecoration(labelText:t('English title','العنوان الإنجليزي'))),
        TextField(controller:ar,decoration:InputDecoration(labelText:t('Arabic title','العنوان العربي'))),
        TextField(controller:grade,decoration:const InputDecoration(labelText:'Grade ID')),
        TextField(controller:subject,decoration:const InputDecoration(labelText:'Subject ID')),
        TextField(controller:duration,keyboardType:TextInputType.number,
          decoration:InputDecoration(labelText:t('Duration (minutes)','المدة بالدقائق'))),
        TextField(controller:count,keyboardType:TextInputType.number,
          decoration:InputDecoration(labelText:t('Number of questions','عدد الأسئلة'))),
        const SizedBox(height:20),
        FilledButton(onPressed:busy?null:create,child:Text(t('Create exam','إنشاء الامتحان'))),
      ],
    ),
  );
}
