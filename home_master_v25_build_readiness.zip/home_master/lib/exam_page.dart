
import 'dart:async';
import 'package:flutter/material.dart';
import 'services/exam_service.dart';

class ExamPage extends StatefulWidget {
  final Map<String,dynamic> exam;
  final bool arabic;
  const ExamPage({super.key,required this.exam,required this.arabic});
  @override State<ExamPage> createState()=>_ExamPageState();
}

class _ExamPageState extends State<ExamPage> {
  int index=0, correct=0;
  late int seconds;
  Timer? timer;
  DateTime? started;
  late List<Map<String,dynamic>> questions;
  final Map<int,int> answers={};

  String t(String e,String a)=>widget.arabic?a:e;

  @override void initState(){
    super.initState();
    seconds=((widget.exam['duration_minutes']??30) as num).toInt()*60;
    questions=List<Map<String,dynamic>>.from(widget.exam['questions']??[]);
    started=DateTime.now();
    timer=Timer.periodic(const Duration(seconds:1),(x){
      if(!mounted)return;
      if(seconds<=0){x.cancel();finish();}
      else setState(()=>seconds--);
    });
  }

  @override void dispose(){timer?.cancel();super.dispose();}

  String clock()=>'${(seconds~/60).toString().padLeft(2,'0')}:${(seconds%60).toString().padLeft(2,'0')}';

  Future<void> finish() async {
    timer?.cancel();
    correct=0;
    for(int i=0;i<questions.length;i++){
      if(answers[i]==questions[i]['correct_index']) correct++;
    }
    final total=questions.length;
    try {
      await ExamService.submitAttempt(
        examId:widget.exam['id'].toString(),
        subjectId:widget.exam['subject_id'].toString(),
        score:correct,total:total,
        durationSeconds:DateTime.now().difference(started!).inSeconds,
      );
    } catch (_) {}
    if(!mounted)return;
    await showDialog(
      context:context,barrierDismissible:false,
      builder:(_)=>AlertDialog(
        title:Text(t('Exam completed','اكتمل الامتحان')),
        content:Text('$correct / $total\n${total==0?0:(correct/total*100).toStringAsFixed(1)}%'),
        actions:[FilledButton(
          onPressed:()=>Navigator.pop(context),
          child:Text(t('Done','تم')),
        )],
      ),
    );
    if(mounted)Navigator.pop(context);
  }

  @override Widget build(BuildContext context){
    if(questions.isEmpty){
      return Scaffold(
        appBar:AppBar(title:Text(t('Exam','الامتحان'))),
        body:Center(child:Text(t('No questions available.','لا توجد أسئلة متاحة.'))),
      );
    }
    final q=questions[index];
    final options=List<String>.from(q['options']??[]);
    final questionText=(widget.arabic?(q['text_ar']??q['text_en']):(q['text_en']??q['text_ar'])).toString();

    return Scaffold(
      appBar:AppBar(
        title:Text((widget.arabic?(widget.exam['title_ar']??'Exam'):(widget.exam['title_en']??'Exam')).toString()),
        actions:[Padding(
          padding:const EdgeInsets.all(16),
          child:Center(child:Text(clock(),style:const TextStyle(fontWeight:FontWeight.bold))),
        )],
      ),
      body:ListView(
        padding:const EdgeInsets.all(16),
        children:[
          LinearProgressIndicator(value:(index+1)/questions.length),
          const SizedBox(height:16),
          Text('${index+1} / ${questions.length}'),
          const SizedBox(height:12),
          Text(questionText,style:Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height:18),
          ...List.generate(options.length,(i)=>Card(
            child:RadioListTile<int>(
              value:i,groupValue:answers[index],
              title:Text(options[i]),
              onChanged:(v)=>setState(()=>answers[index]=v!),
            ),
          )),
          const SizedBox(height:18),
          Row(children:[
            if(index>0)Expanded(
              child:OutlinedButton(
                onPressed:()=>setState(()=>index--),
                child:Text(t('Previous','السابق')),
              ),
            ),
            if(index>0)const SizedBox(width:8),
            Expanded(
              child:FilledButton(
                onPressed:(){
                  if(index<questions.length-1)setState(()=>index++);
                  else finish();
                },
                child:Text(index<questions.length-1?t('Next','التالي'):t('Finish','إنهاء')),
              ),
            ),
          ]),
        ],
      ),
    );
  }
}
