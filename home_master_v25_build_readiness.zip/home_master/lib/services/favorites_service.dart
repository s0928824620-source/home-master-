
import 'package:shared_preferences/shared_preferences.dart';

class FavoritesService {
  static const _key = 'favorite_lessons';

  static Future<Set<String>> getAll() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList(_key) ?? const <String>[]).toSet();
  }

  static Future<bool> isFavorite(String lessonId) async {
    final all = await getAll();
    return all.contains(lessonId);
  }

  static Future<bool> toggle(String lessonId) async {
    final p = await SharedPreferences.getInstance();
    final all = (p.getStringList(_key) ?? <String>[]).toSet();
    final nowFavorite = !all.contains(lessonId);
    if (nowFavorite) {
      all.add(lessonId);
    } else {
      all.remove(lessonId);
    }
    await p.setStringList(_key, all.toList());
    return nowFavorite;
  }
}
