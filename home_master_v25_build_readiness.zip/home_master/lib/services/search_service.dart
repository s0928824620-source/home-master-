
import '../data/app_data.dart';
import '../models/models.dart';
import 'supabase_service.dart';

class SearchHit {
  final String type;
  final String id;
  final String titleEn;
  final String titleAr;
  final String parentId;

  SearchHit({
    required this.type,
    required this.id,
    required this.titleEn,
    required this.titleAr,
    required this.parentId,
  });
}

class SearchService {
  static Future<List<SearchHit>> search(String query, {String? gradeId}) async {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return [];

    if (SupabaseService.configured) {
      try {
        var rows = await SupabaseService.client
            .from('lessons')
            .select('id, subject_id, title_en, title_ar, content_en, content_ar');

        final hits = <SearchHit>[];
        for (final r in rows) {
          final hay = '${r['title_en']} ${r['title_ar']} ${r['content_en']} ${r['content_ar']}'
              .toString()
              .toLowerCase();
          if (hay.contains(q)) {
            hits.add(SearchHit(
              type: 'lesson',
              id: r['id'].toString(),
              titleEn: r['title_en'].toString(),
              titleAr: r['title_ar'].toString(),
              parentId: r['subject_id'].toString(),
            ));
          }
        }
        return hits;
      } catch (_) {}
    }

    return lessons.where((l) {
      final hay = '${l.title.en} ${l.title.ar} ${l.content.en} ${l.content.ar}'
          .toLowerCase();
      return hay.contains(q);
    }).map((l) => SearchHit(
      type: 'lesson',
      id: l.id,
      titleEn: l.title.en,
      titleAr: l.title.ar,
      parentId: l.subjectId,
    )).toList();
  }
}
