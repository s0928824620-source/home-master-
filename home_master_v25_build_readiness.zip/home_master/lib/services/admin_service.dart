
import 'supabase_service.dart';

class AdminService {
  static Future<bool> isStaff() async {
    final profile = await SupabaseService.getProfile();
    final role = (profile?['role'] ?? 'student').toString();
    return role == 'teacher' || role == 'admin';
  }

  static Future<List<Map<String, dynamic>>> lessons({String? subjectId}) async {
    if (!SupabaseService.configured) return [];
    var q = SupabaseService.client.from('lessons').select();
    if (subjectId != null && subjectId.isNotEmpty) {
      q = q.eq('subject_id', subjectId);
    }
    final rows = await q.order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<List<Map<String, dynamic>>> questions(String lessonId) async {
    if (!SupabaseService.configured) return [];
    final rows = await SupabaseService.client
        .from('questions')
        .select()
        .eq('lesson_id', lessonId)
        .order('created_at', ascending: true);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<void> createLesson({
    required String subjectId,
    required String titleEn,
    required String titleAr,
    required String contentEn,
    required String contentAr,
  }) async {
    await SupabaseService.client.from('lessons').insert({
      'subject_id': subjectId,
      'title_en': titleEn,
      'title_ar': titleAr,
      'content_en': contentEn,
      'content_ar': contentAr,
    });
  }

  static Future<void> updateLesson({
    required String id,
    required String titleEn,
    required String titleAr,
    required String contentEn,
    required String contentAr,
  }) async {
    await SupabaseService.client.from('lessons').update({
      'title_en': titleEn,
      'title_ar': titleAr,
      'content_en': contentEn,
      'content_ar': contentAr,
    }).eq('id', id);
  }

  static Future<void> deleteLesson(String id) async {
    await SupabaseService.client.from('lessons').delete().eq('id', id);
  }

  static Future<void> createQuestion({
    required String lessonId,
    required String textEn,
    required String textAr,
    required List<String> optionsEn,
    required List<String> optionsAr,
    required int correctIndex,
  }) async {
    await SupabaseService.client.from('questions').insert({
      'lesson_id': lessonId,
      'text_en': textEn,
      'text_ar': textAr,
      'options_en': optionsEn,
      'options_ar': optionsAr,
      'correct_index': correctIndex,
    });
  }

  static Future<void> updateQuestion({
    required String id,
    required String textEn,
    required String textAr,
    required List<String> optionsEn,
    required List<String> optionsAr,
    required int correctIndex,
  }) async {
    await SupabaseService.client.from('questions').update({
      'text_en': textEn,
      'text_ar': textAr,
      'options_en': optionsEn,
      'options_ar': optionsAr,
      'correct_index': correctIndex,
    }).eq('id', id);
  }

  static Future<void> deleteQuestion(String id) async {
    await SupabaseService.client.from('questions').delete().eq('id', id);
  }
}
