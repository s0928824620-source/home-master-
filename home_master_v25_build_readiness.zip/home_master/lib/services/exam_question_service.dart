
import 'supabase_service.dart';

class ExamQuestionService {
  static Future<List<Map<String,dynamic>>> questions(String subjectId) async {
    if (!SupabaseService.configured) return [];
    final rows=await SupabaseService.client
      .from('questions')
      .select('id,lesson_id,text_en,text_ar,options_en,options_ar,correct_index')
      .eq('subject_id',subjectId)
      .order('id');
    return List<Map<String,dynamic>>.from(rows);
  }

  static Future<List<Map<String,dynamic>>> examQuestions(String examId) async {
    if (!SupabaseService.configured) return [];
    final rows=await SupabaseService.client
      .from('exam_questions')
      .select('question_id,position,questions(*)')
      .eq('exam_id',examId)
      .order('position');
    return List<Map<String,dynamic>>.from(rows);
  }

  static Future<void> setQuestions(String examId,List<String> ids) async {
    if (!SupabaseService.configured) return;
    await SupabaseService.client.from('exam_questions').delete().eq('exam_id',examId);
    if(ids.isEmpty)return;
    await SupabaseService.client.from('exam_questions').insert([
      for(int i=0;i<ids.length;i++){
        'exam_id':examId,'question_id':ids[i],'position':i+1
      }
    ]);
  }

  static Future<void> publish(String examId,bool value) async {
    await SupabaseService.client.from('exams').update({'is_published':value}).eq('id',examId);
  }
}
