
import '../models/models.dart';
import '../data/app_data.dart';
import 'supabase_service.dart';

class ContentRepository {
  static Future<List<Subject>> subjectsForGrade(String gradeId) async {
    if (!SupabaseService.configured) {
      return subjects.where((s) {
        return (gradeSubjectIds[gradeId] ?? []).contains(s.id);
      }).toList();
    }

    try {
      final rows = await SupabaseService.client
          .from('grade_subjects')
          .select('subject_id, subjects(*)')
          .eq('grade_id', gradeId);

      final result = <Subject>[];
      for (final row in rows) {
        final raw = row['subjects'];
        if (raw is Map<String, dynamic>) {
          result.add(_subjectFromRow(raw));
        }
      }
      return result;
    } catch (_) {
      return subjects.where((s) {
        return (gradeSubjectIds[gradeId] ?? []).contains(s.id);
      }).toList();
    }
  }

  static Future<List<Lesson>> lessonsForSubject(String subjectId) async {
    if (!SupabaseService.configured) {
      return lessons.where((l) => l.subjectId == subjectId).toList();
    }

    try {
      final rows = await SupabaseService.client
          .from('lessons')
          .select()
          .eq('subject_id', subjectId)
          .order('id');

      return rows.map<Lesson>(_lessonFromRow).toList();
    } catch (_) {
      return lessons.where((l) => l.subjectId == subjectId).toList();
    }
  }

  static Future<List<Question>> questionsForLesson(String lessonId) async {
    if (!SupabaseService.configured) {
      return questions.where((q) => q.lessonId == lessonId).toList();
    }

    try {
      final rows = await SupabaseService.client
          .from('questions')
          .select()
          .eq('lesson_id', lessonId)
          .order('id');

      return rows.map<Question>(_questionFromRow).toList();
    } catch (_) {
      return questions.where((q) => q.lessonId == lessonId).toList();
    }
  }

  static Subject _subjectFromRow(Map<String, dynamic> r) {
    return Subject(
      id: r['id'].toString(),
      name: LocalizedText(
        en: (r['name_en'] ?? r['name'] ?? '').toString(),
        ar: (r['name_ar'] ?? r['name'] ?? '').toString(),
      ),
    );
  }

  static Lesson _lessonFromRow(Map<String, dynamic> r) {
    return Lesson(
      id: r['id'].toString(),
      subjectId: r['subject_id'].toString(),
      title: LocalizedText(
        en: (r['title_en'] ?? '').toString(),
        ar: (r['title_ar'] ?? '').toString(),
      ),
      content: LocalizedText(
        en: (r['content_en'] ?? '').toString(),
        ar: (r['content_ar'] ?? '').toString(),
      ),
    );
  }

  static Question _questionFromRow(Map<String, dynamic> r) {
    final en = _stringList(r['options_en']);
    final ar = _stringList(r['options_ar']);
    return Question(
      id: r['id'].toString(),
      lessonId: r['lesson_id'].toString(),
      text: LocalizedText(
        en: (r['question_en'] ?? '').toString(),
        ar: (r['question_ar'] ?? '').toString(),
      ),
      options: LocalizedText(
        en: en.join('||'),
        ar: ar.join('||'),
      ),
      correctIndex: (r['correct_index'] ?? 0) as int,
    );
  }

  static List<String> _stringList(dynamic value) {
    if (value is List) return value.map((e) => e.toString()).toList();
    if (value is String) {
      return value.replaceAll('{', '').replaceAll('}', '').split(',');
    }
    return const [];
  }
}
