import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  static SupabaseClient? _client;

  static bool get configured => _client != null;
  static SupabaseClient get client => _client!;

  static Future<void> initialize() async {
    const url = String.fromEnvironment('SUPABASE_URL');
    const key = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');

    if (url.isEmpty || key.isEmpty || url.contains('YOUR-PROJECT')) {
      return;
    }

    await Supabase.initialize(url: url, anonKey: key);
    _client = Supabase.instance.client;
  }

  static User? get currentUser => _client?.auth.currentUser;

  static Stream<AuthState> get authChanges {
    if (_client == null) {
      return const Stream<AuthState>.empty();
    }
    return _client!.auth.onAuthStateChange;
  }

  static Future<AuthResponse> signUp(
    String email,
    String password,
    String name,
    String gradeId,
  ) async {
    final response = await client.auth.signUp(
      email: email,
      password: password,
      data: {
        'full_name': name,
        'grade_id': gradeId,
      },
    );
    return response;
  }

  static Future<AuthResponse> signIn(
    String email,
    String password,
  ) {
    return client.auth.signInWithPassword(
      email: email,
      password: password,
    );
  }

  static Future<void> signOut() => client.auth.signOut();

  static Future<Map<String, dynamic>?> getProfile() async {
    final user = currentUser;
    if (user == null) return null;
    final row = await client
        .from('profiles')
        .select()
        .eq('id', user.id)
        .maybeSingle();
    return row;
  }

  static Future<List<Map<String, dynamic>>> getProgress() async {
    final user = currentUser;
    if (user == null) return [];
    final rows = await client
        .from('lesson_progress')
        .select('lesson_id, completed_at')
        .eq('user_id', user.id);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<List<Map<String, dynamic>>> getResults() async {
    final user = currentUser;
    if (user == null) return [];
    final rows = await client
        .from('quiz_results')
        .select('subject_id, score, total, completed_at')
        .eq('user_id', user.id)
        .order('completed_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<void> markLessonComplete(String lessonId) async {
    final user = currentUser;
    if (user == null) return;
    await client.from('lesson_progress').upsert({
      'user_id': user.id,
      'lesson_id': lessonId,
      'completed_at': DateTime.now().toIso8601String(),
    });
  }

  static Future<void> saveQuizResult(
    String subjectId,
    int score,
    int total,
  ) async {
    final user = currentUser;
    if (user == null) return;
    await client.from('quiz_results').insert({
      'user_id': user.id,
      'subject_id': subjectId,
      'score': score,
      'total': total,
      'completed_at': DateTime.now().toIso8601String(),
    });
  }
}
