
import 'supabase_service.dart';

class ExamService {
  static Future<List<Map<String,dynamic>>> exams({String? gradeId,String? subjectId}) async {
    if (!SupabaseService.configured) return [];
    var q = SupabaseService.client.from('exams').select('*, questions(*)');
    if (gradeId != null) q = q.eq('grade_id', gradeId);
    if (subjectId != null) q = q.eq('subject_id', subjectId);
    final rows = await q.order('created_at', ascending:false);
    return List<Map<String,dynamic>>.from(rows);
  }

  static Future<Map<String,dynamic>> createExam({
    required String titleEn, required String titleAr,
    required String gradeId, required String subjectId,
    required int durationMinutes, required int questionCount,
  }) async {
    final row = await SupabaseService.client.from('exams').insert({
      'title_en': titleEn, 'title_ar': titleAr,
      'grade_id': gradeId, 'subject_id': subjectId,
      'duration_minutes': durationMinutes,
      'question_count': questionCount, 'is_published': false,
    }).select().single();
    return Map<String,dynamic>.from(row);
  }

  static Future<void> submitAttempt({
    required String examId, required String subjectId,
    required int score, required int total, required int durationSeconds,
  }) async {
    await SupabaseService.client.from('exam_attempts').insert({
      'exam_id': examId,
      'user_id': SupabaseService.currentUser!.id,
      'subject_id': subjectId,
      'score': score, 'total': total,
      'duration_seconds': durationSeconds,
    });
  }
}
