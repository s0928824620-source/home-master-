
import 'supabase_service.dart';

class AdminAnalytics {
  static Future<Map<String,dynamic>> summary() async {
    if (!SupabaseService.configured) return {};
    final p = await SupabaseService.client.from('profiles').select('id,role,grade_id,created_at');
    final r = await SupabaseService.client.from('quiz_results').select('id,user_id,subject_id,score,total,created_at');
    final lp = await SupabaseService.client.from('lesson_progress').select('id,user_id,lesson_id,completed_at');

    final profiles=List<Map<String,dynamic>>.from(p);
    final results=List<Map<String,dynamic>>.from(r);
    final progress=List<Map<String,dynamic>>.from(lp);

    int countRole(String role)=>profiles.where((x)=>(x['role']??'student')==role).length;
    double avg=0;
    if(results.isNotEmpty){
      double sum=0;
      for(final x in results){
        final score=(x['score'] as num?)?.toDouble()??0;
        final total=(x['total'] as num?)?.toDouble()??0;
        sum += total>0 ? score/total*100 : 0;
      }
      avg=sum/results.length;
    }
    return {
      'students':countRole('student'),
      'teachers':countRole('teacher'),
      'admins':countRole('admin'),
      'results':results.length,
      'completed_lessons':progress.length,
      'average_score':avg,
    };
  }

  static Future<List<Map<String,dynamic>>> users() async {
    if (!SupabaseService.configured) return [];
    final rows=await SupabaseService.client
      .from('profiles')
      .select('id,name,role,grade_id,created_at')
      .order('created_at',ascending:false);
    return List<Map<String,dynamic>>.from(rows);
  }

  static Future<void> setRole(String userId,String role) async {
    if (!SupabaseService.configured) {
      throw StateError('Supabase is not configured');
    }
    if (!{'student', 'teacher', 'admin'}.contains(role)) {
      throw ArgumentError.value(role, 'role', 'Unsupported role');
    }
    // Role changes must go through the server-side admin-only RPC.
    await SupabaseService.client.rpc('home_master_set_user_role', params: {
      'target_user': userId,
      'new_role': role,
    });
  }
}
