
import 'supabase_service.dart';
class StudentExamService {
 static Future<List<Map<String,dynamic>>> availableExams({String? gradeId}) async {
  if(!SupabaseService.configured)return [];
  var q=SupabaseService.client.from('exams').select('id,title_en,title_ar,grade_id,subject_id,duration_minutes,question_count,created_at').eq('is_published',true);
  if(gradeId!=null) q=q.eq('grade_id',gradeId);
  return List<Map<String,dynamic>>.from(await q.order('created_at',ascending:false));
 }
 static Future<List<Map<String,dynamic>>> myAttempts() async {
  if(!SupabaseService.configured||SupabaseService.currentUser==null)return [];
  return List<Map<String,dynamic>>.from(await SupabaseService.client.from('exam_attempts').select('id,exam_id,subject_id,score,total,duration_seconds,created_at').eq('user_id',SupabaseService.currentUser!.id).order('created_at',ascending:false));
 }
 static Future<List<Map<String,dynamic>>> leaderboard({int limit=20}) async {
  if(!SupabaseService.configured)return [];
  final rows=await SupabaseService.client.from('exam_attempts').select('user_id,score,total').gt('total',0).limit(500);
  final m=<String,Map<String,dynamic>>{};
  for(final x in rows){
   final id=x['user_id'].toString(); final e=m.putIfAbsent(id,()=>{'points':0.0,'attempts':0});
   e['points']=(e['points'] as double)+((x['score'] as num).toDouble()/(x['total'] as num).toDouble()*100);
   e['attempts']=(e['attempts'] as int)+1;
  }
  final a=m.values.toList();
  a.sort((x,y)=>((y['points'] as double)/(y['attempts'] as int)).compareTo((x['points'] as double)/(x['attempts'] as int)));
  return a.take(limit).toList();
 }
}
