
class NotificationService {
  static bool _enabled = true;

  static bool get enabled => _enabled;

  static void setEnabled(bool value) {
    _enabled = value;
  }

  static Future<void> initialize() async {
    // Notification provider can be connected here.
    // Kept dependency-light for the first online release.
  }

  static Future<void> sendStudyReminder({
    required String title,
    required String body,
  }) async {
    if (!_enabled) return;
    // Provider hook for local/push notifications.
  }
}
