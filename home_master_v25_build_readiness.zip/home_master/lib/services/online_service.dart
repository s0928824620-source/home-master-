import 'dart:convert';
import 'package:http/http.dart' as http;

/// Internet API layer for Home Master.
///
/// Set the real API URL before publishing:
/// flutter run --dart-define=HOME_MASTER_API=https://your-domain.com/api
///
/// Expected endpoints:
/// POST /auth/login       -> {"token":"...","user":{...}}
/// POST /auth/register    -> {"token":"...","user":{...}}
/// GET  /content?grade=p8 -> {"subjects":[...]}
/// POST /progress/sync    -> {"ok":true}
class OnlineService {
  static const apiBase = String.fromEnvironment(
    'HOME_MASTER_API',
    defaultValue: 'https://example.com/api',
  );

  String? token;

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  Uri _uri(String path, [Map<String, String>? query]) {
    final base = apiBase.endsWith('/') ? apiBase.substring(0, apiBase.length - 1) : apiBase;
    return Uri.parse('$base$path').replace(queryParameters: query);
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    final r = await http.post(
      _uri('/auth/login'),
      headers: _headers,
      body: jsonEncode({'email': email, 'password': password}),
    );
    return _decode(r);
  }

  Future<Map<String, dynamic>> register(
      String name, String email, String password, String gradeId) async {
    final r = await http.post(
      _uri('/auth/register'),
      headers: _headers,
      body: jsonEncode({
        'name': name,
        'email': email,
        'password': password,
        'gradeId': gradeId,
      }),
    );
    return _decode(r);
  }

  Future<Map<String, dynamic>> getContent(String gradeId) async {
    final r = await http.get(
      _uri('/content', {'grade': gradeId}),
      headers: _headers,
    );
    return _decode(r);
  }

  Future<Map<String, dynamic>> syncProgress(Map<String, dynamic> progress) async {
    final r = await http.post(
      _uri('/progress/sync'),
      headers: _headers,
      body: jsonEncode(progress),
    );
    return _decode(r);
  }

  Map<String, dynamic> _decode(http.Response r) {
    final data = r.body.isEmpty ? <String, dynamic>{} : jsonDecode(r.body);
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception(data is Map && data['message'] != null
          ? data['message']
          : 'Server error (${r.statusCode})');
    }
    return Map<String, dynamic>.from(data as Map);
  }
}
