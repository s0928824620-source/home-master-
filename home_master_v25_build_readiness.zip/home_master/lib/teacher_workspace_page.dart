import 'package:flutter/material.dart';
import 'admin_dashboard.dart';
import 'admin_analytics_page.dart';
import 'exam_admin_page.dart';
import 'question_bank_page.dart';
import 'exam_publish_page.dart';
import 'services/admin_service.dart';
import 'services/exam_service.dart';

class TeacherWorkspacePage extends StatefulWidget {
  final bool arabic;
  const TeacherWorkspacePage({super.key, required this.arabic});
  @override State<TeacherWorkspacePage> createState() => _TeacherWorkspacePageState();
}

class _TeacherWorkspacePageState extends State<TeacherWorkspacePage> {
  bool loading = true;
  bool allowed = false;
  String? message;
  String t(String en, String ar) => widget.arabic ? ar : en;

  @override
  void initState() { super.initState(); _checkAccess(); }

  Future<void> _checkAccess() async {
    try {
      allowed = await AdminService.isStaff();
      if (!allowed) {
        message = t(
          'Sign in with an account that has teacher/admin permissions. If you are an administrator, assign the role securely in Supabase.',
          'سجّل الدخول بحساب لديه صلاحيات معلم أو مدير. إذا كنت المسؤول، عيّن الدور بأمان من Supabase.',
        );
      }
    } catch (_) {
      allowed = false;
      message = t('Could not verify permissions. Check internet and Supabase setup.',
          'تعذر التحقق من الصلاحيات. تحقق من الإنترنت وإعدادات Supabase.');
    }
    if (mounted) setState(() => loading = false);
  }

  void _open(Widget page) => Navigator.push(context, MaterialPageRoute(builder: (_) => page));

  Future<void> _chooseExam({required bool forPublish}) async {
    try {
      final exams = await ExamService.exams();
      if (!mounted) return;
      if (exams.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(t('Create an exam first', 'أنشئ امتحانًا أولًا')),
        ));
        return;
      }
      final exam = await showDialog<Map<String, dynamic>>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: Text(t('Select exam', 'اختر الامتحان')),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView(
              shrinkWrap: true,
              children: exams.map((item) {
                final title = (widget.arabic
                    ? item['title_ar'] : item['title_en'])?.toString()
                    ?? item['id'].toString();
                return ListTile(
                  title: Text(title),
                  onTap: () => Navigator.pop(dialogContext, item),
                );
              }).toList(),
            ),
          ),
        ),
      );
      if (!mounted || exam == null) return;
      if (forPublish) {
        _open(ExamPublishPage(exam: exam, arabic: widget.arabic));
      } else {
        _open(QuestionBankPage(
          examId: exam['id'].toString(),
          subjectId: exam['subject_id'].toString(),
          arabic: widget.arabic,
        ));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: widget.arabic ? TextDirection.rtl : TextDirection.ltr,
    child: Scaffold(
      appBar: AppBar(
        title: Text(t('Teacher workspace', 'مساحة المعلم')),
        actions: [IconButton(onPressed: () { setState(() { loading = true; }); _checkAccess(); },
          icon: const Icon(Icons.refresh), tooltip: t('Refresh permissions', 'تحديث الصلاحيات'))],
      ),
      body: loading ? const Center(child: CircularProgressIndicator()) : !allowed
        ? Center(child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.admin_panel_settings_outlined, size: 54),
              const SizedBox(height: 12),
              Text(message ?? '', textAlign: TextAlign.center),
            ]),
          ))
        : ListView(padding: const EdgeInsets.all(16), children: [
          Text(t('Manage learning content', 'إدارة المحتوى التعليمي'),
            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          _tile(Icons.menu_book_outlined, t('Lessons and questions', 'الدروس والأسئلة'),
            t('Create and edit lesson content', 'إنشاء الدروس وتعديلها'), () => _open(AdminDashboardPage(arabic: widget.arabic))),
          _tile(Icons.quiz_outlined, t('Exam management', 'إدارة الامتحانات'),
            t('Create exams and set duration', 'إنشاء الامتحانات وتحديد مدتها'), () => _open(ExamAdminPage(arabic: widget.arabic))),
          _tile(Icons.library_books_outlined, t('Question bank', 'بنك الأسئلة'),
            t('Select questions for exams', 'اختيار أسئلة للامتحانات'), () => _chooseExam(forPublish: false)),
          _tile(Icons.publish_outlined, t('Publish exams', 'نشر الامتحانات'),
            t('Publish or unpublish an exam', 'نشر الامتحان أو إلغاء نشره'), () => _chooseExam(forPublish: true)),
          _tile(Icons.analytics_outlined, t('Analytics and users', 'الإحصاءات والمستخدمون'),
            t('Review platform activity and roles', 'مراجعة نشاط المنصة والأدوار'), () => _open(AdminAnalyticsPage(arabic: widget.arabic))),
          const SizedBox(height: 12),
          Card(child: ListTile(
            leading: const Icon(Icons.security_outlined),
            title: Text(t('Access is role-protected', 'الوصول محمي بالصلاحيات')),
            subtitle: Text(t('Only accounts approved as staff should see these tools. Configure and test database row-level security before launch.',
              'يجب أن تظهر هذه الأدوات للحسابات المعتمدة كطاقم فقط. أعد إعداد واختبر سياسات أمان قاعدة البيانات قبل الإطلاق.')),
          )),
        ]),
    ),
  );

  Widget _tile(IconData icon, String title, String subtitle, VoidCallback onTap) => Card(
    child: ListTile(
      leading: CircleAvatar(child: Icon(icon)),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    ),
  );
}
