
import 'package:flutter/material.dart';
import 'services/exam_question_service.dart';

class ExamPublishPage extends StatefulWidget {
  final Map<String,dynamic> exam;
  final bool arabic;
  const ExamPublishPage({super.key,required this.exam,required this.arabic});
  @override State<ExamPublishPage> createState()=>_ExamPublishPageState();
}
class _ExamPublishPageState extends State<ExamPublishPage>{
  bool published=false,busy=false;
  String t(String e,String a)=>widget.arabic?a:e;
  @override void initState(){super.initState();published=widget.exam['is_published']==true;}

  Future<void> toggle()async{
    setState(()=>busy=true);
    await ExamQuestionService.publish(widget.exam['id'].toString(),!published);
    if (mounted) setState(() { published = !published; busy = false; });
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(t('Publish Exam','نشر الامتحان'))),
    body:Padding(padding:const EdgeInsets.all(20),child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,
      children:[
        Text((widget.arabic?widget.exam['title_ar']:widget.exam['title_en']).toString(),
          style:Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height:20),
        Card(child:SwitchListTile(
          value:published,onChanged:busy?null:(_)=>toggle(),
          title:Text(published?t('Published','منشور'):t('Not published','غير منشور')),
          subtitle:Text(published?t('Students can see this exam.','الطلاب يستطيعون رؤية هذا الامتحان.'):
            t('Students cannot see this exam yet.','الطلاب لا يستطيعون رؤية هذا الامتحان بعد.')),
        )),
      ],
    )),
  );
}
