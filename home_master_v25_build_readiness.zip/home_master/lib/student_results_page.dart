
import 'package:flutter/material.dart';
import 'services/student_exam_service.dart';
class StudentResultsPage extends StatefulWidget {
 final bool arabic; const StudentResultsPage({super.key,required this.arabic});
 @override State<StudentResultsPage> createState()=>_StudentResultsPageState();
}
class _StudentResultsPageState extends State<StudentResultsPage>{
 List<Map<String,dynamic>> rows=[]; bool loading=true;
 String t(String e,String a)=>widget.arabic?a:e;
 @override void initState(){super.initState();load();}
 Future<void> load()async{try{rows=await StudentExamService.myAttempts();}catch(_){} if(mounted)setState(()=>loading=false);}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(t('My Exam Results','نتائج امتحاناتي')),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),body:loading?const Center(child:CircularProgressIndicator()):rows.isEmpty?Center(child:Text(t('No results yet.','لا توجد نتائج بعد.'))):ListView(children:rows.map((r){final s=(r['score'] as num?)?.toInt()??0;final total=(r['total'] as num?)?.toInt()??0;final p=total>0?s/total*100:0.0;return Card(child:ListTile(leading:CircleAvatar(child:Text('${p.toStringAsFixed(0)}%')),title:Text('${r['subject_id']} • $s / $total'),subtitle:Text('${r['created_at']} • ${r['duration_seconds']} ${t('seconds','ثانية')}')));}).toList()));
}
