
import 'package:flutter/material.dart';
import 'services/student_exam_service.dart';
class LeaderboardPage extends StatefulWidget {
 final bool arabic; const LeaderboardPage({super.key,required this.arabic});
 @override State<LeaderboardPage> createState()=>_LeaderboardPageState();
}
class _LeaderboardPageState extends State<LeaderboardPage>{
 List<Map<String,dynamic>> rows=[]; bool loading=true;
 String t(String e,String a)=>widget.arabic?a:e;
 @override void initState(){super.initState();load();}
 Future<void> load()async{try{rows=await StudentExamService.leaderboard();}catch(_){} if(mounted)setState(()=>loading=false);}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(t('Leaderboard','ترتيب الطلاب')),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),body:loading?const Center(child:CircularProgressIndicator()):rows.isEmpty?Center(child:Text(t('No scores available.','لا توجد درجات متاحة.'))):ListView.builder(itemCount:rows.length,itemBuilder:(c,i){final r=rows[i];final n=(r['attempts'] as int?)??1;final avg=(r['points'] as double? ??0)/n;return Card(child:ListTile(leading:CircleAvatar(child:Text('${i+1}')),title:Text('${t('Learner','الطالب')} ${i+1}'),subtitle:Text('${t('Attempts','المحاولات')}: $n'),trailing:Text('${avg.toStringAsFixed(1)}%')));}));
}
