import 'package:flutter/material.dart';
import 'ui/home_master_theme.dart';
import 'services/supabase_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'data/app_data.dart';
import 'models/models.dart';
import 'admin_dashboard.dart';
import 'student_exams_page.dart';
import 'student_results_page.dart';
import 'leaderboard_page.dart';
import 'student_profile_page.dart';
import 'auth_page.dart';
import 'teacher_workspace_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try { await SupabaseService.initialize(); } catch (_) { /* App remains usable without backend config. */ }
  runApp(const HomeMasterApp());
}


Widget homeMasterAdminEntry(BuildContext context, bool arabic) {
  return ListTile(
    leading: const Icon(Icons.admin_panel_settings_outlined),
    title: Text(arabic ? 'لوحة المعلم والإدارة' : 'Teacher / Admin Dashboard'),
    onTap: () => Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AdminDashboardPage(arabic: arabic),
      ),
    ),
  );
}

class HomeMasterApp extends StatefulWidget {
  const HomeMasterApp({super.key});
  @override State<HomeMasterApp> createState() => _HomeMasterAppState();
}

class _HomeMasterAppState extends State<HomeMasterApp> {
  bool arabic = false;
  bool dark = false;
  String? gradeId;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      arabic = p.getBool('arabic') ?? false;
      dark = p.getBool('dark') ?? false;
      gradeId = p.getString('gradeId');
    });
  }
  Future<void> setArabic(bool v) async { final p = await SharedPreferences.getInstance(); await p.setBool('arabic', v); setState(() => arabic = v); }
  Future<void> setDark(bool v) async { final p = await SharedPreferences.getInstance(); await p.setBool('dark', v); setState(() => dark = v); }
  Future<void> setGrade(String id) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('gradeId', id);
    setState(() => gradeId = id);
  }
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Home Master',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue, brightness: dark ? Brightness.dark : Brightness.light, fontFamily: 'Roboto'),
    home: gradeId == null
        ? GradeSelectionPage(arabic: arabic, onSelected: setGrade)
        : HomePage(arabic: arabic, dark: dark, gradeId: gradeId!, onLanguage: setArabic, onDark: setDark, onGrade: setGrade),
  );
}

String t(bool ar, String en, String a) => ar ? a : en;


class GradeSelectionPage extends StatelessWidget {
  final bool arabic;
  final String? currentGradeId;
  final ValueChanged<String> onSelected;
  const GradeSelectionPage({super.key, required this.arabic, this.currentGradeId, required this.onSelected});

  @override
  Widget build(BuildContext c) => Directionality(
    textDirection: arabic ? TextDirection.rtl : TextDirection.ltr,
    child: Scaffold(
      appBar: AppBar(title: Text(t(arabic, 'Choose your class', 'اختر صفك'))),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const SizedBox(height: 10),
          Text(t(arabic, 'Select your class to see the right subjects and quizzes.',
              'اختر صفك لعرض المواد والاختبارات المناسبة لك.'),
            style: Theme.of(c).textTheme.titleMedium),
          const SizedBox(height: 18),
          ...grades.map((g) => Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.school)),
              title: Text(g.name.get(arabic), style: const TextStyle(fontWeight: FontWeight.bold)),
              trailing: currentGradeId == g.id
                ? const Icon(Icons.check_circle, color: Colors.green)
                : const Icon(Icons.chevron_right),
              onTap: () => onSelected(g.id),
            ),
          )),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.offline_bolt),
              title: Text(t(arabic, 'Works offline', 'يعمل دون إنترنت')),
              subtitle: Text(t(arabic, 'Your class choice is saved on this device.',
                  'يتم حفظ اختيار الصف على هذا الجهاز.')),
            ),
          ),
        ],
      ),
    ),
  );
}


class ProgressStore {
  static Future<void> markLesson(String lessonId) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('lesson_done_$lessonId', true);
  }
  static Future<bool> lessonDone(String lessonId) async {
    final p = await SharedPreferences.getInstance();
    return p.getBool('lesson_done_$lessonId') ?? false;
  }
  static Future<Map<String, dynamic>> summary(List<Subject> ss) async {
    final p = await SharedPreferences.getInstance();
    int done = 0, totalLessons = 0, quizScore = 0, quizTotal = 0;
    for (final sub in ss) {
      for (final l in sub.lessons) {
        totalLessons++;
        if (p.getBool('lesson_done_${l.id}') ?? false) done++;
      }
      final score = p.getInt('result_${sub.id}');
      final total = p.getInt('result_${sub.id}_total');
      if (score != null && total != null) { quizScore += score; quizTotal += total; }
    }
    final lessonPercent = totalLessons == 0 ? 0 : ((done / totalLessons) * 100).round();
    final quizPercent = quizTotal == 0 ? 0 : ((quizScore / quizTotal) * 100).round();
    final overall = quizTotal == 0 ? lessonPercent : ((lessonPercent + quizPercent) / 2).round();
    return {'done': done, 'totalLessons': totalLessons, 'lessonPercent': lessonPercent,
      'quizScore': quizScore, 'quizTotal': quizTotal, 'quizPercent': quizPercent, 'overall': overall};
  }
}
String levelFor(int percent, bool ar) {
  if (percent >= 90) return t(ar, 'Excellent', 'ممتاز');
  if (percent >= 75) return t(ar, 'Very Good', 'جيد جدًا');
  if (percent >= 60) return t(ar, 'Good', 'جيد');
  if (percent >= 40) return t(ar, 'Keep Going', 'واصل التقدم');
  return t(ar, 'Beginner', 'مبتدئ');
}

class HomePage extends StatefulWidget {
  final bool arabic, dark; final String gradeId;
  final ValueChanged<bool> onLanguage, onDark;
  final ValueChanged<String> onGrade;
  const HomePage({super.key, required this.arabic, required this.dark, required this.gradeId, required this.onLanguage, required this.onDark, required this.onGrade});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int index = 0;
  List<Subject> get gradeSubjects {
    final ids = gradeSubjectIds[widget.gradeId] ?? subjects.map((s) => s.id).toList();
    return subjects.where((s) => ids.contains(s.id)).toList();
  }
  @override Widget build(BuildContext context) {
    final ar = widget.arabic;
    final pages = [
      _home(context, ar), SubjectsPage(arabic: ar, gradeId: widget.gradeId), QuizPage(arabic: ar, subjectsForQuiz: gradeSubjects), ResultsPage(arabic: ar, subjectsForResults: gradeSubjects), ProgressPage(arabic: ar, subjects: gradeSubjects), SettingsPage(arabic: ar, dark: widget.dark, gradeId: widget.gradeId, onLanguage: widget.onLanguage, onDark: widget.onDark, onGrade: widget.onGrade)
    ];
    return Directionality(textDirection: ar ? TextDirection.rtl : TextDirection.ltr, child: Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (i) => setState(() => index = i), destinations: [
        NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: t(ar,'Home','الرئيسية')),
        NavigationDestination(icon: const Icon(Icons.menu_book_outlined), label: t(ar,'Subjects','المواد')),
        NavigationDestination(icon: const Icon(Icons.quiz_outlined), label: t(ar,'Quiz','الاختبارات')),
        NavigationDestination(icon: const Icon(Icons.emoji_events_outlined), label: t(ar,'Results','النتائج')),
        NavigationDestination(icon: const Icon(Icons.insights_outlined), label: t(ar,'Progress','التقدم')),
        NavigationDestination(icon: const Icon(Icons.settings_outlined), label: t(ar,'Settings','الإعدادات')),
      ]),
    ));
  }
  Widget _home(BuildContext c, bool ar) => ListView(padding: const EdgeInsets.all(18), children: [
    Row(children: [CircleAvatar(radius: 24, backgroundColor: Colors.blue.shade50, child: const Icon(Icons.school, color: Colors.blue)), const SizedBox(width: 12), Expanded(child: Text(t(ar,'Home Master','هوم ماستر'), style: Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold))), IconButton(onPressed: (){}, icon: const Icon(Icons.notifications_none))]),
    const SizedBox(height: 18),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t(ar,'Learn • Practice • Succeed','تعلّم • تدرّب • انجح'), style: Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text(t(ar,'Your study partner, anytime, anywhere.','شريكك في الدراسة، في أي وقت ومن أي مكان.')), const SizedBox(height: 14), FilledButton.icon(onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => SubjectsPage(arabic: ar, gradeId: widget.gradeId))), icon: const Icon(Icons.play_arrow), label: Text(t(ar,'Start Learning','ابدأ التعلم')))]))),
    const SizedBox(height: 18), Text(t(ar,'Subjects','المواد الدراسية'), style: Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)), const SizedBox(height: 10),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.45, children: gradeSubjects.take(6).map((s)=>_subjectCard(c, ar, s)).toList()),
    const SizedBox(height: 18),
    Card(child: ListTile(leading: const Icon(Icons.offline_bolt), title: Text(t(ar,'Offline learning','التعلم دون إنترنت')), subtitle: Text(t(ar,'Lessons and quizzes are stored in the app.','الدروس والاختبارات محفوظة داخل التطبيق.')))),
  ]);
  Widget _subjectCard(BuildContext c, bool ar, Subject s) {
    return InkWell(
      onTap: () => Navigator.push(c, MaterialPageRoute(
        builder: (_) => SubjectPage(subject: s, arabic: ar),
      )),
      borderRadius: BorderRadius.circular(16),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                backgroundColor: Color(s.colorValue).withOpacity(.12),
                child: Text(s.icon, style: TextStyle(
                  color: Color(s.colorValue), fontWeight: FontWeight.bold,
                )),
              ),
              const Spacer(),
              Text(s.name.get(ar), style: const TextStyle(fontWeight: FontWeight.bold)),
              Text('${s.lessons.length} ${t(ar, 'lessons', 'دروس')}',
                style: Theme.of(c).textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
  }

}

class SubjectsPage extends StatelessWidget {
  final bool arabic;
  final String gradeId;
  const SubjectsPage({super.key, required this.arabic, required this.gradeId});

  @override
  Widget build(BuildContext c) {
    final ids = gradeSubjectIds[gradeId] ?? <String>[];
    final selected = ids.map((id) => subjects.firstWhere((s) => s.id == id)).toList();
    return Directionality(
      textDirection: arabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(t(arabic, 'Subjects', 'المواد الدراسية'))),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Text(t(arabic, 'Subjects', 'المواد الدراسية'),
              style: Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 14),
            ...selected.map((s) => Card(
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Color(s.colorValue).withOpacity(.12),
                  child: Text(s.icon, style: TextStyle(color: Color(s.colorValue), fontWeight: FontWeight.bold)),
                ),
                title: Text(s.name.get(arabic), style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text('${s.lessons.length} ${t(arabic, 'lessons', 'دروس')} • ${s.questions.length} ${t(arabic, 'questions', 'أسئلة')}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => SubjectPage(subject: s, arabic: arabic))),
              ),
            )),
          ],
        ),
      ),
    );
  }
}

class SubjectPage extends StatelessWidget {
  final Subject subject;
  final bool arabic;
  const SubjectPage({super.key, required this.subject, required this.arabic});

  @override
  Widget build(BuildContext c) {
    return Directionality(
      textDirection: arabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(subject.name.get(arabic))),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(child: Padding(
              padding: const EdgeInsets.all(18),
              child: Row(children: [
                CircleAvatar(radius: 28,
                  backgroundColor: Color(subject.colorValue).withOpacity(.12),
                  child: Text(subject.icon, style: TextStyle(fontSize: 22, color: Color(subject.colorValue))),
                ),
                const SizedBox(width: 14),
                Expanded(child: Text(t(arabic, 'Lessons and practice', 'الدروس والتدريب'),
                  style: Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))),
              ]),
            )),
            const SizedBox(height: 12),
            ...subject.lessons.map((l) => Card(child: ListTile(
              leading: const Icon(Icons.menu_book),
              title: Text(l.title.get(arabic)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => LessonPage(lesson: l, arabic: arabic))),
            ))),
            const SizedBox(height: 10),
            FilledButton.icon(
              onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => QuizPage(arabic: arabic, selected: subject))),
              icon: const Icon(Icons.quiz),
              label: Text(t(arabic, 'Take Quiz', 'ابدأ الاختبار')),
            ),
          ],
        ),
      ),
    );
  }
}

class LessonPage extends StatefulWidget {
  final Lesson lesson; final bool arabic;
  const LessonPage({super.key, required this.lesson, required this.arabic});
  @override State<LessonPage> createState() => _LessonPageState();
}
class _LessonPageState extends State<LessonPage> {
  bool done = false;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final v = await ProgressStore.lessonDone(widget.lesson.id);
    if (mounted) setState(() => done = v);
  }
  Future<void> _complete() async {
    await ProgressStore.markLesson(widget.lesson.id);
    if (mounted) setState(() => done = true);
  }
  @override Widget build(BuildContext c) {
    final ar = widget.arabic;
    return Directionality(textDirection: ar ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(widget.lesson.title.get(ar))),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          Text(widget.lesson.title.get(ar), style: Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          Card(child: Padding(padding: const EdgeInsets.all(20),
            child: Text(widget.lesson.body.get(ar), style: Theme.of(c).textTheme.bodyLarge?.copyWith(height: 1.7)))),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: done ? null : _complete,
            icon: Icon(done ? Icons.check_circle : Icons.done_outline),
            label: Text(done ? t(ar, 'Completed', 'تم إكمال الدرس') : t(ar, 'Mark as completed', 'ضع علامة مكتمل')),
          ),
          const SizedBox(height: 12),
          Text(t(ar, 'This lesson is available offline.', 'هذا الدرس متاح دون إنترنت.')),
        ]),
      ));
  }
}

class QuizPage extends StatefulWidget {
  final bool arabic; final Subject? selected; final List<Subject>? subjectsForQuiz;
  const QuizPage({super.key, required this.arabic, this.selected, this.subjectsForQuiz});
  @override State<QuizPage> createState()=>_QuizPageState();
}
class _QuizPageState extends State<QuizPage> {
  late List<Question> qs; int current=0, score=0; int? chosen; bool finished=false;
  @override void initState(){super.initState(); final pool = widget.subjectsForQuiz ?? subjects;
    qs=(widget.selected?.questions ?? pool.expand((s)=>s.questions).toList());}
  void answer(){if(chosen==null)return; if(chosen==qs[current].answer) score++; if(current==qs.length-1){ _saveResult(); setState(()=>finished=true);} else {setState((){current++;chosen=null;});}}

  Future<void> _saveResult() async {
    final p = await SharedPreferences.getInstance();
    final id = widget.selected?.id ?? 'general';
    await p.setInt('result_$id', score);
    await p.setInt('result_${id}_total', qs.length);
  }
  @override
  Widget build(BuildContext c) {
    final ar = widget.arabic;
    return Directionality(
      textDirection: ar ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(t(ar, 'Quiz', 'الاختبارات'))),
        body: finished ? _result(c, ar) : _question(c, ar),
      ),
    );
  }
  Widget _question(BuildContext c,bool ar){final q=qs[current]; return ListView(padding:const EdgeInsets.all(18),children:[LinearProgressIndicator(value:(current+1)/qs.length), const SizedBox(height:20), Text('${current+1}/${qs.length}', style:Theme.of(c).textTheme.labelLarge), const SizedBox(height:10), Text(q.question.get(ar), style:Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.bold)), const SizedBox(height:20), ...List.generate(q.options.length,(i)=>Card(child:RadioListTile<int>(value:i, groupValue:chosen, onChanged:(v)=>setState(()=>chosen=v), title:Text(q.options[i].get(ar))))), const SizedBox(height:10), FilledButton(onPressed:chosen==null?null:answer, child:Text(current==qs.length-1?t(ar,'Finish','إنهاء'):t(ar,'Next','التالي')))]);}
  Widget _result(BuildContext c, bool ar) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.emoji_events, size: 72, color: Colors.amber),
          const SizedBox(height: 16),
          Text(t(ar, 'Quiz Complete!', 'اكتمل الاختبار!'),
            style: Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('$score / ${qs.length}', style: Theme.of(c).textTheme.displaySmall),
          const SizedBox(height: 10),
          Text('${(score * 100 / qs.length).round()}%'),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: () => setState(() { current = 0; score = 0; chosen = null; finished = false; }),
            child: Text(t(ar, 'Try Again', 'إعادة المحاولة')),
          ),
        ],
      ),
    ),
  );

}


class ProgressPage extends StatefulWidget {
  final bool arabic; final List<Subject> subjects;
  const ProgressPage({super.key, required this.arabic, required this.subjects});
  @override State<ProgressPage> createState() => _ProgressPageState();
}
class _ProgressPageState extends State<ProgressPage> {
  Map<String, dynamic>? data;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final v = await ProgressStore.summary(widget.subjects);
    if (mounted) setState(() => data = v);
  }
  @override Widget build(BuildContext c) {
    final ar = widget.arabic;
    if (data == null) return const Center(child: CircularProgressIndicator());
    final overall = data!['overall'] as int;
    return Directionality(textDirection: ar ? TextDirection.rtl : TextDirection.ltr,
      child: ListView(padding: const EdgeInsets.all(18), children: [
        Text(t(ar, 'My Progress', 'تقدمي'), style: Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
          SizedBox(width: 150, height: 150, child: Stack(alignment: Alignment.center, children: [
            CircularProgressIndicator(value: overall / 100, strokeWidth: 12),
            Text('$overall%', style: Theme.of(c).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
          ])),
          const SizedBox(height: 14),
          Text(levelFor(overall, ar), style: Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          Text(t(ar, 'Overall learning progress', 'التقدم الدراسي العام')),
        ]))),
        const SizedBox(height: 12),
        Card(child: ListTile(leading: const Icon(Icons.menu_book),
          title: Text(t(ar, 'Lessons completed', 'الدروس المكتملة')),
          subtitle: Text('${data!['done']} / ${data!['totalLessons']}'),
          trailing: Text('${data!['lessonPercent']}%'))),
        Card(child: ListTile(leading: const Icon(Icons.quiz),
          title: Text(t(ar, 'Quiz performance', 'أداء الاختبارات')),
          subtitle: Text('${data!['quizScore']} / ${data!['quizTotal']}'),
          trailing: Text('${data!['quizPercent']}%'))),
        const SizedBox(height: 12),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(
          t(ar, 'Keep studying every day. Your progress is saved on this device.',
             'واصل الدراسة كل يوم. يتم حفظ تقدمك على هذا الجهاز.')))),
      ]));
  }
}

class ResultsPage extends StatefulWidget {
  final bool arabic; final List<Subject>? subjectsForResults;
  const ResultsPage({super.key, required this.arabic, this.subjectsForResults});
  @override State<ResultsPage> createState()=>_ResultsPageState();
}
class _ResultsPageState extends State<ResultsPage> {
  Map<String,int> scores={};
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async { final p=await SharedPreferences.getInstance(); final m=<String,int>{}; for(final s in subjects){ final v=p.getInt('result_${s.id}'); if(v!=null)m[s.id]=v; } final g=p.getInt('result_general'); if(g!=null)m['general']=g; if(mounted)setState(()=>scores=m); }
  @override
  Widget build(BuildContext c) {
    final ar = widget.arabic;
    final subjectList = widget.subjectsForResults ?? subjects;
    return Directionality(
      textDirection: ar ? TextDirection.rtl : TextDirection.ltr,
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(t(ar, 'My Results', 'نتائجي'), style: Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          if (scores.isEmpty)
            Card(child: Padding(padding: const EdgeInsets.all(22), child: Text(t(ar, 'No quiz results yet. Complete a quiz to see your score here.', 'لا توجد نتائج بعد. أكمل اختبارًا لتظهر نتيجتك هنا.')))),
          ...scores.entries.where((e) => e.key != 'general').map((e) {
            final s = subjectList.firstWhere((x) => x.id == e.key);
            final total = prefTotalPlaceholder(s);
            return Card(child: ListTile(
              leading: const Icon(Icons.emoji_events),
              title: Text(s.name.get(ar)),
              subtitle: Text(t(ar, 'Latest saved score', 'آخر نتيجة محفوظة')),
              trailing: Text('${e.value}/$total', style: const TextStyle(fontWeight: FontWeight.bold)),
            ));
          }),
          if (scores.containsKey('general'))
            Card(child: ListTile(
              leading: const Icon(Icons.public),
              title: Text(t(ar, 'All Subjects', 'كل المواد')),
              trailing: Text('${scores['general']}/${subjectList.expand((s) => s.questions).length}'),
            )),
        ],
      ),
    );
  }

}
int prefTotalPlaceholder(Subject s)=>s.questions.length;

class SettingsPage extends StatelessWidget {
  final bool arabic,dark; final String gradeId;
  final ValueChanged<bool> onLanguage,onDark; final ValueChanged<String> onGrade;
  const SettingsPage({super.key,required this.arabic,required this.dark,required this.gradeId,required this.onLanguage,required this.onDark,required this.onGrade});
  @override Widget build(BuildContext c)=>Directionality(textDirection:arabic?TextDirection.rtl:TextDirection.ltr,child:ListView(padding:const EdgeInsets.all(18),children:[Text(t(arabic,'Settings','الإعدادات'),style:Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:14),Card(child:SwitchListTile(value:arabic,onChanged:onLanguage,title:Text(t(arabic,'Arabic','العربية')),subtitle:Text(t(arabic,'Switch to English','التبديل إلى العربية')))),Card(child:SwitchListTile(value:dark,onChanged:onDark,title:Text(t(arabic,'Dark mode','الوضع الليلي')))),Card(child:ListTile(leading:const Icon(Icons.offline_bolt),title:Text(t(arabic,'Offline mode','الوضع دون إنترنت')),subtitle:Text(t(arabic,'Core lessons and quizzes work without internet.','الدروس والاختبارات الأساسية تعمل دون إنترنت.')))),
Card(child: ListTile(
  leading: const Icon(Icons.school_outlined),
  title: Text(t(arabic, 'My class', 'صفي')),
  subtitle: Text(grades.firstWhere((g) => g.id == gradeId).name.get(arabic)),
  trailing: const Icon(Icons.chevron_right),
  onTap: () => Navigator.push(c, MaterialPageRoute(
    builder: (_) => GradeSelectionPage(
      arabic: arabic,
      currentGradeId: gradeId,
      onSelected: (id) {
        onGrade(id);
        Navigator.popUntil(c, (route) => route.isFirst);
      },
    ),
  )),
)),const SizedBox(height: 18),
Text(t(arabic, 'Student account', 'حساب الطالب'), style: Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
Card(child: ListTile(
  leading: const Icon(Icons.lock_outline),
  title: Text(t(arabic, 'Sign in / Create account', 'تسجيل الدخول / إنشاء حساب')),
  subtitle: Text(t(arabic, 'Sync your progress and online exam results', 'زامن تقدمك ونتائج الامتحانات عبر الإنترنت')),
  trailing: const Icon(Icons.chevron_right),
  onTap: () => Navigator.push(c, MaterialPageRoute(
    builder: (_) => AuthPage(arabic: arabic, gradeId: gradeId),
  )),
)),
Text(t(arabic, 'Student tools', 'أدوات الطالب'), style: Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
Card(child: ListTile(leading: const Icon(Icons.person_outline), title: Text(t(arabic, 'My profile', 'ملفي الشخصي')), subtitle: Text(t(arabic, 'Account and learning progress', 'الحساب والتقدم الدراسي')), onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => StudentProfilePage(arabic: arabic, gradeId: gradeId))))),
Card(child: ListTile(leading: const Icon(Icons.assignment_outlined), title: Text(t(arabic, 'Online exams', 'الامتحانات الإلكترونية')), subtitle: Text(t(arabic, 'Take exams published by teachers', 'أدِّ الامتحانات التي ينشرها المعلمون')), onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => StudentExamsPage(arabic: arabic, gradeId: gradeId))))),
Card(child: ListTile(leading: const Icon(Icons.history_edu_outlined), title: Text(t(arabic, 'Online exam results', 'نتائج الامتحانات الإلكترونية')), onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => StudentResultsPage(arabic: arabic))))),
Card(child: ListTile(leading: const Icon(Icons.leaderboard_outlined), title: Text(t(arabic, 'Leaderboard', 'ترتيب الطلاب')), subtitle: Text(t(arabic, 'See anonymized scores', 'عرض الدرجات بأسماء مستعارة')), onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => LeaderboardPage(arabic: arabic))))),
Card(child: ListTile(
  leading: const Icon(Icons.co_present_outlined),
  title: Text(t(arabic, 'Teacher workspace', 'مساحة المعلم')),
  subtitle: Text(t(arabic, 'Manage lessons, questions and exams', 'إدارة الدروس والأسئلة والامتحانات')),
  trailing: const Icon(Icons.chevron_right),
  onTap: () => Navigator.push(c, MaterialPageRoute(
    builder: (_) => TeacherWorkspacePage(arabic: arabic),
  )),
)),
homeMasterAdminEntry(c, arabic),
Card(child:ListTile(leading:const Icon(Icons.info_outline),title:Text(t(arabic,'About Home Master','عن Home Master')),subtitle:const Text('Learn • Practice • Succeed')))]));
}


// Online account action used by the Settings screen in v8.
Future<void> homeMasterLogout() async {
  if (SupabaseService.configured) {
    await SupabaseService.signOut();
  }
}
