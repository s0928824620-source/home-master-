# Home Master v17 — Student navigation and profile

## What's added
- Connected the existing online exams, online exam results, and anonymized leaderboard pages to Settings > Student tools.
- Added a bilingual student profile page showing account name/email, selected class, saved online lesson progress, practice quiz results, and online exam attempts.
- Added Supabase initialization at app startup. If credentials are missing or initialization fails, the core local learning experience remains available.
- Added a refresh button and sign-out action on the profile page.

## Important setup notes
1. Create a Supabase project and apply `supabase/schema.sql` plus the migration SQL files for versions 12–15 in the documented order.
2. Launch with `--dart-define=SUPABASE_URL=https://YOUR-PROJECT.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR-PUBLISHABLE-KEY`.
3. The app still needs a proper sign-in/sign-up screen to let students authenticate in-app. This version displays a clear not-connected state if there is no signed-in user.
4. Before production release, validate the exam/question table column names and row-level security policies against the actual Supabase schema. No live backend credentials were provided, so live connectivity has not been tested.

## Where to find the features
Open **Settings** → **Student tools** to access My Profile, Online Exams, Online Exam Results, and Leaderboard. The teacher/admin dashboard entry is also available there.
