# Home Master v8 — Online Accounts

Added:
- Supabase email/password login.
- Student account registration.
- Grade selection during registration: P8, S1, S2, S3.
- Online lesson progress storage.
- Online quiz result storage.
- Online profile retrieval.
- Authentication gate before entering the app.

## Run

flutter pub get

flutter run --dart-define=SUPABASE_URL=https://YOUR-PROJECT.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR-PUBLISHABLE-KEY

Important:
- Use the Supabase Publishable/Anon key in the mobile app.
- Never put the service-role key in the mobile app.
- Run schema.sql and then seed_content_v7.sql in Supabase.
