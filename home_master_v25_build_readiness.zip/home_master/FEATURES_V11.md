# Home Master v11 — Search, Favorites & Notifications

## Search
`SearchService.search(query)` searches lesson titles and lesson content.
It uses Supabase when configured and local content as fallback.

## Favorites
`FavoritesService` stores favorite lesson IDs using SharedPreferences.
This lets students bookmark important lessons.

## Notifications
`NotificationService` is a provider-ready abstraction:
- study reminders
- new lesson notifications
- quiz reminders

A notification package can be connected later without changing the rest of the app.

## Suggested navigation
Add a Search icon on the Home/Subjects app bar.
Add a star icon to LessonPage.
Add a Favorites section under Progress.
Add notification preferences under Settings.
