# Home Master v7 — Bilingual Curriculum Seed

This version expands the online curriculum for P8, S1, S2 and S3.

- P8: 4 core subjects × 5 lessons = 20 lessons
- S1: 9 subjects × 5 lessons = 45 lessons
- S2: 9 subjects × 5 lessons = 45 lessons
- S3: 9 subjects × 5 lessons = 45 lessons
- Total lessons: 155
- Questions: 465

Subjects:
Mathematics, English, Biology, Chemistry, Physics, Geography, History, Commerce, Account.

## Add the content to Supabase

1. Run `supabase/schema.sql` first in the Supabase SQL Editor.
2. Then run `supabase/seed_content_v7.sql`.
3. Keep the mobile app configured with the Supabase URL and Publishable Key.
4. Never put a Supabase service-role key inside the mobile application.

This is an initial bilingual content library, not a claim that every official South Sudan syllabus topic is fully covered yet.
