
# Home Master v13 — Admin Analytics

Added:
- Student/teacher/admin counts
- Quiz result count
- Completed lesson count
- Average quiz score
- User list
- Change user role from the admin dashboard

Run `supabase/v13_analytics.sql` in Supabase SQL Editor after v12.

The analytics page is `AdminAnalyticsPage`.
A live Supabase project and correct RLS configuration are required.
