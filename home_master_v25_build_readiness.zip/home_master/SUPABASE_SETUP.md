# Home Master v6 — Supabase Online

This version uses Supabase for:
- Student registration/login
- Online lessons and questions
- Student profiles
- Lesson completion
- Quiz results

Official setup guide:
https://supabase.com/docs/guides/getting-started/quickstarts/flutter

## 1. Create a Supabase project
Create a free project in Supabase.

## 2. Create the database
Open SQL Editor and run:
`supabase/schema.sql`

## 3. Get project credentials
From the Supabase Connect panel, copy:
- Project URL
- Publishable key

Do NOT put a service_role key inside the mobile app. Supabase's documentation recommends publishable keys for client apps and RLS to protect user data.

## 4. Run Home Master
```bash
flutter pub get
flutter run \
  --dart-define=SUPABASE_URL=https://YOUR-PROJECT.supabase.co \
  --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR-PUBLISHABLE-KEY
```

## Important
The Flutter app source now contains the complete Supabase service and database schema, but the app cannot connect until you create your own Supabase project and supply its URL/key.
