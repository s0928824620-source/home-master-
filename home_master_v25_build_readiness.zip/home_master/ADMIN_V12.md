
# Home Master v12 — Teacher & Admin Dashboard

## What was added
- Staff roles: `student`, `teacher`, `admin`.
- Protected curriculum editing with Supabase RLS.
- Teacher/Admin dashboard inside the Flutter app.
- Create, edit and delete lessons.
- Create, edit and delete quiz questions.
- Arabic + English fields for lesson/question content.
- Correct-answer selector for 4-option questions.

## Supabase setup
1. Open your Supabase project's SQL Editor.
2. Run `supabase/v12_admin.sql`.
3. Create/register the teacher or admin account in the app.
4. In Supabase Authentication, find that user's UUID.
5. Run:
   `update public.profiles set role='admin' where id='YOUR-AUTH-USER-UUID';`
6. Start the app with your Supabase URL and Publishable Key.

Do NOT put the Supabase service_role key in the mobile app.

## Opening the dashboard
The dashboard widget is `AdminDashboardPage`.
It is intentionally protected by the user's `profiles.role`.
Students cannot create/edit/delete curriculum through these policies.

## Important
This version prepares the mobile dashboard and secure database policies. A live Supabase project is still required; the package does not contain or invent one.
