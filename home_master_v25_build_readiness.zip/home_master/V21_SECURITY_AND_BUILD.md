# Home Master v21 — Security and Android readiness

## What changed
- Admin role updates now call the Supabase RPC `home_master_set_user_role` instead of updating `profiles.role` directly from the app.
- The analytics page shows a success/failure message when role changes are attempted.
- Added `supabase/v21_security_hardening.sql` to limit profile updates to editable profile fields and keep role changes server-side.

## Required Supabase setup
1. Apply the earlier schema and migrations in order (v12 through v20).
2. Open Supabase SQL Editor and run `supabase/v21_security_hardening.sql`.
3. Confirm at least one trusted administrator has `profiles.role = 'admin'`. Do not make every account an admin.
4. In Supabase project settings, copy the project URL and publishable/anon key.
5. Run the Flutter app with build-time values, for example:
   `flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY`

## Build Android
Install Flutter and Android Studio/Android SDK, then from the project directory run:
1. `flutter pub get`
2. `flutter analyze`
3. `flutter test` (if tests are added)
4. `flutter build apk --release --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_PUBLISHABLE_KEY=...`

The resulting APK is normally at `build/app/outputs/flutter-apk/app-release.apk`.

## Important validation notes
- This ZIP contains Flutter source code, not a prebuilt APK.
- The build was not verified in this environment because Flutter tooling and real Supabase credentials are not available here.
- Before production, test account creation/sign-in, role restrictions, lesson sync, exam publishing, exam attempts, and results against a real Supabase project.
- Apply the SQL migration only after checking the earlier migrations and backing up any important data.
