# Home Master v18 — Student Accounts

## Added
- Bilingual sign-in and account creation page.
- Email/password validation and loading/error states.
- Settings entry for student accounts.
- Supabase profile trigger migration to save student name and selected class.
- Guest/local learning remains available when Supabase is not configured.

## Setup
1. Create a Supabase project.
2. Run `supabase/schema.sql`, then the migrations for the features you use, including `supabase/v18_student_accounts.sql`.
3. Start Flutter with the project URL and publishable key:
   `flutter run --dart-define=SUPABASE_URL=https://YOUR-PROJECT.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR-PUBLISHABLE-KEY`
4. Use the Settings > Student account page to create an account or sign in.

Never put a Supabase `service_role` key in a mobile app.

## Important
This is a source project, not a prebuilt APK. A live online account requires a real Supabase project and valid credentials. Email confirmation behavior depends on the Supabase Auth settings. Run `flutter pub get` and test on an Android/iOS device before release.
