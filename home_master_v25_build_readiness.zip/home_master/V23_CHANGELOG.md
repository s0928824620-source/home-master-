# Home Master v23 — schema compatibility pass

- Added a Supabase compatibility migration for client/server column-name differences across lessons, questions, profiles, progress, and quiz results.
- Corrected `exam_questions.question_id` to use the same text ID type as the existing question bank in the v15 migration.
- Added compatibility triggers to keep legacy lesson/question fields aligned with the names used by the current app.
- Added a migration checklist below.

## Apply and validate
1. Back up your Supabase project first.
2. For a new database, run `schema.sql`, then migrations in order (v12, v13, v14, v15, v16-related SQL if supplied, v18, v19, v20, v21, then v23).
3. For an existing database, review and run `supabase/v23_schema_compatibility.sql` after prior migrations. Do not rerun all migrations blindly.
4. Create a test student and a separate admin; promote the admin only through the SQL editor after verifying the auth UUID.
5. Test lesson listing, lesson create/edit, question bank, exam publish, student attempt, results, profile update, and role change.

This remains source code, not an APK. Flutter is not installed in the authoring environment, so `flutter analyze` and platform builds have not been run.
