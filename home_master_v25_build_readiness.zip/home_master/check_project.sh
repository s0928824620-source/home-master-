#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 tools/preflight_check.py
if command -v flutter >/dev/null 2>&1; then
  flutter pub get
  flutter analyze
  flutter test
else
  echo "Flutter not found: skipped Flutter analyze/test. Install Flutter to continue." >&2
fi
