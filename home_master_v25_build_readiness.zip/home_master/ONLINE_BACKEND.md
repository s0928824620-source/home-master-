# Home Master Online Backend

Home Master v5 is prepared for an internet backend.

## Configure the API
Run:
```bash
flutter run --dart-define=HOME_MASTER_API=https://YOUR-DOMAIN/api
```

For release:
```bash
flutter build apk --dart-define=HOME_MASTER_API=https://YOUR-DOMAIN/api
```

## Required API
### POST /auth/register
Body:
```json
{"name":"Student","email":"student@example.com","password":"secret","gradeId":"s1"}
```
Response:
```json
{"token":"JWT_TOKEN","user":{"id":"1","name":"Student","gradeId":"s1"}}
```

### POST /auth/login
Body:
```json
{"email":"student@example.com","password":"secret"}
```

### GET /content?grade=s1
Return the subjects, lessons and quiz questions for that grade.

### POST /progress/sync
Accept the student's completed lessons and quiz results.

## Recommended free backend
Supabase or Firebase can be used for authentication and database hosting.
The Flutter client is deliberately separated from the backend so the backend can be changed later without rebuilding the app architecture.
