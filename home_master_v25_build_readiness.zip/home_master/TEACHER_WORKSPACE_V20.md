# Home Master v20 — Teacher Workspace

## Added
- A bilingual teacher workspace hub linked from Settings.
- Shortcuts to lesson/question management, exam management, question bank, publishing, and analytics.
- The hub checks staff access before showing tools.
- A SQL RPC for admin-only user role changes, rather than relying on client-side role updates.

## Setup and testing
1. Apply previous schema and migrations first.
2. Review the `profiles.role` values and your `AdminService.isStaff()` implementation.
3. Run `supabase/v20_secure_role_management.sql`.
4. Make sure at least one trusted admin account is provisioned securely; do not expose admin assignment to students.
5. Run `flutter pub get`, then test with student, teacher, and admin accounts.

## Important caveat
This source update wires a workspace hub to existing pages, but does not certify all exam/question database queries as compatible with every earlier schema revision. Test against a development Supabase project and fix any schema mismatches before production. The zip is source code, not an APK/IPA.
