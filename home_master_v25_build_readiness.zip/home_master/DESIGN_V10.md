# Home Master v10 Design Direction

Brand:
- Name: Home Master
- Slogan: Learn • Practice • Succeed.
- Style: clean, modern educational interface.
- Material 3 components.
- Supports light and dark modes.
- Arabic and English labels remain supported.

Main navigation:
Home | Subjects | Quiz | Results | Progress | Settings

Student home should prioritize:
- Continue learning
- Class and progress
- Subject cards
- Quick quiz
- Recent results

No paid features are added; the app remains intended as a free educational app.
