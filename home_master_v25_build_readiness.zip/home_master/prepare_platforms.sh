#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter was not found. Install Flutter and add it to PATH first." >&2
  exit 1
fi

cd "$(dirname "$0")"
flutter create --platforms=android,ios --org org.homemaster.education .
flutter pub get
printf '\nPlatform folders generated. Next run: flutter analyze\n'
