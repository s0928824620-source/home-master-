# Home Master v9 — Online Content Layer

This version adds `lib/services/content_repository.dart`.

It provides:
- online subject loading from Supabase;
- online lesson loading;
- online quiz question loading;
- automatic local fallback if Supabase is unavailable.

The SQL seed from v7 remains the content source:
`supabase/seed_content_v7.sql`

## Integration note

The existing pages can progressively replace direct reads from `app_data.dart` with:
- `ContentRepository.subjectsForGrade(gradeId)`
- `ContentRepository.lessonsForSubject(subjectId)`
- `ContentRepository.questionsForLesson(lessonId)`

This keeps the app usable when the network is unavailable.
