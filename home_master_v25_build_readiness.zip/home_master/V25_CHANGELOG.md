# v25 change log

- Updated Flutter package version to `1.0.0+25`.
- Added a practical platform-generation, validation, Supabase configuration, and Android build guide.
- Clarified that source packaging is not equivalent to a successful APK build.
- No Flutter compilation was run because Flutter/Dart are not installed in the current environment.
