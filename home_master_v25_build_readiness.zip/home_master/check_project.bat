@echo off
setlocal
cd /d "%~dp0"
python tools\preflight_check.py
if errorlevel 1 exit /b 1
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter not found. Static checks only; install Flutter to analyze and test.
  exit /b 0
)
flutter pub get
if errorlevel 1 exit /b 1
flutter analyze
if errorlevel 1 exit /b 1
flutter test
if errorlevel 1 exit /b 1
