import '../models/models.dart';

LocalizedText lt(String en, String ar) => LocalizedText(en, ar);
Lesson lesson(String id, String enTitle, String arTitle, String enBody, String arBody) => Lesson(id:id,title:lt(enTitle,arTitle),body:lt(enBody,arBody));
Question q(String en, String ar, List<String> enO, List<String> arO, int a) => Question(question:lt(en,ar),options:List.generate(enO.length,(i)=>lt(enO[i],arO[i])),answer:a);

final List<Subject> subjects = [
  Subject(id:'mathematics',name:lt('Mathematics','الرياضيات'),colorValue:0xFF1565C0,icon:'∑',lessons:[
    lesson('algebra','Algebra Basics','أساسيات الجبر','An equation has two equal sides. Solve 2x + 6 = 16 by subtracting 6, then dividing by 2, so x = 5.','المعادلة لها طرفان متساويان. لحل 2x + 6 = 16 نطرح 6 ثم نقسم على 2، فنحصل على x = 5.'),
    lesson('fractions','Fractions','الكسور','A fraction represents a part of a whole. In 3/4, 3 is the numerator and 4 is the denominator.','الكسر يمثل جزءًا من كل. في 3/4 البسط هو 3 والمقام هو 4.'),
    lesson('percentages','Percentages','النسب المئوية','A percentage is a fraction out of 100. 25% of 80 is 20.','النسبة المئوية كسر من 100. ‏25% من 80 تساوي 20.'),
    lesson('indices','Indices and Powers','الأسس والقوى','An index shows repeated multiplication. 2³ = 2 × 2 × 2 = 8.','الأس يوضح تكرار الضرب. 2³ = 2 × 2 × 2 = 8.'),
  ],questions:[
    q('What is x in 2x + 6 = 16?','ما قيمة x في 2x + 6 = 16؟',['4','5','6','7'],['٤','٥','٦','٧'],1),
    q('What is 7 × 8?','كم يساوي 7 × 8؟',['54','56','64','48'],['٥٤','٥٦','٦٤','٤٨'],1),
    q('What is 3/4 of 20?','كم يساوي 3/4 من 20؟',['10','12','15','16'],['١٠','١٢','١٥','١٦'],2),
    q('What is 25% of 80?','كم تساوي 25% من 80؟',['15','20','25','30'],['١٥','٢٠','٢٥','٣٠'],1),
    q('What is 2³?','ما قيمة 2³؟',['6','8','9','12'],['٦','٨','٩','١٢'],1),
  ]),
  Subject(id:'english',name:lt('English','اللغة الإنجليزية'),colorValue:0xFFD32F2F,icon:'A',lessons:[
    lesson('parts','Parts of Speech','أقسام الكلام','A noun names a person, place, thing or idea. A verb shows an action or state. An adjective describes a noun.','الاسم يدل على شخص أو مكان أو شيء أو فكرة. الفعل يدل على حدث أو حالة. الصفة تصف الاسم.'),
    lesson('tenses','Basic Tenses','الأزمنة الأساسية','The present describes regular actions: I study. The past describes completed actions: I studied. The future can use will: I will study.','المضارع يصف الأفعال المعتادة: I study. الماضي يصف الأفعال المكتملة: I studied. المستقبل يمكن أن يستخدم will: I will study.'),
    lesson('sentence','Sentence Structure','تركيب الجملة','A basic English sentence often has a subject, verb and object: The student reads a book.','غالبًا تتكون الجملة الإنجليزية الأساسية من فاعل وفعل ومفعول به: The student reads a book.'),
    lesson('vocabulary','Vocabulary Skills','مهارات المفردات','Learn new words using context, synonyms and examples. Keep a small vocabulary list and review it regularly.','تعلم الكلمات الجديدة باستخدام السياق والمرادفات والأمثلة. احتفظ بقائمة مفردات وراجعها باستمرار.'),
  ],questions:[
    q('Which word is a verb?','أي كلمة هي فعل؟',['school','run','beautiful','student'],['مدرسة','يجري','جميل','طالب'],1),
    q('Choose the past tense of “go”.','اختر صيغة الماضي للفعل go.',['goed','goes','went','going'],['goed','goes','went','going'],2),
    q('Which is a noun?','أي كلمة اسم؟',['quickly','teacher','write','beautiful'],['بسرعة','معلم','يكتب','جميل'],1),
    q('Choose the correct sentence.','اختر الجملة الصحيحة.',['He go to school.','He goes to school.','He going school.','He gone school.'],['He go to school.','He goes to school.','He going school.','He gone school.'],1),
    q('What is the opposite of “easy”?','ما عكس كلمة easy؟',['simple','hard','light','early'],['بسيط','صعب','خفيف','مبكر'],1),
  ]),
  Subject(id:'biology',name:lt('Biology','الأحياء'),colorValue:0xFF2E7D32,icon:'⌁',lessons:[
    lesson('cell','The Cell','الخلية','The cell is the basic structural and functional unit of life.','الخلية هي الوحدة الأساسية في تركيب ووظيفة الكائنات الحية.'),
    lesson('photosynthesis','Photosynthesis','البناء الضوئي','Plants use light energy, water and carbon dioxide to make food and release oxygen.','تستخدم النباتات ضوء الشمس والماء وثاني أكسيد الكربون لصنع الغذاء وإطلاق الأكسجين.'),
    lesson('nutrition','Human Nutrition','تغذية الإنسان','A balanced diet supplies carbohydrates, proteins, fats, vitamins, minerals, fibre and water in suitable amounts.','الغذاء المتوازن يوفر الكربوهيدرات والبروتينات والدهون والفيتامينات والمعادن والألياف والماء بكميات مناسبة.'),
    lesson('ecosystem','Ecosystems','الأنظمة البيئية','An ecosystem includes living organisms and the non-living environment in which they interact.','يشمل النظام البيئي الكائنات الحية والبيئة غير الحية التي تتفاعل معها.'),
    lesson(
      'intro_biology',
      'Introduction to Biology',
      'مقدمة في علم الأحياء',
      'Biology is the scientific study of living things. The word Biology comes from two Greek words: bio meaning life and logos meaning study or knowledge.\n\nBranches of Biology include Botany (study of plants), Zoology (study of animals), Ecology (study of organisms and their environment), Microbiology (study of microorganisms), Entomology (study of insects), Genetics (study of heredity), Parasitology (study of parasites), Cytology (study of cells), Anatomy (study of internal structures), Morphology (study of form and structure), Taxonomy (classification of organisms), Physiology (study of functions), and Biochemistry (chemical processes in living things).\n\nBiology helps us understand life, improve agriculture, prevent diseases, protect the environment, and develop careers in medicine, teaching, research and farming.',
      'علم الأحياء هو الدراسة العلمية للكائنات الحية. تتكون كلمة Biology من كلمتين يونانيتين: bio وتعني الحياة، وlogos وتعني الدراسة أو المعرفة.\n\nمن فروع علم الأحياء: علم النبات، وعلم الحيوان، وعلم البيئة، وعلم الأحياء الدقيقة، وعلم الحشرات، وعلم الوراثة، وعلم الطفيليات، وعلم الخلية، وعلم التشريح، وعلم الشكل والتركيب، وعلم التصنيف، وعلم وظائف الأعضاء، والكيمياء الحيوية.\n\nيساعدنا علم الأحياء على فهم الحياة، وتحسين الزراعة، والوقاية من الأمراض، وحماية البيئة، والعمل في مجالات مثل الطب والتعليم والبحث والزراعة.'
    ),
    lesson(
      'living_things',
      'Characteristics of Living Things',
      'خصائص الكائنات الحية',
      'Living things have important characteristics:\n\n1. Nutrition: obtaining and using nutrients for energy, growth and repair.\n2. Gaseous exchange: taking in oxygen and releasing carbon dioxide, or exchanging gases as required by the organism.\n3. Respiration: releasing energy from food in cells.\n4. Growth and development: increasing in size and undergoing changes during life.\n5. Movement: changing position or moving body parts.\n6. Irritability: detecting and responding to stimuli in the environment.\n7. Reproduction: producing new organisms of the same kind.',
      'للكائنات الحية خصائص مهمة:\n\n1. التغذية: الحصول على المواد الغذائية واستخدامها للطاقة والنمو وإصلاح الأنسجة.\n2. تبادل الغازات: أخذ الأكسجين وإخراج ثاني أكسيد الكربون، أو تبادل الغازات حسب حاجة الكائن الحي.\n3. التنفس: تحرير الطاقة من الغذاء داخل الخلايا.\n4. النمو والتطور: زيادة الحجم وحدوث تغيرات أثناء الحياة.\n5. الحركة: تغيير المكان أو تحريك أجزاء الجسم.\n6. الاستجابة للمؤثرات: الإحساس بالمؤثرات في البيئة والاستجابة لها.\n7. التكاثر: إنتاج كائنات حية جديدة من النوع نفسه.'
    ),
    lesson(
      'plants_animals',
      'Differences Between Plants and Animals',
      'الاختلافات بين النباتات والحيوانات',
      'Plants and animals are living organisms, but they differ in several ways.\n\n1. Nutrition: green plants make their own food by photosynthesis, while animals obtain food by eating plants or other animals.\n2. Movement: animals usually move from place to place, while most plants remain fixed in one place, although plant parts can move.\n3. Growth: plants often continue growing throughout life, while growth in many animals becomes limited after maturity.\n4. Response: both plants and animals respond to stimuli in their environment.\n5. Cells: plant cells usually have a cell wall and chloroplasts in photosynthetic tissues; animal cells do not have cell walls or chloroplasts.',
      'النباتات والحيوانات كائنات حية، لكنها تختلف في عدة أمور.\n\n1. التغذية: تصنع النباتات الخضراء غذاءها بالبناء الضوئي، بينما تحصل الحيوانات على الغذاء بأكل النباتات أو الحيوانات الأخرى.\n2. الحركة: تنتقل الحيوانات عادةً من مكان إلى آخر، بينما تبقى معظم النباتات ثابتة في مكانها، مع إمكانية حركة بعض أجزائها.\n3. النمو: تستمر النباتات غالبًا في النمو طوال حياتها، بينما يتوقف النمو في كثير من الحيوانات أو يصبح محدودًا بعد النضج.\n4. الاستجابة: تستجيب النباتات والحيوانات للمؤثرات في البيئة.\n5. الخلايا: تحتوي الخلايا النباتية عادةً على جدار خلوي، وعلى بلاستيدات خضراء في الأنسجة التي تقوم بالبناء الضوئي، أما الخلايا الحيوانية فلا تحتوي على جدار خلوي أو بلاستيدات خضراء.'
    ),
    lesson(
      'forms_of_life',
      'Unicellular and Multicellular Organisms',
      'الكائنات وحيدة الخلية ومتعددة الخلايا',
      'Organisms can be classified by the number of cells in their bodies.\n\n1. Unicellular organisms consist of one cell that carries out all essential life processes. Examples include Amoeba, many bacteria and yeast.\n2. Multicellular organisms consist of many cells. Different cells may perform different functions. Examples include humans, dogs and most plants.\n\nIn multicellular organisms, similar cells can form tissues, tissues form organs, and organs work together in organ systems.',
      'يمكن تصنيف الكائنات الحية حسب عدد الخلايا في أجسامها.\n\n1. الكائنات وحيدة الخلية: تتكون من خلية واحدة تقوم بجميع العمليات الحيوية الأساسية. من أمثلتها الأميبا، وكثير من أنواع البكتيريا، والخميرة.\n2. الكائنات متعددة الخلايا: تتكون من خلايا كثيرة، وقد تؤدي الخلايا المختلفة وظائف مختلفة. من أمثلتها الإنسان والكلاب ومعظم النباتات.\n\nفي الكائنات متعددة الخلايا، يمكن أن تكوّن الخلايا المتشابهة أنسجة، وتكوّن الأنسجة أعضاء، وتعمل الأعضاء معًا ضمن أجهزة الجسم.'
    ),
  ],questions:[
    q('What is the basic unit of life?','ما الوحدة الأساسية للحياة؟',['Tissue','Cell','Organ','System'],['نسيج','خلية','عضو','جهاز'],1),
    q('What gas is released during photosynthesis?','ما الغاز الذي يطلق أثناء البناء الضوئي؟',['Nitrogen','Oxygen','Hydrogen','Helium'],['النيتروجين','الأكسجين','الهيدروجين','الهيليوم'],1),
    q('Which nutrient mainly builds and repairs tissues?','أي عنصر غذائي يساعد أساسًا في بناء وإصلاح الأنسجة؟',['Protein','Water','Salt','Fibre'],['البروتين','الماء','الملح','الألياف'],0),
    q('Which is a living component of an ecosystem?','أي مما يلي مكون حي للنظام البيئي؟',['Sunlight','Water','Plant','Soil'],['ضوء الشمس','الماء','النبات','التربة'],2),
    q('What does Biology study?','ماذا يدرس علم الأحياء؟',['Living things','Rocks','Stars','Machines'],['الكائنات الحية','الصخور','النجوم','الآلات'],0),
    q('What is Botany?','ما علم النبات؟',['Study of animals','Study of plants','Study of rocks','Study of stars'],['علم الحيوان','علم النبات','علم الصخور','علم النجوم'],1),
    q('Which branch studies insects?','أي فرع يدرس الحشرات؟',['Ecology','Genetics','Entomology','Cytology'],['علم البيئة','علم الوراثة','علم الحشرات','علم الخلية'],2),
    q('What is nutrition?','ما التغذية؟',['Producing sound','Obtaining and using nutrients','Moving from place to place','Producing light'],['إصدار الصوت','الحصول على الغذاء واستخدامه','الانتقال من مكان إلى آخر','إنتاج الضوء'],1),
    q('What is reproduction?','ما التكاثر؟',['Producing new organisms','Taking in food','Getting rid of waste','Responding to light'],['إنتاج كائنات حية جديدة','تناول الغذاء','التخلص من الفضلات','الاستجابة للضوء'],0),
    q('Which characteristic means responding to stimuli?','أي خاصية تعني الاستجابة للمؤثرات؟',['Growth','Nutrition','Irritability','Reproduction'],['النمو','التغذية','الاستجابة للمؤثرات','التكاثر'],2),
    q('How do green plants make their food?','كيف تصنع النباتات الخضراء غذاءها؟',['Respiration','Photosynthesis','Reproduction','Digestion'],['التنفس','البناء الضوئي','التكاثر','الهضم'],1),
    q('Which structure is usually found in plant cells but not animal cells?','أي تركيب يوجد عادةً في الخلايا النباتية ولا يوجد في الخلايا الحيوانية؟',['Cell wall','Cell membrane','Cytoplasm','Nucleus'],['الجدار الخلوي','الغشاء الخلوي','السيتوبلازم','النواة'],0),
    q('How many cells make up a unicellular organism?','كم خلية يتكون منها الكائن وحيد الخلية؟',['One','Two','Many','One hundred'],['واحدة','اثنتان','كثيرة','مئة'],0),
    q('Which is an example of a unicellular organism?','أي مما يلي مثال لكائن وحيد الخلية؟',['Human','Dog','Amoeba','Mango tree'],['الإنسان','الكلب','الأميبا','شجرة المانجو'],2),
    q('Which is an example of a multicellular organism?','أي مما يلي مثال لكائن متعدد الخلايا؟',['Amoeba','Human','Many bacteria','Yeast cell'],['الأميبا','الإنسان','كثير من أنواع البكتيريا','خلية خميرة'],1),
    q('What is the correct order of organization in multicellular organisms?','ما الترتيب الصحيح لمستويات التنظيم في الكائنات متعددة الخلايا؟',['Organs, cells, tissues','Cells, tissues, organs','Tissues, organs, cells','Cells, organs, tissues'],['أعضاء، خلايا، أنسجة','خلايا، أنسجة، أعضاء','أنسجة، أعضاء، خلايا','خلايا، أعضاء، أنسجة'],1),
  ]),
  Subject(id:'chemistry',name:lt('Chemistry','الكيمياء'),colorValue:0xFF8E24AA,icon:'⚗',lessons:[
    lesson('matter','States of Matter','حالات المادة','Matter commonly exists as solid, liquid and gas.','توجد المادة عادة في حالات صلبة وسائلة وغازية.'),
    lesson('atom','Atoms and Elements','الذرات والعناصر','An atom is a tiny unit of matter. An element contains atoms with the same number of protons.','الذرة وحدة صغيرة جدًا من المادة. والعنصر يتكون من ذرات لها العدد نفسه من البروتونات.'),
    lesson('mixtures','Mixtures','المخاليط','A mixture contains two or more substances that are physically combined and can often be separated.','المخلوط يحتوي على مادتين أو أكثر متحدتين فيزيائيًا ويمكن غالبًا فصلهما.'),
    lesson('acids','Acids and Bases','الأحماض والقواعد','Acids and bases have different properties. The pH scale is commonly used to describe how acidic or basic a solution is.','للأحماض والقواعد خصائص مختلفة. ويستخدم مقياس pH لوصف حموضة أو قاعدية المحلول.'),
  ],questions:[
    q('Which state has no fixed shape or volume?','أي حالة ليس لها شكل أو حجم ثابت؟',['Solid','Liquid','Gas','Ice'],['صلب','سائل','غاز','ثلج'],2),
    q('What is the centre of an atom called?','ماذا يسمى مركز الذرة؟',['Nucleus','Shell','Cell','Mixture'],['النواة','الغلاف','الخلية','المخلوط'],0),
    q('Which is a mixture?','أي مما يلي مخلوط؟',['Pure oxygen','Salt water','Gold element','Hydrogen'],['الأكسجين النقي','الماء المالح','عنصر الذهب','الهيدروجين'],1),
    q('A pH below 7 is generally…','قيمة pH أقل من 7 تكون عادة…',['Acidic','Basic','Neutral','Metallic'],['حمضية','قاعدية','متعادلـة','فلزية'],0),
  ]),
  Subject(id:'physics',name:lt('Physics','الفيزياء'),colorValue:0xFFEF6C00,icon:'⚡',lessons:[
    lesson('force','Force and Motion','القوة والحركة','A force is a push or pull that can change motion. Force is measured in newtons (N).','القوة هي دفع أو سحب يمكن أن يغير الحركة. وتقاس بالنيوتن (N).'),
    lesson('energy','Energy','الطاقة','Energy is the ability to do work. Common forms include kinetic, potential, thermal and electrical energy.','الطاقة هي القدرة على بذل شغل. ومن أشكالها الطاقة الحركية والوضعية والحرارية والكهربائية.'),
    lesson('electricity','Basic Electricity','الكهرباء الأساسية','An electric current is the flow of charge. Voltage provides the push that drives current through a circuit.','التيار الكهربائي هو تدفق الشحنة. والجهد يوفر القوة الدافعة للتيار في الدائرة.'),
    lesson('density','Density','الكثافة','Density is mass per unit volume: density = mass ÷ volume.','الكثافة هي الكتلة لكل وحدة حجم: الكثافة = الكتلة ÷ الحجم.'),
  ],questions:[
    q('What is the SI unit of force?','ما وحدة قياس القوة؟',['Joule','Watt','Newton','Pascal'],['جول','واط','نيوتن','باسكال'],2),
    q('Which energy is associated with motion?','أي طاقة ترتبط بالحركة؟',['Kinetic','Chemical','Nuclear','Sound only'],['حركية','كيميائية','نووية','صوتية فقط'],0),
    q('What flows in an electric circuit?','ماذا يتدفق في الدائرة الكهربائية؟',['Charge','Wood','Light only','Water'],['الشحنة','الخشب','الضوء فقط','الماء'],0),
    q('Density equals…','الكثافة تساوي…',['mass × volume','mass ÷ volume','volume ÷ mass','mass + volume'],['الكتلة × الحجم','الكتلة ÷ الحجم','الحجم ÷ الكتلة','الكتلة + الحجم'],1),
  ]),
  Subject(id:'geography',name:lt('Geography','الجغرافيا'),colorValue:0xFF00838F,icon:'◎',lessons:[
    lesson('plates','Tectonic Plates','الصفائح التكتونية','Earth’s crust is divided into large tectonic plates. Their movement can cause earthquakes, volcanoes and mountain building.','تنقسم قشرة الأرض إلى صفائح تكتونية كبيرة. ويمكن لحركتها أن تسبب الزلازل والبراكين وتكوين الجبال.'),
    lesson('weather','Weather and Climate','الطقس والمناخ','Weather describes short-term atmospheric conditions, while climate describes long-term patterns in a place.','الطقس يصف حالة الجو قصيرة المدى، بينما المناخ يصف الأنماط طويلة المدى في المكان.'),
    lesson('rivers','Rivers','الأنهار','A river is a natural flowing watercourse. Rivers can erode, transport and deposit materials.','النهر مجرى مائي طبيعي جارٍ. ويمكن للأنهار أن تنحت وتنقل وترسب المواد.'),
    lesson('population','Population','السكان','Population geography studies where people live, population size, density, movement and related patterns.','تدرس جغرافيا السكان أماكن إقامة الناس وحجم السكان والكثافة والهجرة والأنماط المرتبطة بها.'),
  ],questions:[
    q('What can plate movement cause?','ماذا يمكن أن تسبب حركة الصفائح؟',['Earthquakes','Only rain','Only wind','None'],['الزلازل','المطر فقط','الرياح فقط','لا شيء'],0),
    q('Climate refers mainly to…','المناخ يشير أساسًا إلى…',['Long-term patterns','One hour of weather','One storm','One day'],['الأنماط طويلة المدى','ساعة واحدة من الطقس','عاصفة واحدة','يوم واحد'],0),
    q('Which process removes soil or rock?','أي عملية تزيل التربة أو الصخور؟',['Erosion','Condensation','Freezing only','Illumination'],['التعرية','التكاثف','التجمد فقط','الإضاءة'],0),
    q('Population density means…','الكثافة السكانية تعني…',['People per unit area','Total rainfall','Number of rivers','Height of mountains'],['عدد السكان لكل وحدة مساحة','إجمالي الأمطار','عدد الأنهار','ارتفاع الجبال'],0),
  ]),
  Subject(id:'history',name:lt('History','التاريخ'),colorValue:0xFF6D4C41,icon:'⌂',lessons:[
    lesson('sources','Sources of History','مصادر التاريخ','Primary sources are original evidence from the period studied, such as letters, photographs and official records. Secondary sources interpret primary evidence.','المصادر الأولية أدلة أصلية من الفترة المدروسة مثل الرسائل والصور والسجلات الرسمية. أما الثانوية فتفسر الأدلة الأولية.'),
    lesson('colonial','Colonial Administration','الإدارة الاستعمارية','Colonial powers used different systems of administration, including direct and indirect rule, depending on the territory and period.','استخدمت القوى الاستعمارية أنظمة مختلفة للإدارة، منها الحكم المباشر وغير المباشر، حسب الإقليم والفترة.'),
    lesson('trade','Coastal Trade','التجارة الساحلية','Coastal trade involves exchange of goods between ports and coastal communities. It helped connect inland and overseas markets.','التجارة الساحلية هي تبادل السلع بين الموانئ والمجتمعات الساحلية، وقد ساعدت في ربط الأسواق الداخلية والخارجية.'),
    lesson('education','Modern Education','التعليم الحديث','Modern education introduced organized schools, new subjects, examinations and new forms of professional training in many societies.','أدخل التعليم الحديث المدارس المنظمة والمواد الجديدة والامتحانات وأشكالًا جديدة من التدريب المهني في مجتمعات كثيرة.'),
  ],questions:[
    q('Which is a primary source?','أي مما يلي مصدر أولي؟',['A later textbook','An original letter','A modern summary','A revision guide'],['كتاب مدرسي لاحق','رسالة أصلية','ملخص حديث','دليل مراجعة'],1),
    q('Indirect rule means…','الحكم غير المباشر يعني…',['Using local authorities within a colonial system','No government','Only military rule','Private business rule'],['استخدام سلطات محلية داخل نظام استعماري','عدم وجود حكومة','الحكم العسكري فقط','حكم الشركات الخاصة'],0),
    q('Coastal trade mainly uses…','التجارة الساحلية تعتمد أساسًا على…',['Ports and sea routes','Deserts only','Airports only','Mountain tunnels'],['الموانئ والطرق البحرية','الصحارى فقط','المطارات فقط','الأنفاق الجبلية'],0),
    q('A historian studies evidence to…','يدرس المؤرخ الأدلة من أجل…',['Understand and interpret the past','Predict rainfall only','Build roads','Measure temperature only'],['فهم الماضي وتفسيره','توقع الأمطار فقط','بناء الطرق','قياس الحرارة فقط'],0),
  ]),
  Subject(id:'commerce',name:lt('Commerce','التجارة'),colorValue:0xFFC2185B,icon:'↗',lessons:[
    lesson('trade','Trade','التجارة','Trade is the buying and selling of goods and services. It may be domestic or international.','التجارة هي شراء وبيع السلع والخدمات، وقد تكون داخلية أو دولية.'),
    lesson('business','Business Activities','الأنشطة التجارية','Business activities include production, distribution and the provision of services to satisfy human wants.','تشمل الأنشطة التجارية الإنتاج والتوزيع وتقديم الخدمات لإشباع حاجات الإنسان.'),
    lesson('banking','Banking','المصارف','Banks accept deposits, provide loans and offer payment and other financial services.','تقبل المصارف الودائع وتقدم القروض وخدمات الدفع والخدمات المالية الأخرى.'),
    lesson('insurance','Insurance','التأمين','Insurance is an arrangement that provides financial protection against specified risks in return for a premium.','التأمين ترتيب يوفر حماية مالية من مخاطر محددة مقابل قسط.'),
  ],questions:[
    q('What is international trade?','ما المقصود بالتجارة الدولية؟',['Trade within one family','Trade between countries','Free goods only','No buying or selling'],['تجارة داخل أسرة','تجارة بين الدول','سلع مجانية فقط','دون شراء أو بيع'],1),
    q('Which is a service?','أي مما يلي خدمة؟',['Teaching','Bread','Chair','Phone'],['التدريس','الخبز','الكرسي','الهاتف'],0),
    q('Banks commonly provide…','ماذا تقدم المصارف عادة؟',['Loans','Rain','Crops','Roads'],['القروض','المطر','المحاصيل','الطرق'],0),
    q('Insurance protects mainly against…','التأمين يحمي أساسًا من…',['Specified risks','All exams','School subjects','Weather forecasts only'],['مخاطر محددة','كل الامتحانات','المواد الدراسية','توقعات الطقس فقط'],0),
  ]),
  Subject(id:'account',name:lt('Account','المحاسبة'),colorValue:0xFF3949AB,icon:'▦',lessons:[
    lesson('assets','Assets and Liabilities','الأصول والالتزامات','Assets are resources owned by a business. Liabilities are amounts owed to outsiders. Assets = Capital + Liabilities.','الأصول موارد يمتلكها النشاط التجاري، والالتزامات مبالغ مستحقة للآخرين. الأصول = رأس المال + الالتزامات.'),
    lesson('transactions','Transactions','المعاملات','A transaction is a business event that can be measured in money and affects accounting records.','المعاملة حدث تجاري يمكن قياسه بالنقود ويؤثر في السجلات المحاسبية.'),
    lesson('ledger','Ledger Accounts','حسابات دفتر الأستاذ','A ledger groups transactions into individual accounts so that balances can be determined.','يجمع دفتر الأستاذ المعاملات في حسابات منفصلة حتى يمكن تحديد الأرصدة.'),
    lesson('profit','Profit and Loss','الربح والخسارة','Profit occurs when revenue is greater than expenses. A loss occurs when expenses are greater than revenue.','يحدث الربح عندما تكون الإيرادات أكبر من المصروفات، وتحدث الخسارة عندما تكون المصروفات أكبر من الإيرادات.'),
  ],questions:[
    q('Which equation is correct?','أي معادلة صحيحة؟',['Assets = Capital + Liabilities','Assets = Sales - Cash','Capital = Assets + Sales','Liabilities = Assets + Capital'],['الأصول = رأس المال + الالتزامات','الأصول = المبيعات - النقدية','رأس المال = الأصول + المبيعات','الالتزامات = الأصول + رأس المال'],0),
    q('Which is an asset?','أي مما يلي أصل؟',['Cash owned by the business','Loan owed','Supplier debt','Unpaid bill'],['نقدية يملكها النشاط','قرض مستحق','دين للمورد','فاتورة غير مدفوعة'],0),
    q('Profit equals…','الربح يساوي…',['Revenue - Expenses','Expenses - Revenue','Assets + Liabilities','Capital + Sales'],['الإيرادات - المصروفات','المصروفات - الإيرادات','الأصول + الالتزامات','رأس المال + المبيعات'],0),
    q('A ledger is used to…','يستخدم دفتر الأستاذ من أجل…',['Group transactions into accounts','Predict weather','Teach biology','Store water'],['تجميع المعاملات في حسابات','توقع الطقس','تدريس الأحياء','تخزين الماء'],0),
  ]),
];


final List<Grade> grades = [
  Grade(id: 'p8', name: lt('Primary 8', 'الصف الثامن الأساسي')),
  Grade(id: 's1', name: lt('Senior 1', 'الصف الأول الثانوي')),
  Grade(id: 's2', name: lt('Senior 2', 'الصف الثاني الثانوي')),
  Grade(id: 's3', name: lt('Senior 3', 'الصف الثالث الثانوي')),
];

// Subjects currently included in the first offline curriculum.
// More grade-specific content can be assigned here as the curriculum grows.
final Map<String, List<String>> gradeSubjectIds = {
  'p8': ['mathematics', 'english', 'biology', 'geography'],
  's1': ['mathematics', 'english', 'biology', 'chemistry', 'physics', 'geography', 'history', 'commerce', 'account'],
  's2': ['mathematics', 'english', 'biology', 'chemistry', 'physics', 'geography', 'history', 'commerce', 'account'],
  's3': ['mathematics', 'english', 'biology', 'chemistry', 'physics', 'geography', 'history', 'commerce', 'account'],
};
