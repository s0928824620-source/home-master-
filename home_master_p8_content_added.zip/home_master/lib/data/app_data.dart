import '../models/models.dart';

LocalizedText lt(String en, String ar) => LocalizedText(en, ar);
Lesson lesson(String id, String enTitle, String arTitle, String enBody, String arBody) => Lesson(id:id,title:lt(enTitle,arTitle),body:lt(enBody,arBody));
Question q(String en, String ar, List<String> enO, List<String> arO, int a) => Question(question:lt(en,ar),options:List.generate(enO.length,(i)=>lt(enO[i],arO[i])),answer:a);

final List<Subject> subjects = [
  Subject(id:'mathematics',name:lt('Mathematics','الرياضيات'),colorValue:0xFF1565C0,icon:'∑',lessons:[
    lesson('algebra','Algebra Basics','أساسيات الجبر','An equation has two equal sides. Solve 2x + 6 = 16 by subtracting 6, then dividing by 2, so x = 5.','المعادلة لها طرفان متساويان. لحل 2x + 6 = 16 نطرح 6 ثم نقسم على 2، فنحصل على x = 5.'),
    lesson('fractions','Fractions','الكسور','A fraction represents a part of a whole. In 3/4, 3 is the numerator and 4 is the denominator.','الكسر يمثل جزءًا من كل. في 3/4 البسط هو 3 والمقام هو 4.'),
    lesson('percentages','Percentages','النسب المئوية','A percentage is a fraction out of 100. 25% of 80 is 20.','النسبة المئوية كسر من 100. ‏25% من 80 تساوي 20.'),
    lesson('indices','Indices and Powers','الأسس والقوى','An index shows repeated multiplication. 2³ = 2 × 2 × 2 = 8.','الأس يوضح تكرار الضرب. 2³ = 2 × 2 × 2 = 8.'),
  ],questions:[
    q('What is x in 2x + 6 = 16?','ما قيمة x في 2x + 6 = 16؟',['4','5','6','7'],['٤','٥','٦','٧'],1),
    q('What is 7 × 8?','كم يساوي 7 × 8؟',['54','56','64','48'],['٥٤','٥٦','٦٤','٤٨'],1),
    q('What is 3/4 of 20?','كم يساوي 3/4 من 20؟',['10','12','15','16'],['١٠','١٢','١٥','١٦'],2),
    q('What is 25% of 80?','كم تساوي 25% من 80؟',['15','20','25','30'],['١٥','٢٠','٢٥','٣٠'],1),
    q('What is 2³?','ما قيمة 2³؟',['6','8','9','12'],['٦','٨','٩','١٢'],1),
  ]),
  Subject(id:'english',name:lt('English','اللغة الإنجليزية'),colorValue:0xFFD32F2F,icon:'A',lessons:[
    lesson('parts','Parts of Speech','أقسام الكلام','A noun names a person, place, thing or idea. A verb shows an action or state. An adjective describes a noun.','الاسم يدل على شخص أو مكان أو شيء أو فكرة. الفعل يدل على حدث أو حالة. الصفة تصف الاسم.'),
    lesson('tenses','Basic Tenses','الأزمنة الأساسية','The present describes regular actions: I study. The past describes completed actions: I studied. The future can use will: I will study.','المضارع يصف الأفعال المعتادة: I study. الماضي يصف الأفعال المكتملة: I studied. المستقبل يمكن أن يستخدم will: I will study.'),
    lesson('sentence','Sentence Structure','تركيب الجملة','A basic English sentence often has a subject, verb and object: The student reads a book.','غالبًا تتكون الجملة الإنجليزية الأساسية من فاعل وفعل ومفعول به: The student reads a book.'),
    lesson('vocabulary','Vocabulary Skills','مهارات المفردات','Learn new words using context, synonyms and examples. Keep a small vocabulary list and review it regularly.','تعلم الكلمات الجديدة باستخدام السياق والمرادفات والأمثلة. احتفظ بقائمة مفردات وراجعها باستمرار.'),
  ],questions:[
    q('Which word is a verb?','أي كلمة هي فعل؟',['school','run','beautiful','student'],['مدرسة','يجري','جميل','طالب'],1),
    q('Choose the past tense of “go”.','اختر صيغة الماضي للفعل go.',['goed','goes','went','going'],['goed','goes','went','going'],2),
    q('Which is a noun?','أي كلمة اسم؟',['quickly','teacher','write','beautiful'],['بسرعة','معلم','يكتب','جميل'],1),
    q('Choose the correct sentence.','اختر الجملة الصحيحة.',['He go to school.','He goes to school.','He going school.','He gone school.'],['He go to school.','He goes to school.','He going school.','He gone school.'],1),
    q('What is the opposite of “easy”?','ما عكس كلمة easy؟',['simple','hard','light','early'],['بسيط','صعب','خفيف','مبكر'],1),
  ]),
  Subject(id:'biology',name:lt('Biology','الأحياء'),colorValue:0xFF2E7D32,icon:'⌁',lessons:[
    lesson('cell','The Cell','الخلية','The cell is the basic structural and functional unit of life.','الخلية هي الوحدة الأساسية في تركيب ووظيفة الكائنات الحية.'),
    lesson('photosynthesis','Photosynthesis','البناء الضوئي','Plants use light energy, water and carbon dioxide to make food and release oxygen.','تستخدم النباتات ضوء الشمس والماء وثاني أكسيد الكربون لصنع الغذاء وإطلاق الأكسجين.'),
    lesson('nutrition','Human Nutrition','تغذية الإنسان','A balanced diet supplies carbohydrates, proteins, fats, vitamins, minerals, fibre and water in suitable amounts.','الغذاء المتوازن يوفر الكربوهيدرات والبروتينات والدهون والفيتامينات والمعادن والألياف والماء بكميات مناسبة.'),
    lesson('ecosystem','Ecosystems','الأنظمة البيئية','An ecosystem includes living organisms and the non-living environment in which they interact.','يشمل النظام البيئي الكائنات الحية والبيئة غير الحية التي تتفاعل معها.'),
  ],questions:[
    q('What is the basic unit of life?','ما الوحدة الأساسية للحياة؟',['Tissue','Cell','Organ','System'],['نسيج','خلية','عضو','جهاز'],1),
    q('What gas is released during photosynthesis?','ما الغاز الذي يطلق أثناء البناء الضوئي؟',['Nitrogen','Oxygen','Hydrogen','Helium'],['النيتروجين','الأكسجين','الهيدروجين','الهيليوم'],1),
    q('Which nutrient mainly builds and repairs tissues?','أي عنصر غذائي يساعد أساسًا في بناء وإصلاح الأنسجة؟',['Protein','Water','Salt','Fibre'],['البروتين','الماء','الملح','الألياف'],0),
    q('Which is a living component of an ecosystem?','أي مما يلي مكون حي للنظام البيئي؟',['Sunlight','Water','Plant','Soil'],['ضوء الشمس','الماء','النبات','التربة'],2),
  ]),
  Subject(id:'chemistry',name:lt('Chemistry','الكيمياء'),colorValue:0xFF8E24AA,icon:'⚗',lessons:[
    lesson('matter','States of Matter','حالات المادة','Matter commonly exists as solid, liquid and gas.','توجد المادة عادة في حالات صلبة وسائلة وغازية.'),
    lesson('atom','Atoms and Elements','الذرات والعناصر','An atom is a tiny unit of matter. An element contains atoms with the same number of protons.','الذرة وحدة صغيرة جدًا من المادة. والعنصر يتكون من ذرات لها العدد نفسه من البروتونات.'),
    lesson('mixtures','Mixtures','المخاليط','A mixture contains two or more substances that are physically combined and can often be separated.','المخلوط يحتوي على مادتين أو أكثر متحدتين فيزيائيًا ويمكن غالبًا فصلهما.'),
    lesson('acids','Acids and Bases','الأحماض والقواعد','Acids and bases have different properties. The pH scale is commonly used to describe how acidic or basic a solution is.','للأحماض والقواعد خصائص مختلفة. ويستخدم مقياس pH لوصف حموضة أو قاعدية المحلول.'),
  ],questions:[
    q('Which state has no fixed shape or volume?','أي حالة ليس لها شكل أو حجم ثابت؟',['Solid','Liquid','Gas','Ice'],['صلب','سائل','غاز','ثلج'],2),
    q('What is the centre of an atom called?','ماذا يسمى مركز الذرة؟',['Nucleus','Shell','Cell','Mixture'],['النواة','الغلاف','الخلية','المخلوط'],0),
    q('Which is a mixture?','أي مما يلي مخلوط؟',['Pure oxygen','Salt water','Gold element','Hydrogen'],['الأكسجين النقي','الماء المالح','عنصر الذهب','الهيدروجين'],1),
    q('A pH below 7 is generally…','قيمة pH أقل من 7 تكون عادة…',['Acidic','Basic','Neutral','Metallic'],['حمضية','قاعدية','متعادلـة','فلزية'],0),
  ]),
  Subject(id:'physics',name:lt('Physics','الفيزياء'),colorValue:0xFFEF6C00,icon:'⚡',lessons:[
    lesson('force','Force and Motion','القوة والحركة','A force is a push or pull that can change motion. Force is measured in newtons (N).','القوة هي دفع أو سحب يمكن أن يغير الحركة. وتقاس بالنيوتن (N).'),
    lesson('energy','Energy','الطاقة','Energy is the ability to do work. Common forms include kinetic, potential, thermal and electrical energy.','الطاقة هي القدرة على بذل شغل. ومن أشكالها الطاقة الحركية والوضعية والحرارية والكهربائية.'),
    lesson('electricity','Basic Electricity','الكهرباء الأساسية','An electric current is the flow of charge. Voltage provides the push that drives current through a circuit.','التيار الكهربائي هو تدفق الشحنة. والجهد يوفر القوة الدافعة للتيار في الدائرة.'),
    lesson('density','Density','الكثافة','Density is mass per unit volume: density = mass ÷ volume.','الكثافة هي الكتلة لكل وحدة حجم: الكثافة = الكتلة ÷ الحجم.'),
  ],questions:[
    q('What is the SI unit of force?','ما وحدة قياس القوة؟',['Joule','Watt','Newton','Pascal'],['جول','واط','نيوتن','باسكال'],2),
    q('Which energy is associated with motion?','أي طاقة ترتبط بالحركة؟',['Kinetic','Chemical','Nuclear','Sound only'],['حركية','كيميائية','نووية','صوتية فقط'],0),
    q('What flows in an electric circuit?','ماذا يتدفق في الدائرة الكهربائية؟',['Charge','Wood','Light only','Water'],['الشحنة','الخشب','الضوء فقط','الماء'],0),
    q('Density equals…','الكثافة تساوي…',['mass × volume','mass ÷ volume','volume ÷ mass','mass + volume'],['الكتلة × الحجم','الكتلة ÷ الحجم','الحجم ÷ الكتلة','الكتلة + الحجم'],1),
  ]),
  Subject(id:'geography',name:lt('Geography','الجغرافيا'),colorValue:0xFF00838F,icon:'◎',lessons:[
    lesson('plates','Tectonic Plates','الصفائح التكتونية','Earth’s crust is divided into large tectonic plates. Their movement can cause earthquakes, volcanoes and mountain building.','تنقسم قشرة الأرض إلى صفائح تكتونية كبيرة. ويمكن لحركتها أن تسبب الزلازل والبراكين وتكوين الجبال.'),
    lesson('weather','Weather and Climate','الطقس والمناخ','Weather describes short-term atmospheric conditions, while climate describes long-term patterns in a place.','الطقس يصف حالة الجو قصيرة المدى، بينما المناخ يصف الأنماط طويلة المدى في المكان.'),
    lesson('rivers','Rivers','الأنهار','A river is a natural flowing watercourse. Rivers can erode, transport and deposit materials.','النهر مجرى مائي طبيعي جارٍ. ويمكن للأنهار أن تنحت وتنقل وترسب المواد.'),
    lesson('population','Population','السكان','Population geography studies where people live, population size, density, movement and related patterns.','تدرس جغرافيا السكان أماكن إقامة الناس وحجم السكان والكثافة والهجرة والأنماط المرتبطة بها.'),
  ],questions:[
    q('What can plate movement cause?','ماذا يمكن أن تسبب حركة الصفائح؟',['Earthquakes','Only rain','Only wind','None'],['الزلازل','المطر فقط','الرياح فقط','لا شيء'],0),
    q('Climate refers mainly to…','المناخ يشير أساسًا إلى…',['Long-term patterns','One hour of weather','One storm','One day'],['الأنماط طويلة المدى','ساعة واحدة من الطقس','عاصفة واحدة','يوم واحد'],0),
    q('Which process removes soil or rock?','أي عملية تزيل التربة أو الصخور؟',['Erosion','Condensation','Freezing only','Illumination'],['التعرية','التكاثف','التجمد فقط','الإضاءة'],0),
    q('Population density means…','الكثافة السكانية تعني…',['People per unit area','Total rainfall','Number of rivers','Height of mountains'],['عدد السكان لكل وحدة مساحة','إجمالي الأمطار','عدد الأنهار','ارتفاع الجبال'],0),
  ]),
  Subject(id:'history',name:lt('History','التاريخ'),colorValue:0xFF6D4C41,icon:'⌂',lessons:[
    lesson('sources','Sources of History','مصادر التاريخ','Primary sources are original evidence from the period studied, such as letters, photographs and official records. Secondary sources interpret primary evidence.','المصادر الأولية أدلة أصلية من الفترة المدروسة مثل الرسائل والصور والسجلات الرسمية. أما الثانوية فتفسر الأدلة الأولية.'),
    lesson('colonial','Colonial Administration','الإدارة الاستعمارية','Colonial powers used different systems of administration, including direct and indirect rule, depending on the territory and period.','استخدمت القوى الاستعمارية أنظمة مختلفة للإدارة، منها الحكم المباشر وغير المباشر، حسب الإقليم والفترة.'),
    lesson('trade','Coastal Trade','التجارة الساحلية','Coastal trade involves exchange of goods between ports and coastal communities. It helped connect inland and overseas markets.','التجارة الساحلية هي تبادل السلع بين الموانئ والمجتمعات الساحلية، وقد ساعدت في ربط الأسواق الداخلية والخارجية.'),
    lesson('education','Modern Education','التعليم الحديث','Modern education introduced organized schools, new subjects, examinations and new forms of professional training in many societies.','أدخل التعليم الحديث المدارس المنظمة والمواد الجديدة والامتحانات وأشكالًا جديدة من التدريب المهني في مجتمعات كثيرة.'),
  ],questions:[
    q('Which is a primary source?','أي مما يلي مصدر أولي؟',['A later textbook','An original letter','A modern summary','A revision guide'],['كتاب مدرسي لاحق','رسالة أصلية','ملخص حديث','دليل مراجعة'],1),
    q('Indirect rule means…','الحكم غير المباشر يعني…',['Using local authorities within a colonial system','No government','Only military rule','Private business rule'],['استخدام سلطات محلية داخل نظام استعماري','عدم وجود حكومة','الحكم العسكري فقط','حكم الشركات الخاصة'],0),
    q('Coastal trade mainly uses…','التجارة الساحلية تعتمد أساسًا على…',['Ports and sea routes','Deserts only','Airports only','Mountain tunnels'],['الموانئ والطرق البحرية','الصحارى فقط','المطارات فقط','الأنفاق الجبلية'],0),
    q('A historian studies evidence to…','يدرس المؤرخ الأدلة من أجل…',['Understand and interpret the past','Predict rainfall only','Build roads','Measure temperature only'],['فهم الماضي وتفسيره','توقع الأمطار فقط','بناء الطرق','قياس الحرارة فقط'],0),
  ]),
  Subject(id:'commerce',name:lt('Commerce','التجارة'),colorValue:0xFFC2185B,icon:'↗',lessons:[
    lesson('trade','Trade','التجارة','Trade is the buying and selling of goods and services. It may be domestic or international.','التجارة هي شراء وبيع السلع والخدمات، وقد تكون داخلية أو دولية.'),
    lesson('business','Business Activities','الأنشطة التجارية','Business activities include production, distribution and the provision of services to satisfy human wants.','تشمل الأنشطة التجارية الإنتاج والتوزيع وتقديم الخدمات لإشباع حاجات الإنسان.'),
    lesson('banking','Banking','المصارف','Banks accept deposits, provide loans and offer payment and other financial services.','تقبل المصارف الودائع وتقدم القروض وخدمات الدفع والخدمات المالية الأخرى.'),
    lesson('insurance','Insurance','التأمين','Insurance is an arrangement that provides financial protection against specified risks in return for a premium.','التأمين ترتيب يوفر حماية مالية من مخاطر محددة مقابل قسط.'),
  ],questions:[
    q('What is international trade?','ما المقصود بالتجارة الدولية؟',['Trade within one family','Trade between countries','Free goods only','No buying or selling'],['تجارة داخل أسرة','تجارة بين الدول','سلع مجانية فقط','دون شراء أو بيع'],1),
    q('Which is a service?','أي مما يلي خدمة؟',['Teaching','Bread','Chair','Phone'],['التدريس','الخبز','الكرسي','الهاتف'],0),
    q('Banks commonly provide…','ماذا تقدم المصارف عادة؟',['Loans','Rain','Crops','Roads'],['القروض','المطر','المحاصيل','الطرق'],0),
    q('Insurance protects mainly against…','التأمين يحمي أساسًا من…',['Specified risks','All exams','School subjects','Weather forecasts only'],['مخاطر محددة','كل الامتحانات','المواد الدراسية','توقعات الطقس فقط'],0),
  ]),
  Subject(id:'account',name:lt('Account','المحاسبة'),colorValue:0xFF3949AB,icon:'▦',lessons:[
    lesson('assets','Assets and Liabilities','الأصول والالتزامات','Assets are resources owned by a business. Liabilities are amounts owed to outsiders. Assets = Capital + Liabilities.','الأصول موارد يمتلكها النشاط التجاري، والالتزامات مبالغ مستحقة للآخرين. الأصول = رأس المال + الالتزامات.'),
    lesson('transactions','Transactions','المعاملات','A transaction is a business event that can be measured in money and affects accounting records.','المعاملة حدث تجاري يمكن قياسه بالنقود ويؤثر في السجلات المحاسبية.'),
    lesson('ledger','Ledger Accounts','حسابات دفتر الأستاذ','A ledger groups transactions into individual accounts so that balances can be determined.','يجمع دفتر الأستاذ المعاملات في حسابات منفصلة حتى يمكن تحديد الأرصدة.'),
    lesson('profit','Profit and Loss','الربح والخسارة','Profit occurs when revenue is greater than expenses. A loss occurs when expenses are greater than revenue.','يحدث الربح عندما تكون الإيرادات أكبر من المصروفات، وتحدث الخسارة عندما تكون المصروفات أكبر من الإيرادات.'),
  ],questions:[
    q('Which equation is correct?','أي معادلة صحيحة؟',['Assets = Capital + Liabilities','Assets = Sales - Cash','Capital = Assets + Sales','Liabilities = Assets + Capital'],['الأصول = رأس المال + الالتزامات','الأصول = المبيعات - النقدية','رأس المال = الأصول + المبيعات','الالتزامات = الأصول + رأس المال'],0),
    q('Which is an asset?','أي مما يلي أصل؟',['Cash owned by the business','Loan owed','Supplier debt','Unpaid bill'],['نقدية يملكها النشاط','قرض مستحق','دين للمورد','فاتورة غير مدفوعة'],0),
    q('Profit equals…','الربح يساوي…',['Revenue - Expenses','Expenses - Revenue','Assets + Liabilities','Capital + Sales'],['الإيرادات - المصروفات','المصروفات - الإيرادات','الأصول + الالتزامات','رأس المال + المبيعات'],0),
    q('A ledger is used to…','يستخدم دفتر الأستاذ من أجل…',['Group transactions into accounts','Predict weather','Teach biology','Store water'],['تجميع المعاملات في حسابات','توقع الطقس','تدريس الأحياء','تخزين الماء'],0),
  ]),

  // Original bilingual P8 starter content; intended for offline study.
  Subject(id:'p8_mathematics',name:lt('Mathematics','الرياضيات'),colorValue:0xFF1565C0,icon:'∑',lessons:[
    lesson("p8_math_fractions","Fractions and Equivalent Fractions","الكسور والكسور المتكافئة","A fraction shows part of a whole. The numerator is the top number and the denominator is the bottom number. Equivalent fractions have the same value. Example: 1/2 = 2/4 because both represent half. To make an equivalent fraction, multiply or divide the numerator and denominator by the same non-zero number.\n\nExample: Simplify 6/8. Divide the numerator and denominator by 2: 6 ÷ 2 = 3 and 8 ÷ 2 = 4. Answer: 3/4.","الكسر يعبّر عن جزء من كل. البسط هو العدد العلوي والمقام هو العدد السفلي. الكسور المتكافئة لها القيمة نفسها. مثال: ١/٢ = ٢/٤ لأن كليهما يمثل النصف. للحصول على كسر مكافئ، نضرب البسط والمقام أو نقسمهما على العدد نفسه غير الصفري.\n\nمثال: بسّط ٦/٨. نقسم البسط والمقام على ٢: ٦ ÷ ٢ = ٣ و٨ ÷ ٢ = ٤. الإجابة: ٣/٤."),
    lesson("p8_math_percentages","Percentages","النسب المئوية","Percent means “per hundred”. A percentage can be written as a fraction out of 100. To find a percentage of a number, convert the percentage to a fraction or decimal and multiply. For example, 25% = 25/100 = 0.25.\n\nExample: Find 20% of 150. 20/100 × 150 = 30. Answer: 30.","تعني النسبة المئوية «من كل مئة». ويمكن كتابة النسبة المئوية ككسر مقامه ١٠٠. لإيجاد نسبة من عدد، نحوّل النسبة إلى كسر أو عدد عشري ثم نضرب. مثال: ٢٥٪ = ٢٥/١٠٠ = ٠٫٢٥.\n\nمثال: أوجد ٢٠٪ من ١٥٠. ‏٢٠/١٠٠ × ١٥٠ = ٣٠. الإجابة: ٣٠."),
    lesson("p8_math_algebra","Simple Algebra","الجبر البسيط","A variable is a letter that represents an unknown number, such as x. An equation says that two expressions are equal. To solve a simple equation, use the same operation on both sides to keep the equality balanced.\n\nExample: x + 7 = 12. Subtract 7 from both sides: x = 12 − 7 = 5.","المتغير حرف يمثّل عددًا مجهولًا مثل x. والمعادلة تعني أن عبارتين متساويتان. لحل معادلة بسيطة، نستخدم العملية نفسها على الطرفين للمحافظة على التساوي.\n\nمثال: x + ٧ = ١٢. نطرح ٧ من الطرفين: x = ١٢ − ٧ = ٥."),
  ],questions:[
    q("Which fraction is equivalent to 1/2?","أي كسر يكافئ ١/٢؟",["2/3", "2/4", "3/5", "4/5"],["٢/٣", "٢/٤", "٣/٥", "٤/٥"],1),
    q("Simplify 6/8.","بسّط ٦/٨.",["2/3", "3/4", "4/6", "1/4"],["٢/٣", "٣/٤", "٤/٦", "١/٤"],1),
    q("What is 10% of 80?","كم تساوي ١٠٪ من ٨٠؟",["4", "8", "10", "18"],["٤", "٨", "١٠", "١٨"],1),
    q("Write 50% as a simplest fraction.","اكتب ٥٠٪ في صورة كسر مبسّط.",["1/4", "1/3", "1/2", "2/3"],["١/٤", "١/٣", "١/٢", "٢/٣"],2),
    q("Solve: x + 9 = 14.","حل: x + ٩ = ١٤.",["3", "4", "5", "6"],["٣", "٤", "٥", "٦"],2),
    q("If 3x = 18, what is x?","إذا كان ٣x = ١٨، فما قيمة x؟",["3", "6", "9", "15"],["٣", "٦", "٩", "١٥"],1),
  ]),

  Subject(id:'p8_english',name:lt('English','اللغة الإنجليزية'),colorValue:0xFFD32F2F,icon:'A',lessons:[
    lesson("p8_english_parts","Parts of Speech","أقسام الكلام","A noun names a person, place, thing or idea. A verb expresses an action or state. An adjective describes a noun. An adverb often tells how, when or where an action happens.\n\nExample: “The clever pupil writes neatly.” Pupil is a noun, clever is an adjective, writes is a verb, and neatly is an adverb.","الاسم (Noun) يسمّي شخصًا أو مكانًا أو شيئًا أو فكرة. والفعل (Verb) يعبّر عن فعل أو حالة. والصفة (Adjective) تصف الاسم. والظرف (Adverb) يوضح غالبًا كيف أو متى أو أين يحدث الفعل.\n\nمثال: “The clever pupil writes neatly.” كلمة pupil اسم، وclever صفة، وwrites فعل، وneatly ظرف."),
    lesson("p8_english_tenses","Present and Past Tenses","زمن المضارع والماضي","The simple present describes habits, facts and regular actions: “I walk to school.” The simple past describes completed actions: “I walked to school yesterday.” Many regular verbs form the past by adding -ed, but some verbs are irregular, such as go → went.\n\nExample: Today I play football. Yesterday I played football. The verb changes from play to played.","يُستخدم المضارع البسيط للعادات والحقائق والأفعال المتكررة: “I walk to school.” ويُستخدم الماضي البسيط للأفعال التي انتهت: “I walked to school yesterday.” تُكوَّن صيغة الماضي في كثير من الأفعال المنتظمة بإضافة -ed، لكن بعض الأفعال شاذة مثل go ← went.\n\nمثال: اليوم ألعب كرة القدم: Today I play football. أمس لعبت كرة القدم: Yesterday I played football. تغيّر الفعل من play إلى played."),
    lesson("p8_english_comprehension","Reading Comprehension","فهم المقروء","Read a passage carefully. Identify the main idea, important details and the meaning of unfamiliar words from context. Answer using information in the passage rather than guessing.\n\nPassage: “Mary planted two mango trees beside her home. She waters them every morning.” Main idea: Mary is caring for young mango trees.","اقرأ القطعة بعناية. حدّد الفكرة الرئيسية والتفاصيل المهمة ومعاني الكلمات الجديدة من السياق. أجب اعتمادًا على معلومات القطعة بدلًا من التخمين.\n\nقطعة: «زرعت ماري شجرتي مانجو بجانب منزلها. وهي تسقيهما كل صباح». الفكرة الرئيسية: ماري تعتني بشجرتي مانجو صغيرتين."),
  ],questions:[
    q("Which word is a verb in “Birds fly”?","ما الفعل في جملة “Birds fly”؟",["Birds", "fly", "the", "blue"],["Birds", "fly", "the", "blue"],1),
    q("Which word is an adjective?","أي كلمة صفة؟",["quickly", "school", "beautiful", "run"],["بسرعة", "مدرسة", "جميل", "يجري"],2),
    q("Choose the past tense of “go”.","اختر الماضي من الفعل “go”.",["goed", "goes", "went", "going"],["goed", "goes", "went", "going"],2),
    q("Which sentence is in the simple present?","أي جملة في المضارع البسيط؟",["She cooked yesterday.", "She cooks every day.", "She will cook tomorrow.", "She is cooking now."],["She cooked yesterday.", "She cooks every day.", "She will cook tomorrow.", "She is cooking now."],1),
    q("In the passage, when does Mary water the trees?","في القطعة، متى تسقي ماري الأشجار؟",["At night", "Every morning", "Every week", "At noon"],["ليلًا", "كل صباح", "كل أسبوع", "وقت الظهر"],1),
    q("What is the main idea of the passage?","ما الفكرة الرئيسية للقطعة؟",["Mary sells mangoes", "Mary cares for mango trees", "Mary travels", "Mary cuts trees"],["ماري تبيع المانجو", "ماري تعتني بأشجار المانجو", "ماري تسافر", "ماري تقطع الأشجار"],1),
  ]),

  Subject(id:'p8_science',name:lt('Science','العلوم'),colorValue:0xFF2E7D32,icon:'⚗',lessons:[
    lesson("p8_science_cells","Living Things and Cells","الكائنات الحية والخلايا","Living things carry out life processes such as nutrition, growth, respiration, reproduction and responding to their surroundings. A cell is the basic structural unit of living things. Some organisms are made of one cell, while plants and animals are made of many cells.\n\nExample: A goat grows, needs food, breathes and reproduces. These are signs that it is living.","تقوم الكائنات الحية بعمليات الحياة مثل التغذية والنمو والتنفس والتكاثر والاستجابة للبيئة. الخلية هي الوحدة الأساسية في تركيب الكائنات الحية. بعض الكائنات تتكون من خلية واحدة، بينما تتكون النباتات والحيوانات من خلايا كثيرة.\n\nمثال: ينمو الماعز ويحتاج إلى الغذاء ويتنفس ويتكاثر. هذه علامات على أنه كائن حي."),
    lesson("p8_science_matter","States of Matter","حالات المادة","Matter has mass and occupies space. The three common states are solid, liquid and gas. A solid keeps its shape and volume; a liquid keeps its volume but takes the shape of its container; a gas spreads to fill its container.\n\nExample: Ice is solid water. When it melts, it becomes liquid water. When water evaporates, it becomes water vapour, a gas.","المادة لها كتلة وتشغل حيزًا. الحالات الثلاث الشائعة هي الصلبة والسائلة والغازية. يحتفظ الصلب بشكله وحجمه، ويحتفظ السائل بحجمه ويأخذ شكل الوعاء، أما الغاز فينتشر ليملأ الوعاء.\n\nمثال: الثلج ماء في الحالة الصلبة. وعندما ينصهر يصبح ماءً سائلًا. وعندما يتبخر الماء يتحول إلى بخار ماء، وهو غاز."),
    lesson("p8_science_ecosystems","Ecosystems and the Environment","الأنظمة البيئية والبيئة","An ecosystem includes living things and the non-living parts of their environment. Plants are producers because they make food using sunlight. Animals are consumers. Decomposers, such as many fungi and bacteria, break down dead material. Clean water, soil and air help ecosystems remain healthy.\n\nExample: Grass → grasshopper → frog is a simple food chain. The arrows show the direction in which energy moves.","يشمل النظام البيئي الكائنات الحية والأجزاء غير الحية من بيئتها. النباتات منتِجات لأنها تصنع الغذاء باستخدام ضوء الشمس. الحيوانات مستهلكات. والمحللات، مثل كثير من الفطريات والبكتيريا، تفكك المواد الميتة. يساعد الماء والتربة والهواء النظيف على بقاء النظام البيئي سليمًا.\n\nمثال: عشب ← جرادة ← ضفدع في سلسلة غذائية بسيطة؛ وعند كتابة السلسلة من مصدر الغذاء إلى المستهلك تكون: العشب → الجرادة → الضفدع. توضح الأسهم اتجاه انتقال الطاقة."),
  ],questions:[
    q("What is the basic structural unit of life?","ما الوحدة الأساسية في تركيب الكائن الحي؟",["Organ", "Cell", "Rock", "Soil"],["عضو", "خلية", "صخرة", "تربة"],1),
    q("Which is a life process?","أي مما يلي عملية من عمليات الحياة؟",["Rusting", "Growth", "Breaking", "Melting ice"],["الصدأ", "النمو", "الكسر", "ذوبان الجليد"],1),
    q("Which state has a fixed shape and fixed volume?","أي حالة لها شكل وحجم ثابتان؟",["Gas", "Liquid", "Solid", "Vapour"],["الغاز", "السائل", "الصلب", "البخار"],2),
    q("What happens when liquid water evaporates?","ماذا يحدث عندما يتبخر الماء السائل؟",["It becomes a gas", "It becomes soil", "It becomes metal", "It disappears forever"],["يتحول إلى غاز", "يتحول إلى تربة", "يتحول إلى معدن", "يختفي إلى الأبد"],0),
    q("Which organism is a producer?","أي كائن يُعد منتِجًا؟",["Grass", "Goat", "Frog", "Eagle"],["العشب", "الماعز", "الضفدع", "النسر"],0),
    q("Which is a non-living part of an ecosystem?","أي مما يلي جزء غير حي من النظام البيئي؟",["Bird", "Tree", "Water", "Insect"],["طائر", "شجرة", "ماء", "حشرة"],2),
  ]),

  Subject(id:'p8_social_studies',name:lt('Social Studies','الدراسات الاجتماعية'),colorValue:0xFF00838F,icon:'◎',lessons:[
    lesson("p8_sst_maps","Maps and Directions","الخرائط والاتجاهات","A map is a drawing of all or part of the Earth's surface. A title tells what the map shows. A key explains symbols, and a scale compares map distance with real distance. The four main compass directions are north, east, south and west.\n\nExample: If a school is north of a market, the market is south of the school.","الخريطة رسم لسطح الأرض كله أو جزء منه. يوضح العنوان موضوع الخريطة. ويشرح المفتاح الرموز، بينما يقارن مقياس الرسم بين المسافة على الخريطة والمسافة الحقيقية. الاتجاهات الأصلية الأربعة هي الشمال والشرق والجنوب والغرب.\n\nمثال: إذا كانت المدرسة شمال السوق، فإن السوق يقع جنوب المدرسة."),
    lesson("p8_sst_community","Community and Citizenship","المجتمع والمواطنة","A community is a group of people who live in the same area or share interests. Good citizens respect others, follow fair laws, protect public property and help their community. Rights come with responsibilities.\n\nExample: Keeping a school compound clean protects public property and supports the whole community.","المجتمع مجموعة من الناس يعيشون في منطقة واحدة أو تجمعهم مصالح مشتركة. يحترم المواطن الصالح الآخرين، ويلتزم بالقوانين العادلة، ويحافظ على الممتلكات العامة ويساعد مجتمعه. ترتبط الحقوق بالمسؤوليات.\n\nمثال: المحافظة على نظافة ساحة المدرسة تحمي الممتلكات العامة وتفيد المجتمع كله."),
    lesson("p8_sst_environment","Environment and Natural Resources","البيئة والموارد الطبيعية","Natural resources include water, soil, forests, wildlife and minerals. Some resources can renew naturally if managed carefully; others are limited. Communities can protect resources by planting trees, avoiding pollution, saving water and using land responsibly.\n\nExample: Planting trees can reduce soil erosion and provide shade and habitats for wildlife.","تشمل الموارد الطبيعية الماء والتربة والغابات والحياة البرية والمعادن. يمكن لبعض الموارد أن تتجدد طبيعيًا إذا أُديرت بعناية، بينما موارد أخرى محدودة. تستطيع المجتمعات حماية الموارد بزراعة الأشجار وتجنب التلوث وتوفير الماء واستخدام الأرض بمسؤولية.\n\nمثال: يمكن لزراعة الأشجار أن تقلل تعرية التربة وتوفر الظل وموائل للحياة البرية."),
  ],questions:[
    q("What explains symbols on a map?","ما الذي يشرح الرموز في الخريطة؟",["Map key", "Title only", "Compass needle only", "Border"],["مفتاح الخريطة", "العنوان فقط", "إبرة البوصلة فقط", "الإطار"],0),
    q("Which direction is opposite to east?","ما الاتجاه المعاكس للشرق؟",["North", "South", "West", "North-east"],["الشمال", "الجنوب", "الغرب", "الشمال الشرقي"],2),
    q("Which action shows responsible citizenship?","أي تصرف يدل على المواطنة المسؤولة؟",["Damaging a classroom", "Helping keep public places clean", "Ignoring safety rules", "Taking another person's property"],["إتلاف الفصل", "المساعدة في نظافة الأماكن العامة", "تجاهل قواعد السلامة", "أخذ ممتلكات الآخرين"],1),
    q("A responsibility is…","المسؤولية هي…",["A duty to act properly", "A reason to damage property", "A right to ignore others", "A type of map"],["واجب للتصرف بصورة سليمة", "سبب لإتلاف الممتلكات", "حق في تجاهل الآخرين", "نوع من الخرائط"],0),
    q("Which is a natural resource?","أي مما يلي مورد طبيعي؟",["Plastic bag", "Water", "Mobile app", "Concrete block"],["كيس بلاستيكي", "الماء", "تطبيق هاتف", "كتلة خرسانية"],1),
    q("Which action helps conserve the environment?","أي عمل يساعد على حماية البيئة؟",["Burning all trees", "Dumping waste in rivers", "Planting trees", "Wasting clean water"],["حرق كل الأشجار", "إلقاء النفايات في الأنهار", "زراعة الأشجار", "إهدار المياه النظيفة"],2),
  ]),

  Subject(id:'p8_cre',name:lt('Christian Religious Education (CRE)','التربية الدينية المسيحية'),colorValue:0xFF6D4C41,icon:'✦',lessons:[
    lesson("p8_cre_values","Values: Honesty and Kindness","القيم: الصدق واللطف","Honesty means telling the truth and acting fairly. Kindness means treating others with care and respect. These values build trust at home, in school and in the community. When a mistake happens, a responsible person admits it and tries to make things right.\n\nExample: If you find a classmate's pencil, return it instead of keeping it.","الصدق هو قول الحقيقة والتصرف بعدل. واللطف هو معاملة الآخرين بعناية واحترام. تبني هذه القيم الثقة في المنزل والمدرسة والمجتمع. وعندما يحدث خطأ، يعترف الشخص المسؤول به ويحاول إصلاحه.\n\nمثال: إذا وجدت قلم زميلك، فأعده إليه بدلًا من الاحتفاظ به."),
    lesson("p8_cre_service","Service and Forgiveness","الخدمة والتسامح","Service means using time and abilities to help others. Forgiveness means choosing not to seek revenge after being wronged; it does not mean ignoring safety or allowing continued harm. Peaceful communication and seeking help from a trusted adult can resolve disagreements.\n\nExample: Students can serve their school by helping organize books or cleaning their classroom safely.","الخدمة هي استخدام الوقت والقدرات لمساعدة الآخرين. والتسامح هو اختيار عدم الانتقام عند التعرض للأذى؛ ولا يعني تجاهل السلامة أو السماح باستمرار الضرر. يمكن للتواصل الهادئ وطلب المساعدة من شخص بالغ موثوق أن يساعدا في حل الخلافات.\n\nمثال: يستطيع الطلاب خدمة مدرستهم بالمساعدة في ترتيب الكتب أو تنظيف الفصل بطريقة آمنة."),
  ],questions:[
    q("Which action shows honesty?","أي تصرف يدل على الصدق؟",["Returning a lost item", "Blaming someone falsely", "Hiding a mistake", "Copying answers"],["إعادة غرض مفقود", "اتهام شخص زورًا", "إخفاء الخطأ", "نسخ الإجابات"],0),
    q("Kindness includes…","يشمل اللطف…",["Mocking others", "Helping someone in need", "Spreading rumours", "Damaging books"],["السخرية من الآخرين", "مساعدة المحتاج", "نشر الشائعات", "إتلاف الكتب"],1),
    q("Which is an example of service?","أي مما يلي مثال على الخدمة؟",["Helping clean the classroom", "Breaking a desk", "Excluding a classmate", "Wasting food"],["المساعدة في تنظيف الفصل", "كسر مكتب", "إقصاء زميل", "إهدار الطعام"],0),
    q("Forgiveness means…","ماذا يعني التسامح؟",["Taking revenge", "Choosing not to seek revenge", "Hiding every danger", "Accepting continued harm"],["الانتقام", "اختيار عدم الانتقام", "إخفاء كل خطر", "قبول استمرار الأذى"],1),
  ]),

];


final List<Grade> grades = [
  Grade(id: 'p8', name: lt('Primary 8', 'الصف الثامن الأساسي')),
  Grade(id: 's1', name: lt('Senior 1', 'الصف الأول الثانوي')),
  Grade(id: 's2', name: lt('Senior 2', 'الصف الثاني الثانوي')),
  Grade(id: 's3', name: lt('Senior 3', 'الصف الثالث الثانوي')),
];

// Subjects currently included in the first offline curriculum.
// More grade-specific content can be assigned here as the curriculum grows.
final Map<String, List<String>> gradeSubjectIds = {
  'p8': ['p8_mathematics', 'p8_english', 'p8_science', 'p8_social_studies', 'p8_cre'],
  's1': ['mathematics', 'english', 'biology', 'chemistry', 'physics', 'geography', 'history', 'commerce', 'account'],
  's2': ['mathematics', 'english', 'biology', 'chemistry', 'physics', 'geography', 'history', 'commerce', 'account'],
  's3': ['mathematics', 'english', 'biology', 'chemistry', 'physics', 'geography', 'history', 'commerce', 'account'],
};
