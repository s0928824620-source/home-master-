# Home Master — P8 bilingual starter lessons

## What is included
- 5 P8 subject areas: Mathematics, English, Science, Social Studies, and Christian Religious Education (CRE).
- 13? Original bilingual lesson records, examples, and two multiple-choice questions per lesson.
- Correct answer index and a short explanation for each question.
- JSON is suitable as a source data pack for an offline curriculum import.

## Important
This is a **starter pack**, not a complete P8 curriculum and not a replacement for official student textbooks. It is original explanatory content written to cover broad learning areas. Verify each unit against current South Sudan NCDC books and teacher guidance before calling it fully curriculum-complete.

## Integration note
This ZIP is a content pack only. It does **not** modify the Flutter app or automatically install the lessons into the existing APK. The app's data loader must be updated to read these records (or equivalent Dart data must be added), and a new APK must then be built and tested. No Supabase secrets are included.
